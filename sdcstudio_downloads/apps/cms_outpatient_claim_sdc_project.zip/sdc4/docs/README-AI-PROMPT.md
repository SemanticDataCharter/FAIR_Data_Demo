# CMS Outpatient Claim

**Model ID**: `dm-mllwhe842wtnim4ms48qonio`
**Project**: FAIR Data Demo
**Description**: SDC4 data model for CMS DE-SynPUF (Medicare Claims Synthetic Data) (cms_outpatient) — FAIR Data Demo

### Dublin Core Metadata
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal

## Package Contents

- `dm-mllwhe842wtnim4ms48qonio.xsd` -- XML Schema Definition (data model structure)
- `dm-mllwhe842wtnim4ms48qonio.xml` -- XML instance example with sample data
- `dm-mllwhe842wtnim4ms48qonio-instance.json` -- JSON instance example (same structure as XML)
- `dm-mllwhe842wtnim4ms48qonio.jsonld` -- JSON-LD semantic schema description
- `dm-mllwhe842wtnim4ms48qonio.html` -- Human-readable model documentation
- `dm-mllwhe842wtnim4ms48qonio_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-mllwhe842wtnim4ms48qonio.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-mllwhe842wtnim4ms48qonio.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-mllwhe842wtnim4ms48qonio.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-mllwhe842wtnim4ms48qonio.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **CMS Outpatient Claim Governed Record** | Cluster | `cfbimjxaeo7964wdjqelryzr` | 0 components; 4 sub-cluster(s) |
|   **Audit Event** | Cluster | `t2tvd3wylxrstdeu5aw6gkw1` | 13 components |
|     Audit Agent Reference | XdString | `dkc2ccj5te35z9gd4bu1blcq` | maxLen=2000; pattern=`\S+` |
|     Audit Entity Reference | XdString | `gcjyjrnp0wsfoelcp4m05c67` | maxLen=2000; pattern=`\S+` |
|     Audit Event Identifier | XdString | `fjhgr5fyqxt2crmg2cb5c513` | maxLen=255 |
|     Data Subject Reference | XdString | `sndpbhm3xbd6qtbyxmvh3i0e` | maxLen=2000; pattern=`\S+` |
|     On Behalf Of Reference | XdString | `nf1air1zbj8v9w66jozdxmyl` | maxLen=2000; pattern=`\S+` |
|     System Identifier | XdString | `h3kdbvdtyalpvik97saaf0an` | maxLen=255 |
|     System Location Name | XdString | `ujir739mf1g8ajeczs9nzh9m` | maxLen=255 |
|     Audit Event Action | XdToken | `ce1c8sydkov8bkv4dgdmwe5x` | 5 enum(s) |
|     Audit Event Outcome | XdToken | `rpz1czz06jhpahmfz30rblvp` | 4 enum(s) |
|     Confidentiality | XdToken | `vbctgmdcwps5b3r3l6sboa6y` | 6 enum(s) |
|     Provenance Agent Type | XdToken | `jujsdur1igws8orw6tvvlqco` | 13 enum(s) |
|     Purpose of Use | XdToken | `d1evlz8yvdlwt6ia9fjq4pgj` | 11 enum(s) |
|     Audit Recorded At | XdTemporal | `uwiosm2q9ym3ewr4de910s70` | -- |
|   **CMS Outpatient Claim** | Cluster | `ls6pcoy94kbq68aa9v5y1qr8` | 12 components; 28 sub-cluster(s) |
|     Attending Physician NPI (AT_PHYSN_NPI) | XdString | `b5h4gc4jje1imwkzdt6xg5wb` | maxLen=10; pattern=`[0-9]{10}` |
|     Beneficiary Code (DESYNPUF_ID) | XdString | `zshx6rx7ca1j00eda9kxyh6h` | maxLen=16; pattern=`[0-9A-F]{16}` |
|     Claim ID (CLM_ID) | XdString | `skyz3ht3zv3j5qwsx8x0dyru` | maxLen=20; pattern=`[0-9]{1,20}` |
|     Operating Physician NPI (OP_PHYSN_NPI) | XdString | `lq0eu7o1fizlst28weyv3z2t` | maxLen=10; pattern=`[0-9]{10}` |
|     Other Physician NPI (OT_PHYSN_NPI) | XdString | `d3c64u25m9yvux5qe9eu2ur9` | maxLen=10; pattern=`[0-9]{10}` |
|     Provider Institution (PRVDR_NUM) | XdString | `lv5pcw6w5e15mo1t2oiofatl` | maxLen=10 |
|     Claim Line Segment (SEGMENT) | XdCount | `x30sghfdhlvgw2gn7trxp9u6` | units=Items |
|     Blood Deductible Liability Amount | XdQuantity | `s7najsv11bd33calnyktjcon` | units=Currency |
|     Claim Payment Amount | XdQuantity | `bgis0a73v9ncnwhicmjmvhl1` | units=Currency |
|     Part B Coinsurance Amount | XdQuantity | `d3wdaw6x7seq2wist9v1ebch` | units=Currency |
|     Part B Deductible Amount | XdQuantity | `tg2j38jv33c2b34s21m1on28` | units=Currency |
|     Primary Payer Claim Paid Amount | XdQuantity | `rnpfh6mpz8jfq28dfjp17rf9` | units=Currency |
|     **Admitting Diagnosis** | Cluster | `av5ztq8he6ot9ubpc4mhtp3s` | 0 components; 1 sub-cluster(s) |
|       **Diagnosis (ICD-9-CM)** | Cluster | `f9y0zpvphrny3gapgnjss0w1` | 3 components |
|         Code System: ICD-9-CM | XdLink | `qdl35df54hlauu2mhwac6goe` | -- |
|         Diagnosis Code (ICD-9-CM) | XdString | `jpr4t7i8lrhxen4x63s6jp2c` | maxLen=5; pattern=`[0-9EV][0-9]{2,4}` |
|         Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|     **Claim Diagnosis 1** | Cluster | `v6cz7f7o7q0e1ziekrn7oam5` | 0 components; 1 sub-cluster(s) |
|     **Claim Diagnosis 10** | Cluster | `c7up53lff6ip0zyv8dkkt868` | 0 components; 1 sub-cluster(s) |
|     **Claim Diagnosis 2** | Cluster | `x1942izf02stqs3kiu2yepf5` | 0 components; 1 sub-cluster(s) |
|     **Claim Diagnosis 3** | Cluster | `n1asylnn94ejo14l8us3wxf6` | 0 components; 1 sub-cluster(s) |
|     **Claim Diagnosis 4** | Cluster | `lpc82x2o46h4uixol7vdj05b` | 0 components; 1 sub-cluster(s) |
|     **Claim Diagnosis 5** | Cluster | `zd43681w5jtanaml4wiaz1yo` | 0 components; 1 sub-cluster(s) |
|     **Claim Diagnosis 6** | Cluster | `xvdtx5vxlu8pl9dyfz8x8m1r` | 0 components; 1 sub-cluster(s) |
|     **Claim Diagnosis 7** | Cluster | `pelxyum1gkog2kgqhndrluo7` | 0 components; 1 sub-cluster(s) |
|     **Claim Diagnosis 8** | Cluster | `p2y70uqn5j1mrktvht2tf6u4` | 0 components; 1 sub-cluster(s) |
|     **Claim Diagnosis 9** | Cluster | `it3x0l7q5js77eubgxkv0eij` | 0 components; 1 sub-cluster(s) |
|     **Claim HCPCS 1** | Cluster | `e8mpixmhxaxlcrxmdfepx9za` | 0 components; 1 sub-cluster(s) |
|       **Procedure (HCPCS)** | Cluster | `embtq0y4cmyk5em87e3jbdjx` | 3 components |
|         Code System: HCPCS | XdLink | `u3euzufk7txuf1u20g0ca89l` | -- |
|         HCPCS Code | XdString | `sqy06x5fv64a322dtl308lmw` | maxLen=5; pattern=`[0-9A-Z][0-9]{3}[0-9A-Z]` |
|         Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|     **Claim HCPCS 10** | Cluster | `uso6k4nxb3m5ju33iqric9as` | 0 components; 1 sub-cluster(s) |
|     **Claim HCPCS 2** | Cluster | `xfvr55ap2rv2nokf9v12gggl` | 0 components; 1 sub-cluster(s) |
|     **Claim HCPCS 3** | Cluster | `jrlt189phj31y3vwgbpd79fw` | 0 components; 1 sub-cluster(s) |
|     **Claim HCPCS 4** | Cluster | `f9j6mhy2vd2tjjms2r2w5hls` | 0 components; 1 sub-cluster(s) |
|     **Claim HCPCS 5** | Cluster | `g9uatlpz9l8bg2d168yileej` | 0 components; 1 sub-cluster(s) |
|     **Claim HCPCS 6** | Cluster | `l9jnt4o3wpofp22dvqjrez9t` | 0 components; 1 sub-cluster(s) |
|     **Claim HCPCS 7** | Cluster | `e9wisxqgslfvwzf8f9g2ns1a` | 0 components; 1 sub-cluster(s) |
|     **Claim HCPCS 8** | Cluster | `zkshfzesnopszu12m8yt656o` | 0 components; 1 sub-cluster(s) |
|     **Claim HCPCS 9** | Cluster | `uv5qgddm3wuigsszk0o80bk9` | 0 components; 1 sub-cluster(s) |
|     **Claim Procedure 1** | Cluster | `mzga0gpl0rsdppkx89slwi9z` | 0 components; 1 sub-cluster(s) |
|       **Procedure (ICD-9-CM)** | Cluster | `mrjuxhrc2jvbxslo2rlzndyv` | 3 components |
|         Code System: ICD-9-CM | XdLink | `qdl35df54hlauu2mhwac6goe` | -- |
|         Procedure Code (ICD-9-CM) | XdString | `nwmv4c2ogjk8ohxzum1zuprf` | maxLen=4; pattern=`[0-9]{2,4}` |
|         Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|     **Claim Procedure 2** | Cluster | `s5duw4mmis3a4auw1fwvkctt` | 0 components; 1 sub-cluster(s) |
|     **Claim Procedure 3** | Cluster | `wph20dg6mu7bwrm4gbw6wao9` | 0 components; 1 sub-cluster(s) |
|     **Claim Procedure 4** | Cluster | `a50e7whycfue1qianqp65rq9` | 0 components; 1 sub-cluster(s) |
|     **Claim Procedure 5** | Cluster | `lg86shb5pwq1r3sann4tyxzq` | 0 components; 1 sub-cluster(s) |
|     **Claim Procedure 6** | Cluster | `mfk506g2b5l0gvz9m2stpljy` | 0 components; 1 sub-cluster(s) |
|     **Encounter** | Cluster | `rghkif2x2xhe0e82mc85qwvm` | 6 components; 2 sub-cluster(s) |
|       Encounter Class | XdToken | `f8vsfzqb1m8ecfosdzhc9out` | 11 enum(s) |
|       Encounter Priority | XdToken | `jcsoakfsmdndfvw6p0nh879m` | 15 enum(s) |
|       Encounter Status | XdToken | `mpkqsp6zn1gbc1zhqai9y40b` | 9 enum(s) |
|       Encounter Length | XdQuantity | `gdcfl9ghwkswdbmxww4senbt` | units=Time Units |
|       Encounter End | XdTemporal | `pkren9mdq1ve6mdcn5hdu4xq` | -- |
|       Encounter Start | XdTemporal | `anbcg4rhacgmv8lkfofymmv0` | -- |
|       **Encounter Reason (SNOMED CT)** | Cluster | `u6u23oip0dinxve95ub0kwma` | 3 components |
|         Code System: SNOMED CT | XdLink | `q75pzzv36or6dxgjrrbvmun5` | -- |
|         Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|         Encounter Reason Code (SNOMED CT) | XdString | `cmtzyf0esp2hbf8ze2q0d3bh` | maxLen=40; pattern=`[0-9]{6,18}` |
|       **Hospitalization** | Cluster | `fnxiiamw1uk1hvsxmjgsu1xy` | 2 components |
|         Admit Source | XdToken | `awvbv44gmq5co6prxcnhdz09` | 10 enum(s) |
|         Discharge Disposition | XdToken | `wd1txyosw8ha21sohphne92e` | 11 enum(s) |
|   **PROV Activity** | Cluster | `vmikfu0irht9fmq7q02t3oqs` | 15 components |
|     Activity Description | XdString | `hhusuzzig19rs46ngz23k5g7` | maxLen=4000 |
|     Activity Identifier | XdString | `wr06h54xqqw2q9id8i9673jy` | maxLen=255 |
|     Activity Label | XdString | `r6hkunjm2q0hlxiknlc9ljix` | maxLen=255 |
|     Activity Location | XdString | `uzai5uey5p1fnn9ezj9u6vor` | maxLen=255 |
|     Activity Type | XdString | `jjzmhdxvbt97pq81iwqubtxk` | maxLen=255 |
|     Error Message | XdString | `xlgjqdpwdbn2re3mdh5yy2rk` | maxLen=4000 |
|     Had Plan Reference | XdString | `vhezo2cckpe92x4c3j2memeh` | maxLen=2000; pattern=`\S+` |
|     Used Entity Reference | XdString | `t0whhrqtnb54te4mk48i1ooj` | maxLen=2000; pattern=`\S+` |
|     Was Associated With Reference | XdString | `r48alj7hc3797qfjnf2uj71n` | maxLen=2000; pattern=`\S+` |
|     Was Ended By Reference | XdString | `ueb5g1ojzlwwt0mnds5zb6wl` | maxLen=2000; pattern=`\S+` |
|     Was Informed By Reference | XdString | `qh84jdzp1kxt85aq4ilo0svk` | maxLen=2000; pattern=`\S+` |
|     Was Started By Reference | XdString | `ginfqbk7q59ld2r4us8sjnv1` | maxLen=2000; pattern=`\S+` |
|     Activity Status | XdToken | `wl6j4ekcmu4hvt2m12zw4zp8` | 6 enum(s) |
|     Ended At | XdTemporal | `a5scyosu6j84vz350mqyrzl2` | -- |
|     Started At | XdTemporal | `sa4nl1kbpdr842fkucvfjkpq` | -- |
|   **PROV Agent** | Cluster | `c179ilk2ns15cd5rzzdfd6f6` | 9 components |
|     Acted On Behalf Of Reference | XdString | `og08xf6bu928uuz6t3y0e23f` | maxLen=2000; pattern=`\S+` |
|     Agent Description | XdString | `gb78cmuyo72hqs5apymdki7l` | maxLen=4000 |
|     Agent Email | XdString | `qb90a0sp9vvb6c5cbcf236ys` | maxLen=255 |
|     Agent Identifier | XdString | `w2ruemcfy35rw60jl1t9dew2` | maxLen=255 |
|     Agent Name | XdString | `xxe21o9ojzmy9wxxky1tnmog` | maxLen=255 |
|     Agent Organization Name | XdString | `eftvwi5byq6cdtd931qyxzw0` | maxLen=255 |
|     Software Name | XdString | `aa663ivutjf2fs4757t0bbzy` | maxLen=255 |
|     Software Version | XdString | `x0lebwtobgaelj5pev3258sd` | maxLen=60 |
|     PROV Agent Type | XdToken | `i16vqj89it3db7d3c5qjko9p` | 3 enum(s) |

## Structural Hierarchy

```
DM: CMS Outpatient Claim
  [Cluster] CMS Outpatient Claim Governed Record
    [Cluster] Audit Event
      [XdString] Audit Agent Reference
      [XdString] Audit Entity Reference
      [XdString] Audit Event Identifier
      [XdString] Data Subject Reference
      [XdString] On Behalf Of Reference
      [XdString] System Identifier
      [XdString] System Location Name
      [XdToken] Audit Event Action
      [XdToken] Audit Event Outcome
      [XdToken] Confidentiality
      [XdToken] Provenance Agent Type
      [XdToken] Purpose of Use
      [XdTemporal] Audit Recorded At
    [Cluster] CMS Outpatient Claim
      [XdString] Attending Physician NPI (AT_PHYSN_NPI)
      [XdString] Beneficiary Code (DESYNPUF_ID)
      [XdString] Claim ID (CLM_ID)
      [XdString] Operating Physician NPI (OP_PHYSN_NPI)
      [XdString] Other Physician NPI (OT_PHYSN_NPI)
      [XdString] Provider Institution (PRVDR_NUM)
      [XdCount] Claim Line Segment (SEGMENT)
      [XdQuantity] Blood Deductible Liability Amount
      [XdQuantity] Claim Payment Amount
      [XdQuantity] Part B Coinsurance Amount
      [XdQuantity] Part B Deductible Amount
      [XdQuantity] Primary Payer Claim Paid Amount
      [Cluster] Admitting Diagnosis
        [Cluster] Diagnosis (ICD-9-CM)
          [XdLink] Code System: ICD-9-CM
          [XdString] Diagnosis Code (ICD-9-CM)
          [XdString] Code Display Text
      [Cluster] Claim Diagnosis 1
        [Cluster] Diagnosis (ICD-9-CM) (circular ref)
      [Cluster] Claim Diagnosis 10
        [Cluster] Diagnosis (ICD-9-CM) (circular ref)
      [Cluster] Claim Diagnosis 2
        [Cluster] Diagnosis (ICD-9-CM) (circular ref)
      [Cluster] Claim Diagnosis 3
        [Cluster] Diagnosis (ICD-9-CM) (circular ref)
      [Cluster] Claim Diagnosis 4
        [Cluster] Diagnosis (ICD-9-CM) (circular ref)
      [Cluster] Claim Diagnosis 5
        [Cluster] Diagnosis (ICD-9-CM) (circular ref)
      [Cluster] Claim Diagnosis 6
        [Cluster] Diagnosis (ICD-9-CM) (circular ref)
      [Cluster] Claim Diagnosis 7
        [Cluster] Diagnosis (ICD-9-CM) (circular ref)
      [Cluster] Claim Diagnosis 8
        [Cluster] Diagnosis (ICD-9-CM) (circular ref)
      [Cluster] Claim Diagnosis 9
        [Cluster] Diagnosis (ICD-9-CM) (circular ref)
      [Cluster] Claim HCPCS 1
        [Cluster] Procedure (HCPCS)
          [XdLink] Code System: HCPCS
          [XdString] HCPCS Code
          [XdString] Code Display Text
      [Cluster] Claim HCPCS 10
        [Cluster] Procedure (HCPCS) (circular ref)
      [Cluster] Claim HCPCS 2
        [Cluster] Procedure (HCPCS) (circular ref)
      [Cluster] Claim HCPCS 3
        [Cluster] Procedure (HCPCS) (circular ref)
      [Cluster] Claim HCPCS 4
        [Cluster] Procedure (HCPCS) (circular ref)
      [Cluster] Claim HCPCS 5
        [Cluster] Procedure (HCPCS) (circular ref)
      [Cluster] Claim HCPCS 6
        [Cluster] Procedure (HCPCS) (circular ref)
      [Cluster] Claim HCPCS 7
        [Cluster] Procedure (HCPCS) (circular ref)
      [Cluster] Claim HCPCS 8
        [Cluster] Procedure (HCPCS) (circular ref)
      [Cluster] Claim HCPCS 9
        [Cluster] Procedure (HCPCS) (circular ref)
      [Cluster] Claim Procedure 1
        [Cluster] Procedure (ICD-9-CM)
          [XdLink] Code System: ICD-9-CM
          [XdString] Procedure Code (ICD-9-CM)
          [XdString] Code Display Text
      [Cluster] Claim Procedure 2
        [Cluster] Procedure (ICD-9-CM) (circular ref)
      [Cluster] Claim Procedure 3
        [Cluster] Procedure (ICD-9-CM) (circular ref)
      [Cluster] Claim Procedure 4
        [Cluster] Procedure (ICD-9-CM) (circular ref)
      [Cluster] Claim Procedure 5
        [Cluster] Procedure (ICD-9-CM) (circular ref)
      [Cluster] Claim Procedure 6
        [Cluster] Procedure (ICD-9-CM) (circular ref)
      [Cluster] Encounter
        [XdToken] Encounter Class
        [XdToken] Encounter Priority
        [XdToken] Encounter Status
        [XdQuantity] Encounter Length
        [XdTemporal] Encounter End
        [XdTemporal] Encounter Start
        [Cluster] Encounter Reason (SNOMED CT)
          [XdLink] Code System: SNOMED CT
          [XdString] Code Display Text
          [XdString] Encounter Reason Code (SNOMED CT)
        [Cluster] Hospitalization
          [XdToken] Admit Source
          [XdToken] Discharge Disposition
    [Cluster] PROV Activity
      [XdString] Activity Description
      [XdString] Activity Identifier
      [XdString] Activity Label
      [XdString] Activity Location
      [XdString] Activity Type
      [XdString] Error Message
      [XdString] Had Plan Reference
      [XdString] Used Entity Reference
      [XdString] Was Associated With Reference
      [XdString] Was Ended By Reference
      [XdString] Was Informed By Reference
      [XdString] Was Started By Reference
      [XdToken] Activity Status
      [XdTemporal] Ended At
      [XdTemporal] Started At
    [Cluster] PROV Agent
      [XdString] Acted On Behalf Of Reference
      [XdString] Agent Description
      [XdString] Agent Email
      [XdString] Agent Identifier
      [XdString] Agent Name
      [XdString] Agent Organization Name
      [XdString] Software Name
      [XdString] Software Version
      [XdToken] PROV Agent Type
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| CMS Outpatient Claim Governed Record | `dcterms:publisher` | `https://axius-sdc.com` |
| CMS Outpatient Claim Governed Record | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| CMS Outpatient Claim Governed Record | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-outpatient-claim-governed-record` |
| CMS Outpatient Claim Governed Record | `skos:exactMatch` | `http://www.w3.org/ns/prov#Entity` |
| Audit Event | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event` |
| Audit Event | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/AuditEvent` |
| Audit Agent Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Agent Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Agent Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-agent-reference` |
| Audit Agent Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.who` |
| Audit Agent Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bads7w1q6wmhn18u6dxwt28t` |
| Audit Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Entity Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-entity-reference` |
| Audit Entity Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.entity.what` |
| Audit Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-sjp1x177mlpq3howdltptm3c` |
| Audit Event Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-identifier` |
| Audit Event Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Data Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Data Subject Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Data Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/data-subject-reference` |
| Data Subject Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.patient` |
| Data Subject Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-x2rc9cg84d2famryqzdic0as` |
| On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| On Behalf Of Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/on-behalf-of-reference` |
| On Behalf Of Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/provenance-definitions.html#Provenance.agent.onBehalfOf` |
| On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-j9gvyx6u9pb7v1dd0m6joxd6` |
| System Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| System Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-identifier` |
| System Identifier | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.source.observer` |
| System Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-des67jo3ki9w0zgaz2i2t2cq` |
| System Location Name | `dcterms:publisher` | `https://axius-sdc.com` |
| System Location Name | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Location Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-location-name` |
| System Location Name | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.location` |
| System Location Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l6fwy1a2l5i43t308pknygp7` |
| Audit Event Action | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Action | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Action | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-action` |
| Audit Event Action | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-action` |
| Audit Event Action | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-o8lawuczf9vry55e98cjg12r` |
| Audit Event Outcome | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Outcome | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Outcome | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-outcome` |
| Audit Event Outcome | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-outcome` |
| Audit Event Outcome | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lgmleqp52a6kl268drrtfjk5` |
| Confidentiality | `dcterms:publisher` | `https://axius-sdc.com` |
| Confidentiality | `dcterms:source` | `http://terminology.hl7.org/` |
| Confidentiality | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/confidentiality` |
| Confidentiality | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-Confidentiality` |
| Confidentiality | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hp8q52t8tgmis92c4ljrfy7e` |
| Provenance Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Provenance Agent Type | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Provenance Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/provenance-agent-type` |
| Provenance Agent Type | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/provenance-participant-type` |
| Provenance Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-syt8l7pmb64eym2chcn43ai7` |
| Purpose of Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Purpose of Use | `dcterms:source` | `http://terminology.hl7.org/` |
| Purpose of Use | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/purpose-of-use` |
| Purpose of Use | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActReason` |
| Purpose of Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-y87ikto4p56zlkx4o2d63ain` |
| Audit Recorded At | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Recorded At | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Recorded At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-recorded-at` |
| Audit Recorded At | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.recorded` |
| CMS Outpatient Claim | `dcterms:publisher` | `https://axius-sdc.com` |
| CMS Outpatient Claim | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| CMS Outpatient Claim | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-outpatient-claim` |
| CMS Outpatient Claim | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/Claim` |
| Attending Physician NPI (AT_PHYSN_NPI) | `dcterms:publisher` | `https://axius-sdc.com` |
| Attending Physician NPI (AT_PHYSN_NPI) | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Attending Physician NPI (AT_PHYSN_NPI) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-attending-physician-npi` |
| Attending Physician NPI (AT_PHYSN_NPI) | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Beneficiary Code (DESYNPUF_ID) | `dcterms:publisher` | `https://axius-sdc.com` |
| Beneficiary Code (DESYNPUF_ID) | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Beneficiary Code (DESYNPUF_ID) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-beneficiary-code` |
| Beneficiary Code (DESYNPUF_ID) | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim ID (CLM_ID) | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim ID (CLM_ID) | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim ID (CLM_ID) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-id` |
| Claim ID (CLM_ID) | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Operating Physician NPI (OP_PHYSN_NPI) | `dcterms:publisher` | `https://axius-sdc.com` |
| Operating Physician NPI (OP_PHYSN_NPI) | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Operating Physician NPI (OP_PHYSN_NPI) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-operating-physician-npi` |
| Operating Physician NPI (OP_PHYSN_NPI) | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Other Physician NPI (OT_PHYSN_NPI) | `dcterms:publisher` | `https://axius-sdc.com` |
| Other Physician NPI (OT_PHYSN_NPI) | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Other Physician NPI (OT_PHYSN_NPI) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-other-physician-npi` |
| Other Physician NPI (OT_PHYSN_NPI) | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Provider Institution (PRVDR_NUM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Provider Institution (PRVDR_NUM) | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Provider Institution (PRVDR_NUM) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-provider-institution` |
| Provider Institution (PRVDR_NUM) | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Line Segment (SEGMENT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim Line Segment (SEGMENT) | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Line Segment (SEGMENT) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-line-segment` |
| Claim Line Segment (SEGMENT) | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Blood Deductible Liability Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Blood Deductible Liability Amount | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Blood Deductible Liability Amount | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-blood-deductible-liability-amount` |
| Blood Deductible Liability Amount | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Blood Deductible Liability Amount | `skos:closeMatch` | `https://schema.org/MonetaryAmount` |
| Claim Payment Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim Payment Amount | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Payment Amount | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-payment-amount` |
| Claim Payment Amount | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Payment Amount | `skos:closeMatch` | `https://schema.org/MonetaryAmount` |
| Part B Coinsurance Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Part B Coinsurance Amount | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Part B Coinsurance Amount | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-part-b-coinsurance-amount` |
| Part B Coinsurance Amount | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Part B Coinsurance Amount | `skos:closeMatch` | `https://schema.org/MonetaryAmount` |
| Part B Deductible Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Part B Deductible Amount | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Part B Deductible Amount | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-part-b-deductible-amount` |
| Part B Deductible Amount | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Part B Deductible Amount | `skos:closeMatch` | `https://schema.org/MonetaryAmount` |
| Primary Payer Claim Paid Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Primary Payer Claim Paid Amount | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Primary Payer Claim Paid Amount | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-primary-payer-claim-paid-amount` |
| Primary Payer Claim Paid Amount | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Primary Payer Claim Paid Amount | `skos:closeMatch` | `https://schema.org/MonetaryAmount` |
| Admitting Diagnosis | `dcterms:publisher` | `https://axius-sdc.com` |
| Admitting Diagnosis | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Admitting Diagnosis | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-admitting-diagnosis` |
| Admitting Diagnosis | `skos:exactMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.diagnosis` |
| Diagnosis (ICD-9-CM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Diagnosis (ICD-9-CM) | `dcterms:source` | `http://hl7.org/fhir/sid/icd-9-cm` |
| Diagnosis (ICD-9-CM) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/diagnosis-icd9cm` |
| Diagnosis (ICD-9-CM) | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes.html#Coding` |
| Code System: ICD-9-CM | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: ICD-9-CM | `dcterms:source` | `http://hl7.org/fhir/sid/icd-9-cm` |
| Code System: ICD-9-CM | `dcterms:identifier` | `https://axius-sdc.com/library/fair/system-icd9cm` |
| Code System: ICD-9-CM | `skos:exactMatch` | `http://hl7.org/fhir/sid/icd-9-cm` |
| Diagnosis Code (ICD-9-CM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Diagnosis Code (ICD-9-CM) | `dcterms:source` | `http://hl7.org/fhir/sid/icd-9-cm` |
| Diagnosis Code (ICD-9-CM) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/diagnosis-icd9cm-code` |
| Diagnosis Code (ICD-9-CM) | `skos:exactMatch` | `http://hl7.org/fhir/sid/icd-9-cm` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Claim Diagnosis 1 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim Diagnosis 1 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Diagnosis 1 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-diagnosis-1` |
| Claim Diagnosis 1 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.diagnosis` |
| Claim Diagnosis 10 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim Diagnosis 10 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Diagnosis 10 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-diagnosis-10` |
| Claim Diagnosis 10 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.diagnosis` |
| Claim Diagnosis 2 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim Diagnosis 2 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Diagnosis 2 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-diagnosis-2` |
| Claim Diagnosis 2 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.diagnosis` |
| Claim Diagnosis 3 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim Diagnosis 3 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Diagnosis 3 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-diagnosis-3` |
| Claim Diagnosis 3 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.diagnosis` |
| Claim Diagnosis 4 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim Diagnosis 4 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Diagnosis 4 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-diagnosis-4` |
| Claim Diagnosis 4 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.diagnosis` |
| Claim Diagnosis 5 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim Diagnosis 5 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Diagnosis 5 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-diagnosis-5` |
| Claim Diagnosis 5 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.diagnosis` |
| Claim Diagnosis 6 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim Diagnosis 6 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Diagnosis 6 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-diagnosis-6` |
| Claim Diagnosis 6 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.diagnosis` |
| Claim Diagnosis 7 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim Diagnosis 7 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Diagnosis 7 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-diagnosis-7` |
| Claim Diagnosis 7 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.diagnosis` |
| Claim Diagnosis 8 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim Diagnosis 8 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Diagnosis 8 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-diagnosis-8` |
| Claim Diagnosis 8 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.diagnosis` |
| Claim Diagnosis 9 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim Diagnosis 9 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Diagnosis 9 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-diagnosis-9` |
| Claim Diagnosis 9 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.diagnosis` |
| Claim HCPCS 1 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim HCPCS 1 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim HCPCS 1 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-hcpcs-1` |
| Claim HCPCS 1 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.item` |
| Procedure (HCPCS) | `dcterms:publisher` | `https://axius-sdc.com` |
| Procedure (HCPCS) | `dcterms:source` | `http://www.ama-assn.org/go/cpt` |
| Procedure (HCPCS) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/procedure-hcpcs` |
| Procedure (HCPCS) | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes.html#Coding` |
| Code System: HCPCS | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: HCPCS | `dcterms:source` | `http://www.ama-assn.org/go/cpt` |
| Code System: HCPCS | `dcterms:identifier` | `https://axius-sdc.com/library/fair/system-hcpcs` |
| Code System: HCPCS | `skos:exactMatch` | `http://www.ama-assn.org/go/cpt` |
| HCPCS Code | `dcterms:publisher` | `https://axius-sdc.com` |
| HCPCS Code | `dcterms:source` | `http://www.ama-assn.org/go/cpt` |
| HCPCS Code | `dcterms:identifier` | `https://axius-sdc.com/library/fair/hcpcs-code` |
| HCPCS Code | `skos:exactMatch` | `http://www.ama-assn.org/go/cpt` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Claim HCPCS 10 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim HCPCS 10 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim HCPCS 10 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-hcpcs-10` |
| Claim HCPCS 10 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.item` |
| Claim HCPCS 2 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim HCPCS 2 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim HCPCS 2 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-hcpcs-2` |
| Claim HCPCS 2 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.item` |
| Claim HCPCS 3 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim HCPCS 3 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim HCPCS 3 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-hcpcs-3` |
| Claim HCPCS 3 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.item` |
| Claim HCPCS 4 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim HCPCS 4 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim HCPCS 4 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-hcpcs-4` |
| Claim HCPCS 4 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.item` |
| Claim HCPCS 5 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim HCPCS 5 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim HCPCS 5 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-hcpcs-5` |
| Claim HCPCS 5 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.item` |
| Claim HCPCS 6 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim HCPCS 6 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim HCPCS 6 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-hcpcs-6` |
| Claim HCPCS 6 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.item` |
| Claim HCPCS 7 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim HCPCS 7 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim HCPCS 7 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-hcpcs-7` |
| Claim HCPCS 7 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.item` |
| Claim HCPCS 8 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim HCPCS 8 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim HCPCS 8 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-hcpcs-8` |
| Claim HCPCS 8 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.item` |
| Claim HCPCS 9 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim HCPCS 9 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim HCPCS 9 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-hcpcs-9` |
| Claim HCPCS 9 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.item` |
| Claim Procedure 1 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim Procedure 1 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Procedure 1 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-procedure-1` |
| Claim Procedure 1 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.procedure` |
| Procedure (ICD-9-CM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Procedure (ICD-9-CM) | `dcterms:source` | `http://hl7.org/fhir/sid/icd-9-cm` |
| Procedure (ICD-9-CM) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/procedure-icd9cm` |
| Procedure (ICD-9-CM) | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes.html#Coding` |
| Code System: ICD-9-CM | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: ICD-9-CM | `dcterms:source` | `http://hl7.org/fhir/sid/icd-9-cm` |
| Code System: ICD-9-CM | `dcterms:identifier` | `https://axius-sdc.com/library/fair/system-icd9cm` |
| Code System: ICD-9-CM | `skos:exactMatch` | `http://hl7.org/fhir/sid/icd-9-cm` |
| Procedure Code (ICD-9-CM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Procedure Code (ICD-9-CM) | `dcterms:source` | `http://hl7.org/fhir/sid/icd-9-cm` |
| Procedure Code (ICD-9-CM) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/procedure-icd9cm-code` |
| Procedure Code (ICD-9-CM) | `skos:exactMatch` | `http://hl7.org/fhir/sid/icd-9-cm` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Claim Procedure 2 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim Procedure 2 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Procedure 2 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-procedure-2` |
| Claim Procedure 2 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.procedure` |
| Claim Procedure 3 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim Procedure 3 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Procedure 3 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-procedure-3` |
| Claim Procedure 3 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.procedure` |
| Claim Procedure 4 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim Procedure 4 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Procedure 4 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-procedure-4` |
| Claim Procedure 4 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.procedure` |
| Claim Procedure 5 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim Procedure 5 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Procedure 5 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-procedure-5` |
| Claim Procedure 5 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.procedure` |
| Claim Procedure 6 | `dcterms:publisher` | `https://axius-sdc.com` |
| Claim Procedure 6 | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Procedure 6 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-claim-procedure-6` |
| Claim Procedure 6 | `skos:exactMatch` | `http://hl7.org/fhir/R4/claim-definitions.html#Claim.procedure` |
| Encounter | `dcterms:publisher` | `https://axius-sdc.com` |
| Encounter | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Encounter | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/encounter` |
| Encounter | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/Encounter` |
| Encounter | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ixcrz5r9vrahm36nzsol3xea` |
| Encounter Class | `dcterms:publisher` | `https://axius-sdc.com` |
| Encounter Class | `dcterms:source` | `http://terminology.hl7.org/` |
| Encounter Class | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/encounter-class` |
| Encounter Class | `skos:closeMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.class` |
| Encounter Class | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActCode` |
| Encounter Class | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-mogsgkfr8h5hk18jvqysphpq` |
| Encounter Priority | `dcterms:publisher` | `https://axius-sdc.com` |
| Encounter Priority | `dcterms:source` | `http://terminology.hl7.org/` |
| Encounter Priority | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/encounter-priority` |
| Encounter Priority | `skos:closeMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.priority` |
| Encounter Priority | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActPriority` |
| Encounter Priority | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bf6yz6dbpwau77wke189an3c` |
| Encounter Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Encounter Status | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Encounter Status | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/encounter-status` |
| Encounter Status | `skos:closeMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.status` |
| Encounter Status | `skos:exactMatch` | `http://hl7.org/fhir/encounter-status` |
| Encounter Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yq8mjdfv83g4l9cauiwxaxof` |
| Encounter Length | `dcterms:publisher` | `https://axius-sdc.com` |
| Encounter Length | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Encounter Length | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/encounter-length` |
| Encounter Length | `skos:exactMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.length` |
| Encounter Length | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-y2bp9qn2xbkpnyj4el6489bs` |
| Encounter End | `dcterms:publisher` | `https://axius-sdc.com` |
| Encounter End | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Encounter End | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/encounter-end` |
| Encounter End | `skos:exactMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.period.end` |
| Encounter End | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-q2f2ixoppgfbosedoytboovu` |
| Encounter Start | `dcterms:publisher` | `https://axius-sdc.com` |
| Encounter Start | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Encounter Start | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/encounter-start` |
| Encounter Start | `skos:exactMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.period.start` |
| Encounter Start | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-n0nymcfopzp382j8kc6t3k2z` |
| Encounter Reason (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Encounter Reason (SNOMED CT) | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Encounter Reason (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/encounter-reason` |
| Encounter Reason (SNOMED CT) | `skos:closeMatch` | `http://snomed.info/sct` |
| Encounter Reason (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.reasonCode` |
| Code System: SNOMED CT | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: SNOMED CT | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/system-snomed` |
| Code System: SNOMED CT | `skos:exactMatch` | `http://snomed.info/sct` |
| Code System: SNOMED CT | `dcterms:source` | `http://snomed.info/sct` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Encounter Reason Code (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Encounter Reason Code (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/encounter-reason-code` |
| Encounter Reason Code (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.reasonCode` |
| Encounter Reason Code (SNOMED CT) | `skos:exactMatch` | `http://snomed.info/sct` |
| Encounter Reason Code (SNOMED CT) | `dcterms:source` | `http://snomed.info/sct` |
| Encounter Reason Code (SNOMED CT) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-s7dqnduaqd5go4ztlhai2uzs` |
| Hospitalization | `dcterms:publisher` | `https://axius-sdc.com` |
| Hospitalization | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Hospitalization | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/hospitalization` |
| Hospitalization | `skos:exactMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.hospitalization` |
| Hospitalization | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qxa1fowjvhe4zb0xbdxnf4yc` |
| Admit Source | `dcterms:publisher` | `https://axius-sdc.com` |
| Admit Source | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Admit Source | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/admit-source` |
| Admit Source | `skos:closeMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.hospitalization.admitSource` |
| Admit Source | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/admit-source` |
| Admit Source | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-d6fhrxgpx4yrg0wyqu29ryvv` |
| Discharge Disposition | `dcterms:publisher` | `https://axius-sdc.com` |
| Discharge Disposition | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Discharge Disposition | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/discharge-disposition` |
| Discharge Disposition | `skos:closeMatch` | `http://hl7.org/fhir/R4/encounter-definitions.html#Encounter.hospitalization.dischargeDisposition` |
| Discharge Disposition | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/discharge-disposition` |
| Discharge Disposition | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-t7iyfamfrzty7ev82gl15w4g` |
| PROV Activity | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Activity | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-activity` |
| PROV Activity | `skos:exactMatch` | `http://www.w3.org/ns/prov#Activity` |
| PROV Activity | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-description` |
| Activity Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Activity Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-m9xg6e182m1oq77ssrf9iujv` |
| Activity Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-identifier` |
| Activity Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Activity Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fpnn1dew0kcevc8ptohndc5t` |
| Activity Label | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Label | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-label` |
| Activity Label | `skos:exactMatch` | `http://www.w3.org/2000/01/rdf-schema#label` |
| Activity Label | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Label | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-n4kaez29vbknku2jy8n56gfm` |
| Activity Location | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Location | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-location` |
| Activity Location | `skos:exactMatch` | `http://www.w3.org/ns/prov#atLocation` |
| Activity Location | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Location | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ciuklf1kl8bphpudye4i47am` |
| Activity Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-type` |
| Activity Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#type` |
| Activity Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ceusvbe55b266gcdzf5qnurc` |
| Error Message | `dcterms:publisher` | `https://axius-sdc.com` |
| Error Message | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/error-message` |
| Error Message | `dcterms:source` | `https://schema.org/` |
| Error Message | `skos:exactMatch` | `https://schema.org/error` |
| Error Message | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-eakhqr9l9nbblppgxc5fq25n` |
| Had Plan Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Had Plan Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/had-plan-reference` |
| Had Plan Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#hadPlan` |
| Had Plan Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Had Plan Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-xvdfh1nzfar33yxmgl3jgvqo` |
| Used Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Used Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/used-entity-reference` |
| Used Entity Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#used` |
| Used Entity Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Used Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ixv0fa8xlde52mdeymr4zaka` |
| Was Associated With Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Associated With Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-associated-with-reference` |
| Was Associated With Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasAssociatedWith` |
| Was Associated With Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Associated With Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gs0e1hp2rpjl6qfg9v8d047f` |
| Was Ended By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Ended By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-ended-by-reference` |
| Was Ended By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasEndedBy` |
| Was Ended By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Ended By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-jr1e3n5kg31nqz1ynh28kitp` |
| Was Informed By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Informed By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-informed-by-reference` |
| Was Informed By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasInformedBy` |
| Was Informed By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Informed By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rz60y6aujd274j4i7jpyxvpr` |
| Was Started By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Started By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-started-by-reference` |
| Was Started By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasStartedBy` |
| Was Started By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Started By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kmodjk1e5xu9z94zgiaxx1hu` |
| Activity Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Status | `dcterms:source` | `https://w3id.org/dpv` |
| Activity Status | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-status` |
| Activity Status | `skos:closeMatch` | `https://w3id.org/dpv#ActivityStatus` |
| Activity Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yehcpzf43j0b5zp9ck59t9eg` |
| Ended At | `dcterms:publisher` | `https://axius-sdc.com` |
| Ended At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/ended-at-time` |
| Ended At | `skos:exactMatch` | `http://www.w3.org/ns/prov#endedAtTime` |
| Ended At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Started At | `dcterms:publisher` | `https://axius-sdc.com` |
| Started At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/started-at-time` |
| Started At | `skos:exactMatch` | `http://www.w3.org/ns/prov#startedAtTime` |
| Started At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent` |
| PROV Agent | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Acted On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/acted-on-behalf-of-reference` |
| Acted On Behalf Of Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#actedOnBehalfOf` |
| Acted On Behalf Of Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dce4w62jxjngjnmc5y26fq66` |
| Agent Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-description` |
| Agent Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Agent Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w79xppnskig5vq31er8gh7nk` |
| Agent Email | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Email | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-email` |
| Agent Email | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/mbox` |
| Agent Email | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Email | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yp6pm5xyovxhkjimrrb8h9xy` |
| Agent Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-identifier` |
| Agent Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Agent Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hhfnj5hd1yzt252jfq5pdjj1` |
| Agent Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-name` |
| Agent Name | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/name` |
| Agent Name | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yya0pdgjd2w0wlz5r3h516om` |
| Agent Organization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Organization Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-organization-name` |
| Agent Organization Name | `dcterms:source` | `https://schema.org/` |
| Agent Organization Name | `skos:exactMatch` | `https://schema.org/legalName` |
| Agent Organization Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ifw5zfe4oiijbxjn1ylc2wm3` |
| Software Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-name` |
| Software Name | `dcterms:source` | `https://schema.org/` |
| Software Name | `skos:exactMatch` | `https://schema.org/SoftwareApplication` |
| Software Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rsjfjz8m5z7a58h5793duqbs` |
| Software Version | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Version | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-version` |
| Software Version | `dcterms:source` | `https://schema.org/` |
| Software Version | `skos:exactMatch` | `https://schema.org/softwareVersion` |
| Software Version | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tep9wanrrtqfw0k76huv6tvd` |
| PROV Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent-type` |
| PROV Agent Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-nesxtz8c5o665swc9lhvqkjj` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "CMS Outpatient Claim" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-mllwhe842wtnim4ms48qonio.xsd)
- Example instance (dm-mllwhe842wtnim4ms48qonio.xml)
- HTML documentation (dm-mllwhe842wtnim4ms48qonio.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"CMS Outpatient Claim" SDC4 schema (dm-mllwhe842wtnim4ms48qonio.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"CMS Outpatient Claim" schema (dm-mllwhe842wtnim4ms48qonio.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "CMS Outpatient Claim" SDC4 schema (dm-mllwhe842wtnim4ms48qonio.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "CMS Outpatient Claim" data model (dm-mllwhe842wtnim4ms48qonio.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-mllwhe842wtnim4ms48qonio.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-mllwhe842wtnim4ms48qonio.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-mllwhe842wtnim4ms48qonio.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-mllwhe842wtnim4ms48qonio.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-mllwhe842wtnim4ms48qonio.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
