# NHANES — Blood Pressure

**Model ID**: `dm-r3gyip9ebl7ockdpj4kwabjo`
**Project**: FAIR Data Demo
**Description**: SDC4 data model for National Health and Nutrition Examination Survey (nhanes_blood_pressure) — FAIR Data Demo

### Dublin Core Metadata
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal

## Package Contents

- `dm-r3gyip9ebl7ockdpj4kwabjo.xsd` -- XML Schema Definition (data model structure)
- `dm-r3gyip9ebl7ockdpj4kwabjo.xml` -- XML instance example with sample data
- `dm-r3gyip9ebl7ockdpj4kwabjo-instance.json` -- JSON instance example (same structure as XML)
- `dm-r3gyip9ebl7ockdpj4kwabjo.jsonld` -- JSON-LD semantic schema description
- `dm-r3gyip9ebl7ockdpj4kwabjo.html` -- Human-readable model documentation
- `dm-r3gyip9ebl7ockdpj4kwabjo_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-r3gyip9ebl7ockdpj4kwabjo.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-r3gyip9ebl7ockdpj4kwabjo.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-r3gyip9ebl7ockdpj4kwabjo.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-r3gyip9ebl7ockdpj4kwabjo.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **nhanes-blood-pressure** | Cluster | `fha5l173r195kdvwcg59753k` | 11 components |
|   Dependent Sequence Number | XdString | `bxpnk5cd59ghc0xw2aswgjze` | maxLen=9 |
|   Blood Pressure Device | XdToken | `o7rh6eamxdcdd1dp6qsho558` | 3 enum(s) |
|   Diastolic Blood Pressure | XdCount | `b0qfvgagjyebeuizpe900a93` | units=mmHg |
|   Pulse Pressure | XdCount | `cmxx2gdv9ivg6l1eutaa2eij` | units=mmHg |
|   Systolic Blood Pressure | XdCount | `v15kv8dnd9th63hmccqetmki` | units=mmHg |
|   60 sec HR (30 sec HR * 2) | XdQuantity | `jygdqqncec7ssmtm4shgadli` | units=BPXCHR_units |
|   60 sec. pulse (30 sec. pulse * 2) | XdQuantity | `x747pjmrj88farwsmxqzvqxm` | units=BPXPLS_units |
|   Arm selected | XdQuantity | `o7sn9ypj5u8qsjapo3v5b6df` | units=BPAARM_units |
|   Coded cuff size | XdQuantity | `zb0h147ogifwrbm6891m3qcp` | units=BPACSZ_units |
|   MIL: maximum inflation levels (mm Hg) | XdQuantity | `lgzkb3bg6a5zu6lkfs0biwiu` | units=BPXML1_units |
|   Current Meter Reading | XdQuantity | `yocg1i1shwncgccuu2czoknz` | units=Count (Each) |

## Structural Hierarchy

```
DM: NHANES — Blood Pressure
  [Cluster] nhanes-blood-pressure
    [XdString] Dependent Sequence Number
    [XdToken] Blood Pressure Device
    [XdCount] Diastolic Blood Pressure
    [XdCount] Pulse Pressure
    [XdCount] Systolic Blood Pressure
    [XdQuantity] 60 sec HR (30 sec HR * 2)
    [XdQuantity] 60 sec. pulse (30 sec. pulse * 2)
    [XdQuantity] Arm selected
    [XdQuantity] Coded cuff size
    [XdQuantity] MIL: maximum inflation levels (mm Hg)
    [XdQuantity] Current Meter Reading
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| nhanes-blood-pressure | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1967281` |
| Dependent Sequence Number | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q29635268` |
| Dependent Sequence Number | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1061489` |
| Blood Pressure Device | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q73466793` |
| Blood Pressure Device | `skos:exactMatch` | `https://schema.org/DefinedTermSet` |
| Blood Pressure Device | `rdf:type` | `http://www.w3.org/2004/02/skos/core#ConceptScheme` |
| Diastolic Blood Pressure | `rdfs:isDefinedBy` | `https://professional.heart.org/en/science-news/2017-hypertension-clinical-guidelines` |
| Diastolic Blood Pressure | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q82642` |
| Diastolic Blood Pressure | `rdf:type` | `https://schema.org/Integer` |
| Pulse Pressure | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1759415` |
| Pulse Pressure | `rdf:type` | `https://schema.org/Integer` |
| Systolic Blood Pressure | `rdfs:isDefinedBy` | `https://professional.heart.org/en/science-news/2017-hypertension-clinical-guidelines` |
| Systolic Blood Pressure | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q82642` |
| Systolic Blood Pressure | `rdf:type` | `https://schema.org/Integer` |
| 60 sec HR (30 sec HR * 2) | `skos:exactMatch` | `https://loinc.org/8867-4` |
| 60 sec HR (30 sec HR * 2) | `rdfs:isDefinedBy` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| 60 sec HR (30 sec HR * 2) | `dcterms:subject` | `http://snomed.info/id/46973005` |
| 60 sec HR (30 sec HR * 2) | `skos:closeMatch` | `http://snomed.info/id/364075005` |
| 60 sec. pulse (30 sec. pulse * 2) | `skos:exactMatch` | `https://loinc.org/8867-4` |
| 60 sec. pulse (30 sec. pulse * 2) | `rdfs:isDefinedBy` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| 60 sec. pulse (30 sec. pulse * 2) | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q43788543` |
| 60 sec. pulse (30 sec. pulse * 2) | `dcterms:subject` | `http://snomed.info/id/46973005` |
| Arm selected | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q41774743` |
| Arm selected | `rdfs:isDefinedBy` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Arm selected | `dcterms:subject` | `http://snomed.info/id/46973005` |
| Coded cuff size | `rdfs:isDefinedBy` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Coded cuff size | `rdfs:isDefinedBy` | `https://schema.org/size` |
| Coded cuff size | `dcterms:subject` | `http://snomed.info/id/46973005` |
| MIL: maximum inflation levels (mm Hg) | `rdfs:isDefinedBy` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| MIL: maximum inflation levels (mm Hg) | `skos:closeMatch` | `http://snomed.info/id/46973005` |
| MIL: maximum inflation levels (mm Hg) | `dcterms:subject` | `http://snomed.info/id/46973005` |
| Current Meter Reading | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q315065` |
| Current Meter Reading | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1061489` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "NHANES — Blood Pressure" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-r3gyip9ebl7ockdpj4kwabjo.xsd)
- Example instance (dm-r3gyip9ebl7ockdpj4kwabjo.xml)
- HTML documentation (dm-r3gyip9ebl7ockdpj4kwabjo.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"NHANES — Blood Pressure" SDC4 schema (dm-r3gyip9ebl7ockdpj4kwabjo.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"NHANES — Blood Pressure" schema (dm-r3gyip9ebl7ockdpj4kwabjo.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "NHANES — Blood Pressure" SDC4 schema (dm-r3gyip9ebl7ockdpj4kwabjo.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "NHANES — Blood Pressure" data model (dm-r3gyip9ebl7ockdpj4kwabjo.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-r3gyip9ebl7ockdpj4kwabjo.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-r3gyip9ebl7ockdpj4kwabjo.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-r3gyip9ebl7ockdpj4kwabjo.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-r3gyip9ebl7ockdpj4kwabjo.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-r3gyip9ebl7ockdpj4kwabjo.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
