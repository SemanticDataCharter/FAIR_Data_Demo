"""
Django app configuration for nhanes_—_medications.
"""
from django.apps import AppConfig


class Nhanes_—_medicationsConfig(AppConfig):
    """App configuration for nhanes_—_medications."""

    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nhanes_—_medications'

    def ready(self):
        """
        Import signals when app is ready.

        This ensures that signal handlers are registered when Django starts.
        """
        import nhanes_—_medications.signals  # noqa: F401
