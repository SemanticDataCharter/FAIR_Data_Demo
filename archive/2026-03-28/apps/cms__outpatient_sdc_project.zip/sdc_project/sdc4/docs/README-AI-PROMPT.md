# CMS — Outpatient

**Model ID**: `dm-k6f8kugg359vc6ew75ulojg9`
**Project**: FAIR Data Demo
**Description**: SDC4 data model for CMS DE-SynPUF (Medicare Claims Synthetic Data) (cms_outpatient) — FAIR Data Demo

### Dublin Core Metadata
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal

## Package Contents

- `dm-k6f8kugg359vc6ew75ulojg9.xsd` -- XML Schema Definition (data model structure)
- `dm-k6f8kugg359vc6ew75ulojg9.xml` -- XML instance example with sample data
- `dm-k6f8kugg359vc6ew75ulojg9-instance.json` -- JSON instance example (same structure as XML)
- `dm-k6f8kugg359vc6ew75ulojg9.jsonld` -- JSON-LD semantic schema description
- `dm-k6f8kugg359vc6ew75ulojg9.html` -- Human-readable model documentation
- `dm-k6f8kugg359vc6ew75ulojg9_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-k6f8kugg359vc6ew75ulojg9.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-k6f8kugg359vc6ew75ulojg9.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-k6f8kugg359vc6ew75ulojg9.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-k6f8kugg359vc6ew75ulojg9.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **cms-outpatient** | Cluster | `rsg9ml37moqualgtlyesc2yo` | 76 components |
|   Admitting Diagnosis Code (ICD-9-CM) | XdString | `byet7dbnt5w4jzy026i1ra0r` | minLen=1; maxLen=200 |
|   Beneficiary Code | XdString | `qeqb0siehg15s5megtj1rbk8` | minLen=1; maxLen=50 |
|   HCPCS Code 1 | XdString | `c6g82ede8bot57v1mhdsp9wk` | minLen=1; maxLen=200 |
|   HCPCS Code 10 | XdString | `eqoy4zpynvzmblre7wtzredn` | minLen=1; maxLen=200 |
|   HCPCS Code 11 | XdString | `wachpi4ue78b2ztq44jigszo` | minLen=1; maxLen=200 |
|   HCPCS Code 12 | XdString | `o9m5xx8tq2b83unyh49u6k6u` | minLen=1; maxLen=200 |
|   HCPCS Code 13 | XdString | `nqsvl2pycziolhybm5kzuqye` | minLen=1; maxLen=200 |
|   HCPCS Code 14 | XdString | `uiexdes629e02edfn1tc7x63` | minLen=1; maxLen=200 |
|   HCPCS Code 15 | XdString | `jksr7pkne10b4btkxyheyuhh` | minLen=1; maxLen=200 |
|   HCPCS Code 16 | XdString | `pev6q1k5v4d2cvedj23mazxo` | minLen=1; maxLen=200 |
|   HCPCS Code 17 | XdString | `wc94hlj7j7q8bxrmjc1pg3fb` | minLen=1; maxLen=200 |
|   HCPCS Code 18 | XdString | `x3yxwzpjh3ceprrxsm0035ev` | minLen=1; maxLen=200 |
|   HCPCS Code 19 | XdString | `a83fiza24m2by4ums4cpcwn8` | minLen=1; maxLen=200 |
|   HCPCS Code 2 | XdString | `dtrwu350p9ra8s420zdo6dzx` | minLen=1; maxLen=200 |
|   HCPCS Code 20 | XdString | `b88sdksofh7btwthe9756oby` | minLen=1; maxLen=200 |
|   HCPCS Code 21 | XdString | `o8o2kek3gd45ujfr6apl7r5v` | minLen=1; maxLen=200 |
|   HCPCS Code 22 | XdString | `hf7unnab1lweprsoquguvbhw` | minLen=1; maxLen=200 |
|   HCPCS Code 23 | XdString | `ggew4rc7or575evxvjyuemml` | minLen=1; maxLen=200 |
|   HCPCS Code 25 | XdString | `n576f9btn2b6b75xbzj90xmn` | minLen=1; maxLen=200 |
|   HCPCS Code 28 | XdString | `x41t3gy1xebzcxz9da0td0wj` | minLen=1; maxLen=200 |
|   HCPCS Code 3 | XdString | `y6uzjl22ukembruwtouk8qwl` | minLen=1; maxLen=200 |
|   HCPCS Code 30 | XdString | `qlacp174k7z5n56wrvo49v6u` | minLen=1; maxLen=200 |
|   HCPCS Code 31 | XdString | `q2i4tobxjv45lt0bdnh6upu7` | minLen=1; maxLen=200 |
|   HCPCS Code 36 | XdString | `y3dvjqqbt2fg3hfh0xo2ci48` | minLen=1; maxLen=200 |
|   HCPCS Code 37 | XdString | `z8fmnbd0cq9alk1ccoi4tab8` | minLen=1; maxLen=200 |
|   HCPCS Code 4 | XdString | `z52ts5413a73cm8r5prnfrtz` | minLen=1; maxLen=200 |
|   HCPCS Code 41 | XdString | `ierah40okii9d12w6xily3f3` | minLen=1; maxLen=200 |
|   HCPCS Code 42 | XdString | `ublff1qvjrzby4thdmajr0ou` | minLen=1; maxLen=200 |
|   HCPCS Code 44 | XdString | `dh67y1qy9vxry9orfcfr59ui` | minLen=1; maxLen=200 |
|   HCPCS Code 45 | XdString | `zj1qfezmo6v5i6wdy2ec3m1m` | minLen=1; maxLen=200 |
|   HCPCS Code 6 | XdString | `e2vchho4c4sqwlecpa233wc1` | minLen=1; maxLen=200 |
|   HCPCS Code 7 | XdString | `r66dx3zr363e6nusgn5bnivy` | minLen=1; maxLen=200 |
|   HCPCS Code 8 | XdString | `wmh1u8whaxczqdiwk3ibn2j2` | minLen=1; maxLen=200 |
|   HCPCS Code 9 | XdString | `iilb4o78sfhtm57o1lcg7oaj` | minLen=1; maxLen=200 |
|   ICD-9-CM Diagnosis Code 1 | XdString | `h2qmxy3eg8z2tbjpdv72i88s` | minLen=1; maxLen=200 |
|   ICD-9-CM Diagnosis Code 2 | XdString | `xqzv440kq21libnr35norscf` | minLen=1; maxLen=200 |
|   ICD-9-CM Diagnosis Code 3 | XdString | `nfbphildqp54672gyzzcjl4x` | minLen=1; maxLen=200 |
|   ICD-9-CM Diagnosis Code 4 | XdString | `gbnlnwceh9nj0uc0klkhc42w` | minLen=1; maxLen=200 |
|   ICD-9-CM Diagnosis Code 5 | XdString | `me15caiqjhwjoygt9vtm7ux5` | minLen=1; maxLen=200 |
|   ICD-9-CM Diagnosis Code 6 | XdString | `bszrtosi43ipepmk6vejrvkf` | minLen=1; maxLen=200 |
|   ICD-9-CM Diagnosis Code 7 | XdString | `n48x3erx8tw7mcrmq9vfr6c6` | minLen=1; maxLen=200 |
|   ICD-9-CM Diagnosis Code 8 | XdString | `gq1yxmndkr0w5x0kuf86qxa7` | minLen=1; maxLen=200 |
|   ICD-9-CM Procedure Code 2 | XdString | `mg6dmqlur3wbv7qtlwtzg9df` | minLen=1; maxLen=200 |
|   ICD-9-CM Procedure Code 3 | XdString | `fxehuqw4eh94vo2rzo449172` | minLen=1; maxLen=200 |
|   ICD-9-CM Procedure Code 4 | XdString | `lsb4gj0w05u6kv7oog7lv9zu` | minLen=1; maxLen=200 |
|   ICD9_DGNS_CD_10 (duplicate label) | XdString | `h3hehrlo5zbiedfmva6aw8v8` | minLen=1; maxLen=200 |
|   ICD9_PRCDR_CD_1 (duplicate label) | XdString | `r3lgrusha3kzugs923vdc9dd` | minLen=1; maxLen=200 |
|   ICD9_PRCDR_CD_5 (duplicate label) | XdString | `hgly59s8t8wukcl142chc7ax` | minLen=1; maxLen=200 |
|   ICD9_PRCDR_CD_6 (duplicate label) | XdString | `qz2pyzv4b8thxm82l38kzfb2` | minLen=1; maxLen=200 |
|   Provider Institution Number | XdString | `hmms66svrt1ihiue1s8d4wgl` | minLen=1; maxLen=200 |
|   Attending Physician NPI | XdCount | `oxf8o3fv3f2qb02fzdm5vb37` | units=AT_PHYSN_NPI_units |
|   Claim ID | XdCount | `r0j15xm8h3qf7c2159lilkfz` | units=CLM_ID_units |
|   Claims End Date | XdCount | `k9y6cjmb6i3td87pg51bpgwj` | units=CLM_THRU_DT_units |
|   Claims Start Date | XdCount | `ydx9s8vc3mkm6xl2ghk2u71a` | units=CLM_FROM_DT_units |
|   HCPCS_CD_24 (duplicate label) | XdCount | `piixyffc72zluvupku9rjngw` | units=HCPCS_CD_24_units |
|   HCPCS_CD_26 (duplicate label) | XdCount | `f9td31zp14lf2zwbtw4bcrbx` | units=HCPCS_CD_26_units |
|   HCPCS_CD_27 (duplicate label) | XdCount | `jor22hzapzva8mn0xmit2ifl` | units=HCPCS_CD_27_units |
|   HCPCS_CD_29 (duplicate label) | XdCount | `qj106tovelir2rqz5vf59ldr` | units=HCPCS_CD_29_units |
|   HCPCS_CD_32 (duplicate label) | XdCount | `xy1i1wzwrtvzns1iqimr3xy5` | units=HCPCS_CD_32_units |
|   HCPCS_CD_33 (duplicate label) | XdCount | `l8070v0ceogx8cvrfpqmoymp` | units=HCPCS_CD_33_units |
|   HCPCS_CD_34 (duplicate label) | XdCount | `bl9xra4q7r9d0iionsgxzql4` | units=HCPCS_CD_34_units |
|   HCPCS_CD_35 (duplicate label) | XdCount | `fnwfb61x0cw9atshp12wm6tf` | units=HCPCS_CD_35_units |
|   HCPCS_CD_38 (duplicate label) | XdCount | `qg0nsyz1n43q4yuxf0mxjxot` | units=HCPCS_CD_38_units |
|   HCPCS_CD_39 (duplicate label) | XdCount | `z0ws00oj3zj620bg3q3r1ewv` | units=HCPCS_CD_39_units |
|   HCPCS_CD_40 (duplicate label) | XdCount | `ll5ui05hda7pi42ib2e42ie3` | units=HCPCS_CD_40_units |
|   HCPCS_CD_43 (duplicate label) | XdCount | `s4eqjfu26lmro8pm2qqkmhy0` | units=HCPCS_CD_43_units |
|   HCPCS_CD_5 (duplicate label) | XdCount | `zf9v0w0c5vtzlck15pd13anq` | units=HCPCS_CD_5_units |
|   ICD9_DGNS_CD_9 (duplicate label) | XdCount | `da0r7x0tvbgrbp0n4eyy8k0u` | units=ICD9_DGNS_CD_9_units |
|   Operating Physician NPI | XdCount | `nq1us0z45fvjpa7pi0lxx2r4` | units=OP_PHYSN_NPI_units |
|   Other Physician NPI | XdCount | `gar0akj5prixv8lqcd1zrb17` | units=OT_PHYSN_NPI_units |
|   SEGMENT (duplicate label) | XdCount | `a2tag43yf695zvtmnc6pxzjn` | units=SEGMENT_units |
|   Blood Deductible Liability Amount | XdQuantity | `cyr76x1s3bu5dzdewetc8gv8` | units=NCH_BENE_BLOOD_DDCTBL_LBLTY_AM_units |
|   Claim Payment Amount | XdQuantity | `b7wqs85a0zfe76e23m40djap` | units=CLM_PMT_AMT_units |
|   Part B Coinsurance Amount | XdQuantity | `ytjmfsqg2yrwi6r6gwcgg0k1` | units=NCH_BENE_PTB_COINSRNC_AMT_units |
|   Part B Deductible Amount | XdQuantity | `lt6gjz0ljidgd52dj6jmt84p` | units=NCH_BENE_PTB_DDCTBL_AMT_units |
|   Primary Payer Claim Paid Amount | XdQuantity | `gp8pll5nz09c494ffc228z7g` | units=NCH_PRMRY_PYR_CLM_PD_AMT_units |

## Structural Hierarchy

```
DM: CMS — Outpatient
  [Cluster] cms-outpatient
    [XdString] Admitting Diagnosis Code (ICD-9-CM)
    [XdString] Beneficiary Code
    [XdString] HCPCS Code 1
    [XdString] HCPCS Code 10
    [XdString] HCPCS Code 11
    [XdString] HCPCS Code 12
    [XdString] HCPCS Code 13
    [XdString] HCPCS Code 14
    [XdString] HCPCS Code 15
    [XdString] HCPCS Code 16
    [XdString] HCPCS Code 17
    [XdString] HCPCS Code 18
    [XdString] HCPCS Code 19
    [XdString] HCPCS Code 2
    [XdString] HCPCS Code 20
    [XdString] HCPCS Code 21
    [XdString] HCPCS Code 22
    [XdString] HCPCS Code 23
    [XdString] HCPCS Code 25
    [XdString] HCPCS Code 28
    [XdString] HCPCS Code 3
    [XdString] HCPCS Code 30
    [XdString] HCPCS Code 31
    [XdString] HCPCS Code 36
    [XdString] HCPCS Code 37
    [XdString] HCPCS Code 4
    [XdString] HCPCS Code 41
    [XdString] HCPCS Code 42
    [XdString] HCPCS Code 44
    [XdString] HCPCS Code 45
    [XdString] HCPCS Code 6
    [XdString] HCPCS Code 7
    [XdString] HCPCS Code 8
    [XdString] HCPCS Code 9
    [XdString] ICD-9-CM Diagnosis Code 1
    [XdString] ICD-9-CM Diagnosis Code 2
    [XdString] ICD-9-CM Diagnosis Code 3
    [XdString] ICD-9-CM Diagnosis Code 4
    [XdString] ICD-9-CM Diagnosis Code 5
    [XdString] ICD-9-CM Diagnosis Code 6
    [XdString] ICD-9-CM Diagnosis Code 7
    [XdString] ICD-9-CM Diagnosis Code 8
    [XdString] ICD-9-CM Procedure Code 2
    [XdString] ICD-9-CM Procedure Code 3
    [XdString] ICD-9-CM Procedure Code 4
    [XdString] ICD9_DGNS_CD_10 (duplicate label)
    [XdString] ICD9_PRCDR_CD_1 (duplicate label)
    [XdString] ICD9_PRCDR_CD_5 (duplicate label)
    [XdString] ICD9_PRCDR_CD_6 (duplicate label)
    [XdString] Provider Institution Number
    [XdCount] Attending Physician NPI
    [XdCount] Claim ID
    [XdCount] Claims End Date
    [XdCount] Claims Start Date
    [XdCount] HCPCS_CD_24 (duplicate label)
    [XdCount] HCPCS_CD_26 (duplicate label)
    [XdCount] HCPCS_CD_27 (duplicate label)
    [XdCount] HCPCS_CD_29 (duplicate label)
    [XdCount] HCPCS_CD_32 (duplicate label)
    [XdCount] HCPCS_CD_33 (duplicate label)
    [XdCount] HCPCS_CD_34 (duplicate label)
    [XdCount] HCPCS_CD_35 (duplicate label)
    [XdCount] HCPCS_CD_38 (duplicate label)
    [XdCount] HCPCS_CD_39 (duplicate label)
    [XdCount] HCPCS_CD_40 (duplicate label)
    [XdCount] HCPCS_CD_43 (duplicate label)
    [XdCount] HCPCS_CD_5 (duplicate label)
    [XdCount] ICD9_DGNS_CD_9 (duplicate label)
    [XdCount] Operating Physician NPI
    [XdCount] Other Physician NPI
    [XdCount] SEGMENT (duplicate label)
    [XdQuantity] Blood Deductible Liability Amount
    [XdQuantity] Claim Payment Amount
    [XdQuantity] Part B Coinsurance Amount
    [XdQuantity] Part B Deductible Amount
    [XdQuantity] Primary Payer Claim Paid Amount
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| cms-outpatient | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q569500` |
| Admitting Diagnosis Code (ICD-9-CM) | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Admitting Diagnosis Code (ICD-9-CM) | `dcterms:subject` | `http://snomed.info/id/32485007` |
| Admitting Diagnosis Code (ICD-9-CM) | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Beneficiary Code | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Beneficiary Code | `rdfs:isDefinedBy` | `https://w3id.org/semanticarts/ns/ontology/gist/ID` |
| Beneficiary Code | `dcterms:subject` | `http://snomed.info/id/184102003` |
| HCPCS Code 1 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/femtometre` |
| HCPCS Code 1 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 1 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 10 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/femtometre` |
| HCPCS Code 10 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 10 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 11 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 11 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 11 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 12 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/picometre` |
| HCPCS Code 12 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 12 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 13 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 13 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 13 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 14 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 14 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 14 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 15 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/femtometre` |
| HCPCS Code 15 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 15 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 16 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 16 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 16 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 17 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 17 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 17 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 18 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 18 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 18 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 19 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 19 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 19 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 2 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 2 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/NumberBotrytis2` |
| HCPCS Code 2 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 20 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 20 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 20 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 21 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/zettagram` |
| HCPCS Code 21 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 21 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 22 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 22 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 22 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 23 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 23 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/perm-23C` |
| HCPCS Code 23 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 25 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 25 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 25 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 28 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 28 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 28 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 3 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 3 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/NumberBotrytis3` |
| HCPCS Code 3 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 30 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 30 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 30 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 31 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 31 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 31 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 36 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 36 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 36 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 37 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 37 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 37 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 4 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 4 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/NumberBotrytis4` |
| HCPCS Code 4 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 41 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 41 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 41 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 42 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 42 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 42 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 44 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 44 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 44 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 45 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 45 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 45 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 6 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 6 | `rdfs:isDefinedBy` | `https://schema.org/iso6523Code` |
| HCPCS Code 6 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 7 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/BudStadiumDay7` |
| HCPCS Code 7 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 7 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 8 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 8 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS Code 8 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| HCPCS Code 9 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/gigametre` |
| HCPCS Code 9 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HCPCS Code 9 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| ICD-9-CM Diagnosis Code 1 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/femtometre` |
| ICD-9-CM Diagnosis Code 1 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| ICD-9-CM Diagnosis Code 1 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| ICD-9-CM Diagnosis Code 2 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| ICD-9-CM Diagnosis Code 2 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/NumberBotrytis2` |
| ICD-9-CM Diagnosis Code 2 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| ICD-9-CM Diagnosis Code 3 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| ICD-9-CM Diagnosis Code 3 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/NumberBotrytis3` |
| ICD-9-CM Diagnosis Code 3 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| ICD-9-CM Diagnosis Code 4 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| ICD-9-CM Diagnosis Code 4 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/NumberBotrytis4` |
| ICD-9-CM Diagnosis Code 4 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| ICD-9-CM Diagnosis Code 5 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| ICD-9-CM Diagnosis Code 5 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/NumberManualFirmness0.5` |
| ICD-9-CM Diagnosis Code 5 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| ICD-9-CM Diagnosis Code 6 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| ICD-9-CM Diagnosis Code 6 | `rdfs:isDefinedBy` | `https://schema.org/iso6523Code` |
| ICD-9-CM Diagnosis Code 6 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| ICD-9-CM Diagnosis Code 7 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/BudStadiumDay7` |
| ICD-9-CM Diagnosis Code 7 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| ICD-9-CM Diagnosis Code 7 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| ICD-9-CM Diagnosis Code 8 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| ICD-9-CM Diagnosis Code 8 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| ICD-9-CM Diagnosis Code 8 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| ICD-9-CM Procedure Code 2 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| ICD-9-CM Procedure Code 2 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/NumberBotrytis2` |
| ICD-9-CM Procedure Code 2 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| ICD-9-CM Procedure Code 3 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| ICD-9-CM Procedure Code 3 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/NumberBotrytis3` |
| ICD-9-CM Procedure Code 3 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| ICD-9-CM Procedure Code 4 | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| ICD-9-CM Procedure Code 4 | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/NumberBotrytis4` |
| ICD-9-CM Procedure Code 4 | `dcterms:subject` | `http://snomed.info/id/32485007` |
| Provider Institution Number | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Provider Institution Number | `dcterms:subject` | `http://snomed.info/id/32485007` |
| Provider Institution Number | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Attending Physician NPI | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Attending Physician NPI | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q6975101` |
| Attending Physician NPI | `dcterms:subject` | `http://snomed.info/id/32485007` |
| Claim ID | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim ID | `rdfs:isDefinedBy` | `https://w3id.org/semanticarts/ns/ontology/gist/ID` |
| Claim ID | `dcterms:subject` | `http://snomed.info/id/32485007` |
| Claims End Date | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claims End Date | `dcterms:subject` | `http://snomed.info/id/32485007` |
| Claims End Date | `rdfs:isDefinedBy` | `sdc4:XdCountType/xdcount-value` |
| Claims Start Date | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claims Start Date | `rdfs:isDefinedBy` | `https://w3id.org/semanticarts/ns/ontology/gist/comesFromAgent` |
| Claims Start Date | `dcterms:subject` | `http://snomed.info/id/32485007` |
| HCPCS_CD_35 (duplicate label) | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q80806568` |
| Operating Physician NPI | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Operating Physician NPI | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q6975101` |
| Operating Physician NPI | `dcterms:subject` | `http://snomed.info/id/32485007` |
| Other Physician NPI | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Other Physician NPI | `dcterms:subject` | `http://snomed.info/id/32485007` |
| Other Physician NPI | `rdfs:isDefinedBy` | `sdc4:XdCountType/xdcount-value` |
| Blood Deductible Liability Amount | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Blood Deductible Liability Amount | `dcterms:subject` | `http://snomed.info/id/32485007` |
| Blood Deductible Liability Amount | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-units` |
| Claim Payment Amount | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Claim Payment Amount | `dcterms:subject` | `http://snomed.info/id/32485007` |
| Claim Payment Amount | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Part B Coinsurance Amount | `rdfs:isDefinedBy` | `https://schema.org/beneficiaryBank` |
| Part B Coinsurance Amount | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Part B Coinsurance Amount | `dcterms:subject` | `http://snomed.info/id/281685003` |
| Part B Deductible Amount | `rdfs:isDefinedBy` | `https://schema.org/beneficiaryBank` |
| Part B Deductible Amount | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Part B Deductible Amount | `dcterms:subject` | `http://snomed.info/id/281685003` |
| Primary Payer Claim Paid Amount | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Primary Payer Claim Paid Amount | `dcterms:subject` | `http://snomed.info/id/32485007` |
| Primary Payer Claim Paid Amount | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "CMS — Outpatient" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-k6f8kugg359vc6ew75ulojg9.xsd)
- Example instance (dm-k6f8kugg359vc6ew75ulojg9.xml)
- HTML documentation (dm-k6f8kugg359vc6ew75ulojg9.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"CMS — Outpatient" SDC4 schema (dm-k6f8kugg359vc6ew75ulojg9.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"CMS — Outpatient" schema (dm-k6f8kugg359vc6ew75ulojg9.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "CMS — Outpatient" SDC4 schema (dm-k6f8kugg359vc6ew75ulojg9.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "CMS — Outpatient" data model (dm-k6f8kugg359vc6ew75ulojg9.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-k6f8kugg359vc6ew75ulojg9.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-k6f8kugg359vc6ew75ulojg9.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-k6f8kugg359vc6ew75ulojg9.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-k6f8kugg359vc6ew75ulojg9.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-k6f8kugg359vc6ew75ulojg9.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
