"""
Django app configuration for nhanes_—_blood_pressure.
"""
from django.apps import AppConfig


class Nhanes_—_blood_pressureConfig(AppConfig):
    """App configuration for nhanes_—_blood_pressure."""

    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nhanes_—_blood_pressure'

    def ready(self):
        """
        Import signals when app is ready.

        This ensures that signal handlers are registered when Django starts.
        """
        import nhanes_—_blood_pressure.signals  # noqa: F401
