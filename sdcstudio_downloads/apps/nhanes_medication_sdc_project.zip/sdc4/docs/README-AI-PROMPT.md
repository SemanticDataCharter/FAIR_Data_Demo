# NHANES Medication

**Model ID**: `dm-epbdfmvxc3gbh5f66hhb3o2m`
**Project**: FAIR Data Demo
**Description**: SDC4 data model for National Health and Nutrition Examination Survey (nhanes_medications) — FAIR Data Demo

### Dublin Core Metadata
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal

## Package Contents

- `dm-epbdfmvxc3gbh5f66hhb3o2m.xsd` -- XML Schema Definition (data model structure)
- `dm-epbdfmvxc3gbh5f66hhb3o2m.xml` -- XML instance example with sample data
- `dm-epbdfmvxc3gbh5f66hhb3o2m-instance.json` -- JSON instance example (same structure as XML)
- `dm-epbdfmvxc3gbh5f66hhb3o2m.jsonld` -- JSON-LD semantic schema description
- `dm-epbdfmvxc3gbh5f66hhb3o2m.html` -- Human-readable model documentation
- `dm-epbdfmvxc3gbh5f66hhb3o2m_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-epbdfmvxc3gbh5f66hhb3o2m.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-epbdfmvxc3gbh5f66hhb3o2m.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-epbdfmvxc3gbh5f66hhb3o2m.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-epbdfmvxc3gbh5f66hhb3o2m.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **NHANES Medication Governed Record** | Cluster | `jo2kw48cijwgg64s6cud2el1` | 0 components; 4 sub-cluster(s) |
|   **Audit Event** | Cluster | `t2tvd3wylxrstdeu5aw6gkw1` | 13 components |
|     Audit Agent Reference | XdString | `dkc2ccj5te35z9gd4bu1blcq` | maxLen=2000; pattern=`\S+` |
|     Audit Entity Reference | XdString | `gcjyjrnp0wsfoelcp4m05c67` | maxLen=2000; pattern=`\S+` |
|     Audit Event Identifier | XdString | `fjhgr5fyqxt2crmg2cb5c513` | maxLen=255 |
|     Data Subject Reference | XdString | `sndpbhm3xbd6qtbyxmvh3i0e` | maxLen=2000; pattern=`\S+` |
|     On Behalf Of Reference | XdString | `nf1air1zbj8v9w66jozdxmyl` | maxLen=2000; pattern=`\S+` |
|     System Identifier | XdString | `h3kdbvdtyalpvik97saaf0an` | maxLen=255 |
|     System Location Name | XdString | `ujir739mf1g8ajeczs9nzh9m` | maxLen=255 |
|     Audit Event Action | XdToken | `ce1c8sydkov8bkv4dgdmwe5x` | 5 enum(s) |
|     Audit Event Outcome | XdToken | `rpz1czz06jhpahmfz30rblvp` | 4 enum(s) |
|     Confidentiality | XdToken | `vbctgmdcwps5b3r3l6sboa6y` | 6 enum(s) |
|     Provenance Agent Type | XdToken | `jujsdur1igws8orw6tvvlqco` | 13 enum(s) |
|     Purpose of Use | XdToken | `d1evlz8yvdlwt6ia9fjq4pgj` | 11 enum(s) |
|     Audit Recorded At | XdTemporal | `uwiosm2q9ym3ewr4de910s70` | -- |
|   **NHANES Medication** | Cluster | `ncudsi2t2ij3rd2pmnnfr2j9` | 6 components; 3 sub-cluster(s) |
|     Generic Drug Code (RXDDRGID) | XdString | `wypildaam8rrd87zkkjxl732` | maxLen=12 |
|     Generic Drug Name (RXDDRUG) | XdString | `lok5ozew80qmwah6h45jr69y` | maxLen=200 |
|     Respondent Sequence Number (SEQN) | XdString | `uto4zszvpicva38wx77knz5y` | maxLen=8; pattern=`[0-9]{5,6}` |
|     Taken Prescription Medicine, Past Month (RXDUSE) | XdToken | `a1zr74c1vayeeglk54da7gaf` | 2 enum(s) |
|     Number of Days Taken Medicine (RXDDAYS) | XdCount | `jwgah039kcz574bbjvpxvfdj` | units=Days |
|     Number of Prescription Medicines Taken (RXDCOUNT) | XdCount | `v28gzpjsaxkkgjm470icwipg` | units=Items |
|     **Medication Reason 1** | Cluster | `i213d6dp9r4c0nmzxkgc0tja` | 0 components; 1 sub-cluster(s) |
|       **Diagnosis (ICD-10-CM)** | Cluster | `jk4cboqk4me0yj2i04m8c2ad` | 3 components |
|         Code System: ICD-10-CM | XdLink | `jwgx8nvbtsim7ck4uqmpqyl2` | -- |
|         Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|         Diagnosis Code (ICD-10-CM) | XdString | `efimv7gxg5ompt8m6xb2b6k5` | maxLen=40; pattern=`[A-TV-Z][0-9][0-9AB](\.[0-9A-TV-Z]{1,4})?` |
|     **Medication Reason 2** | Cluster | `u3qz0js9emqn2i7s5nyynmgt` | 0 components; 1 sub-cluster(s) |
|     **Medication Reason 3** | Cluster | `rozfpmwczk4yuw4c2vom4gyx` | 0 components; 1 sub-cluster(s) |
|   **PROV Activity** | Cluster | `vmikfu0irht9fmq7q02t3oqs` | 15 components |
|     Activity Description | XdString | `hhusuzzig19rs46ngz23k5g7` | maxLen=4000 |
|     Activity Identifier | XdString | `wr06h54xqqw2q9id8i9673jy` | maxLen=255 |
|     Activity Label | XdString | `r6hkunjm2q0hlxiknlc9ljix` | maxLen=255 |
|     Activity Location | XdString | `uzai5uey5p1fnn9ezj9u6vor` | maxLen=255 |
|     Activity Type | XdString | `jjzmhdxvbt97pq81iwqubtxk` | maxLen=255 |
|     Error Message | XdString | `xlgjqdpwdbn2re3mdh5yy2rk` | maxLen=4000 |
|     Had Plan Reference | XdString | `vhezo2cckpe92x4c3j2memeh` | maxLen=2000; pattern=`\S+` |
|     Used Entity Reference | XdString | `t0whhrqtnb54te4mk48i1ooj` | maxLen=2000; pattern=`\S+` |
|     Was Associated With Reference | XdString | `r48alj7hc3797qfjnf2uj71n` | maxLen=2000; pattern=`\S+` |
|     Was Ended By Reference | XdString | `ueb5g1ojzlwwt0mnds5zb6wl` | maxLen=2000; pattern=`\S+` |
|     Was Informed By Reference | XdString | `qh84jdzp1kxt85aq4ilo0svk` | maxLen=2000; pattern=`\S+` |
|     Was Started By Reference | XdString | `ginfqbk7q59ld2r4us8sjnv1` | maxLen=2000; pattern=`\S+` |
|     Activity Status | XdToken | `wl6j4ekcmu4hvt2m12zw4zp8` | 6 enum(s) |
|     Ended At | XdTemporal | `a5scyosu6j84vz350mqyrzl2` | -- |
|     Started At | XdTemporal | `sa4nl1kbpdr842fkucvfjkpq` | -- |
|   **PROV Agent** | Cluster | `c179ilk2ns15cd5rzzdfd6f6` | 9 components |
|     Acted On Behalf Of Reference | XdString | `og08xf6bu928uuz6t3y0e23f` | maxLen=2000; pattern=`\S+` |
|     Agent Description | XdString | `gb78cmuyo72hqs5apymdki7l` | maxLen=4000 |
|     Agent Email | XdString | `qb90a0sp9vvb6c5cbcf236ys` | maxLen=255 |
|     Agent Identifier | XdString | `w2ruemcfy35rw60jl1t9dew2` | maxLen=255 |
|     Agent Name | XdString | `xxe21o9ojzmy9wxxky1tnmog` | maxLen=255 |
|     Agent Organization Name | XdString | `eftvwi5byq6cdtd931qyxzw0` | maxLen=255 |
|     Software Name | XdString | `aa663ivutjf2fs4757t0bbzy` | maxLen=255 |
|     Software Version | XdString | `x0lebwtobgaelj5pev3258sd` | maxLen=60 |
|     PROV Agent Type | XdToken | `i16vqj89it3db7d3c5qjko9p` | 3 enum(s) |

## Structural Hierarchy

```
DM: NHANES Medication
  [Cluster] NHANES Medication Governed Record
    [Cluster] Audit Event
      [XdString] Audit Agent Reference
      [XdString] Audit Entity Reference
      [XdString] Audit Event Identifier
      [XdString] Data Subject Reference
      [XdString] On Behalf Of Reference
      [XdString] System Identifier
      [XdString] System Location Name
      [XdToken] Audit Event Action
      [XdToken] Audit Event Outcome
      [XdToken] Confidentiality
      [XdToken] Provenance Agent Type
      [XdToken] Purpose of Use
      [XdTemporal] Audit Recorded At
    [Cluster] NHANES Medication
      [XdString] Generic Drug Code (RXDDRGID)
      [XdString] Generic Drug Name (RXDDRUG)
      [XdString] Respondent Sequence Number (SEQN)
      [XdToken] Taken Prescription Medicine, Past Month (RXDUSE)
      [XdCount] Number of Days Taken Medicine (RXDDAYS)
      [XdCount] Number of Prescription Medicines Taken (RXDCOUNT)
      [Cluster] Medication Reason 1
        [Cluster] Diagnosis (ICD-10-CM)
          [XdLink] Code System: ICD-10-CM
          [XdString] Code Display Text
          [XdString] Diagnosis Code (ICD-10-CM)
      [Cluster] Medication Reason 2
        [Cluster] Diagnosis (ICD-10-CM) (circular ref)
      [Cluster] Medication Reason 3
        [Cluster] Diagnosis (ICD-10-CM) (circular ref)
    [Cluster] PROV Activity
      [XdString] Activity Description
      [XdString] Activity Identifier
      [XdString] Activity Label
      [XdString] Activity Location
      [XdString] Activity Type
      [XdString] Error Message
      [XdString] Had Plan Reference
      [XdString] Used Entity Reference
      [XdString] Was Associated With Reference
      [XdString] Was Ended By Reference
      [XdString] Was Informed By Reference
      [XdString] Was Started By Reference
      [XdToken] Activity Status
      [XdTemporal] Ended At
      [XdTemporal] Started At
    [Cluster] PROV Agent
      [XdString] Acted On Behalf Of Reference
      [XdString] Agent Description
      [XdString] Agent Email
      [XdString] Agent Identifier
      [XdString] Agent Name
      [XdString] Agent Organization Name
      [XdString] Software Name
      [XdString] Software Version
      [XdToken] PROV Agent Type
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| NHANES Medication Governed Record | `dcterms:publisher` | `https://axius-sdc.com` |
| NHANES Medication Governed Record | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| NHANES Medication Governed Record | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-medication-governed-record` |
| NHANES Medication Governed Record | `skos:exactMatch` | `http://www.w3.org/ns/prov#Entity` |
| Audit Event | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event` |
| Audit Event | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/AuditEvent` |
| Audit Agent Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Agent Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Agent Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-agent-reference` |
| Audit Agent Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.who` |
| Audit Agent Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bads7w1q6wmhn18u6dxwt28t` |
| Audit Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Entity Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-entity-reference` |
| Audit Entity Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.entity.what` |
| Audit Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-sjp1x177mlpq3howdltptm3c` |
| Audit Event Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-identifier` |
| Audit Event Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Data Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Data Subject Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Data Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/data-subject-reference` |
| Data Subject Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.patient` |
| Data Subject Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-x2rc9cg84d2famryqzdic0as` |
| On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| On Behalf Of Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/on-behalf-of-reference` |
| On Behalf Of Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/provenance-definitions.html#Provenance.agent.onBehalfOf` |
| On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-j9gvyx6u9pb7v1dd0m6joxd6` |
| System Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| System Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-identifier` |
| System Identifier | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.source.observer` |
| System Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-des67jo3ki9w0zgaz2i2t2cq` |
| System Location Name | `dcterms:publisher` | `https://axius-sdc.com` |
| System Location Name | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Location Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-location-name` |
| System Location Name | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.location` |
| System Location Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l6fwy1a2l5i43t308pknygp7` |
| Audit Event Action | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Action | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Action | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-action` |
| Audit Event Action | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-action` |
| Audit Event Action | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-o8lawuczf9vry55e98cjg12r` |
| Audit Event Outcome | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Outcome | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Outcome | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-outcome` |
| Audit Event Outcome | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-outcome` |
| Audit Event Outcome | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lgmleqp52a6kl268drrtfjk5` |
| Confidentiality | `dcterms:publisher` | `https://axius-sdc.com` |
| Confidentiality | `dcterms:source` | `http://terminology.hl7.org/` |
| Confidentiality | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/confidentiality` |
| Confidentiality | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-Confidentiality` |
| Confidentiality | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hp8q52t8tgmis92c4ljrfy7e` |
| Provenance Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Provenance Agent Type | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Provenance Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/provenance-agent-type` |
| Provenance Agent Type | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/provenance-participant-type` |
| Provenance Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-syt8l7pmb64eym2chcn43ai7` |
| Purpose of Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Purpose of Use | `dcterms:source` | `http://terminology.hl7.org/` |
| Purpose of Use | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/purpose-of-use` |
| Purpose of Use | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActReason` |
| Purpose of Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-y87ikto4p56zlkx4o2d63ain` |
| Audit Recorded At | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Recorded At | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Recorded At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-recorded-at` |
| Audit Recorded At | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.recorded` |
| NHANES Medication | `dcterms:publisher` | `https://axius-sdc.com` |
| NHANES Medication | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-medication` |
| NHANES Medication | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| NHANES Medication | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/MedicationStatement` |
| Generic Drug Code (RXDDRGID) | `dcterms:publisher` | `https://axius-sdc.com` |
| Generic Drug Code (RXDDRGID) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-generic-drug-code` |
| Generic Drug Code (RXDDRGID) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Generic Drug Code (RXDDRGID) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/RXQ_RX_J.htm#RXDDRGID` |
| Generic Drug Name (RXDDRUG) | `dcterms:publisher` | `https://axius-sdc.com` |
| Generic Drug Name (RXDDRUG) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-generic-drug-name` |
| Generic Drug Name (RXDDRUG) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Generic Drug Name (RXDDRUG) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/RXQ_RX_J.htm#RXDDRUG` |
| Respondent Sequence Number (SEQN) | `dcterms:publisher` | `https://axius-sdc.com` |
| Respondent Sequence Number (SEQN) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-respondent-sequence-number` |
| Respondent Sequence Number (SEQN) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Respondent Sequence Number (SEQN) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#SEQN` |
| Taken Prescription Medicine, Past Month (RXDUSE) | `dcterms:publisher` | `https://axius-sdc.com` |
| Taken Prescription Medicine, Past Month (RXDUSE) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-taken-prescription-past-month` |
| Taken Prescription Medicine, Past Month (RXDUSE) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Taken Prescription Medicine, Past Month (RXDUSE) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/RXQ_RX_J.htm#RXDUSE` |
| Number of Days Taken Medicine (RXDDAYS) | `dcterms:publisher` | `https://axius-sdc.com` |
| Number of Days Taken Medicine (RXDDAYS) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-days-taken-medicine` |
| Number of Days Taken Medicine (RXDDAYS) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Number of Days Taken Medicine (RXDDAYS) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/RXQ_RX_J.htm#RXDDAYS` |
| Number of Prescription Medicines Taken (RXDCOUNT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Number of Prescription Medicines Taken (RXDCOUNT) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-number-of-prescription-medicines` |
| Number of Prescription Medicines Taken (RXDCOUNT) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Number of Prescription Medicines Taken (RXDCOUNT) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/RXQ_RX_J.htm#RXDCOUNT` |
| Medication Reason 1 | `dcterms:publisher` | `https://axius-sdc.com` |
| Medication Reason 1 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-medication-reason-1` |
| Medication Reason 1 | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Medication Reason 1 | `skos:exactMatch` | `http://hl7.org/fhir/R4/medicationrequest-definitions.html#MedicationRequest.reasonCode` |
| Diagnosis (ICD-10-CM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Diagnosis (ICD-10-CM) | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Diagnosis (ICD-10-CM) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/diagnosis-icd10cm` |
| Diagnosis (ICD-10-CM) | `skos:closeMatch` | `http://hl7.org/fhir/sid/icd-10-cm` |
| Diagnosis (ICD-10-CM) | `skos:exactMatch` | `http://hl7.org/fhir/R4/condition-definitions.html#Condition.code` |
| Code System: ICD-10-CM | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: ICD-10-CM | `dcterms:source` | `http://hl7.org/fhir/sid/icd-10-cm` |
| Code System: ICD-10-CM | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/system-icd10cm` |
| Code System: ICD-10-CM | `skos:exactMatch` | `http://hl7.org/fhir/sid/icd-10-cm` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Diagnosis Code (ICD-10-CM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Diagnosis Code (ICD-10-CM) | `dcterms:source` | `http://hl7.org/fhir/sid/icd-10-cm` |
| Diagnosis Code (ICD-10-CM) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/diagnosis-icd10cm-code` |
| Diagnosis Code (ICD-10-CM) | `skos:exactMatch` | `http://hl7.org/fhir/R4/condition-definitions.html#Condition.code` |
| Diagnosis Code (ICD-10-CM) | `skos:exactMatch` | `http://hl7.org/fhir/sid/icd-10-cm` |
| Diagnosis Code (ICD-10-CM) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gnssdkny454dgbykbs16wuew` |
| Medication Reason 2 | `dcterms:publisher` | `https://axius-sdc.com` |
| Medication Reason 2 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-medication-reason-2` |
| Medication Reason 2 | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Medication Reason 2 | `skos:exactMatch` | `http://hl7.org/fhir/R4/medicationrequest-definitions.html#MedicationRequest.reasonCode` |
| Medication Reason 3 | `dcterms:publisher` | `https://axius-sdc.com` |
| Medication Reason 3 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-medication-reason-3` |
| Medication Reason 3 | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Medication Reason 3 | `skos:exactMatch` | `http://hl7.org/fhir/R4/medicationrequest-definitions.html#MedicationRequest.reasonCode` |
| PROV Activity | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Activity | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-activity` |
| PROV Activity | `skos:exactMatch` | `http://www.w3.org/ns/prov#Activity` |
| PROV Activity | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-description` |
| Activity Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Activity Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-m9xg6e182m1oq77ssrf9iujv` |
| Activity Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-identifier` |
| Activity Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Activity Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fpnn1dew0kcevc8ptohndc5t` |
| Activity Label | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Label | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-label` |
| Activity Label | `skos:exactMatch` | `http://www.w3.org/2000/01/rdf-schema#label` |
| Activity Label | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Label | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-n4kaez29vbknku2jy8n56gfm` |
| Activity Location | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Location | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-location` |
| Activity Location | `skos:exactMatch` | `http://www.w3.org/ns/prov#atLocation` |
| Activity Location | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Location | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ciuklf1kl8bphpudye4i47am` |
| Activity Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-type` |
| Activity Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#type` |
| Activity Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ceusvbe55b266gcdzf5qnurc` |
| Error Message | `dcterms:publisher` | `https://axius-sdc.com` |
| Error Message | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/error-message` |
| Error Message | `dcterms:source` | `https://schema.org/` |
| Error Message | `skos:exactMatch` | `https://schema.org/error` |
| Error Message | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-eakhqr9l9nbblppgxc5fq25n` |
| Had Plan Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Had Plan Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/had-plan-reference` |
| Had Plan Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#hadPlan` |
| Had Plan Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Had Plan Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-xvdfh1nzfar33yxmgl3jgvqo` |
| Used Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Used Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/used-entity-reference` |
| Used Entity Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#used` |
| Used Entity Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Used Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ixv0fa8xlde52mdeymr4zaka` |
| Was Associated With Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Associated With Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-associated-with-reference` |
| Was Associated With Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasAssociatedWith` |
| Was Associated With Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Associated With Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gs0e1hp2rpjl6qfg9v8d047f` |
| Was Ended By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Ended By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-ended-by-reference` |
| Was Ended By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasEndedBy` |
| Was Ended By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Ended By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-jr1e3n5kg31nqz1ynh28kitp` |
| Was Informed By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Informed By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-informed-by-reference` |
| Was Informed By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasInformedBy` |
| Was Informed By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Informed By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rz60y6aujd274j4i7jpyxvpr` |
| Was Started By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Started By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-started-by-reference` |
| Was Started By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasStartedBy` |
| Was Started By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Started By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kmodjk1e5xu9z94zgiaxx1hu` |
| Activity Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Status | `dcterms:source` | `https://w3id.org/dpv` |
| Activity Status | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-status` |
| Activity Status | `skos:closeMatch` | `https://w3id.org/dpv#ActivityStatus` |
| Activity Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yehcpzf43j0b5zp9ck59t9eg` |
| Ended At | `dcterms:publisher` | `https://axius-sdc.com` |
| Ended At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/ended-at-time` |
| Ended At | `skos:exactMatch` | `http://www.w3.org/ns/prov#endedAtTime` |
| Ended At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Started At | `dcterms:publisher` | `https://axius-sdc.com` |
| Started At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/started-at-time` |
| Started At | `skos:exactMatch` | `http://www.w3.org/ns/prov#startedAtTime` |
| Started At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent` |
| PROV Agent | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Acted On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/acted-on-behalf-of-reference` |
| Acted On Behalf Of Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#actedOnBehalfOf` |
| Acted On Behalf Of Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dce4w62jxjngjnmc5y26fq66` |
| Agent Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-description` |
| Agent Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Agent Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w79xppnskig5vq31er8gh7nk` |
| Agent Email | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Email | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-email` |
| Agent Email | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/mbox` |
| Agent Email | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Email | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yp6pm5xyovxhkjimrrb8h9xy` |
| Agent Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-identifier` |
| Agent Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Agent Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hhfnj5hd1yzt252jfq5pdjj1` |
| Agent Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-name` |
| Agent Name | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/name` |
| Agent Name | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yya0pdgjd2w0wlz5r3h516om` |
| Agent Organization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Organization Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-organization-name` |
| Agent Organization Name | `dcterms:source` | `https://schema.org/` |
| Agent Organization Name | `skos:exactMatch` | `https://schema.org/legalName` |
| Agent Organization Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ifw5zfe4oiijbxjn1ylc2wm3` |
| Software Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-name` |
| Software Name | `dcterms:source` | `https://schema.org/` |
| Software Name | `skos:exactMatch` | `https://schema.org/SoftwareApplication` |
| Software Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rsjfjz8m5z7a58h5793duqbs` |
| Software Version | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Version | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-version` |
| Software Version | `dcterms:source` | `https://schema.org/` |
| Software Version | `skos:exactMatch` | `https://schema.org/softwareVersion` |
| Software Version | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tep9wanrrtqfw0k76huv6tvd` |
| PROV Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent-type` |
| PROV Agent Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-nesxtz8c5o665swc9lhvqkjj` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "NHANES Medication" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-epbdfmvxc3gbh5f66hhb3o2m.xsd)
- Example instance (dm-epbdfmvxc3gbh5f66hhb3o2m.xml)
- HTML documentation (dm-epbdfmvxc3gbh5f66hhb3o2m.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"NHANES Medication" SDC4 schema (dm-epbdfmvxc3gbh5f66hhb3o2m.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"NHANES Medication" schema (dm-epbdfmvxc3gbh5f66hhb3o2m.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "NHANES Medication" SDC4 schema (dm-epbdfmvxc3gbh5f66hhb3o2m.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "NHANES Medication" data model (dm-epbdfmvxc3gbh5f66hhb3o2m.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-epbdfmvxc3gbh5f66hhb3o2m.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-epbdfmvxc3gbh5f66hhb3o2m.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-epbdfmvxc3gbh5f66hhb3o2m.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-epbdfmvxc3gbh5f66hhb3o2m.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-epbdfmvxc3gbh5f66hhb3o2m.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
