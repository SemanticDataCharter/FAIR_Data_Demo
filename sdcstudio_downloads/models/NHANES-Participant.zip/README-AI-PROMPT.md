# NHANES Participant

**Model ID**: `dm-xy8upneajsb8vdcmnve01g6g`
**Project**: FAIR Data Demo
**Description**: SDC4 data model for National Health and Nutrition Examination Survey (nhanes_blood_pressure) — FAIR Data Demo

### Dublin Core Metadata
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal

## Package Contents

- `dm-xy8upneajsb8vdcmnve01g6g.xsd` -- XML Schema Definition (data model structure)
- `dm-xy8upneajsb8vdcmnve01g6g.xml` -- XML instance example with sample data
- `dm-xy8upneajsb8vdcmnve01g6g-instance.json` -- JSON instance example (same structure as XML)
- `dm-xy8upneajsb8vdcmnve01g6g.jsonld` -- JSON-LD semantic schema description
- `dm-xy8upneajsb8vdcmnve01g6g.html` -- Human-readable model documentation
- `dm-xy8upneajsb8vdcmnve01g6g_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-xy8upneajsb8vdcmnve01g6g.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-xy8upneajsb8vdcmnve01g6g.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-xy8upneajsb8vdcmnve01g6g.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-xy8upneajsb8vdcmnve01g6g.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **NHANES Participant Governed Record** | Cluster | `l6t9agg233vswxyv60quiu6w` | 0 components; 4 sub-cluster(s) |
|   **Audit Event** | Cluster | `t2tvd3wylxrstdeu5aw6gkw1` | 13 components |
|     Audit Agent Reference | XdString | `dkc2ccj5te35z9gd4bu1blcq` | maxLen=2000; pattern=`\S+` |
|     Audit Entity Reference | XdString | `gcjyjrnp0wsfoelcp4m05c67` | maxLen=2000; pattern=`\S+` |
|     Audit Event Identifier | XdString | `fjhgr5fyqxt2crmg2cb5c513` | maxLen=255 |
|     Data Subject Reference | XdString | `sndpbhm3xbd6qtbyxmvh3i0e` | maxLen=2000; pattern=`\S+` |
|     On Behalf Of Reference | XdString | `nf1air1zbj8v9w66jozdxmyl` | maxLen=2000; pattern=`\S+` |
|     System Identifier | XdString | `h3kdbvdtyalpvik97saaf0an` | maxLen=255 |
|     System Location Name | XdString | `ujir739mf1g8ajeczs9nzh9m` | maxLen=255 |
|     Audit Event Action | XdToken | `ce1c8sydkov8bkv4dgdmwe5x` | 5 enum(s) |
|     Audit Event Outcome | XdToken | `rpz1czz06jhpahmfz30rblvp` | 4 enum(s) |
|     Confidentiality | XdToken | `vbctgmdcwps5b3r3l6sboa6y` | 6 enum(s) |
|     Provenance Agent Type | XdToken | `jujsdur1igws8orw6tvvlqco` | 13 enum(s) |
|     Purpose of Use | XdToken | `d1evlz8yvdlwt6ia9fjq4pgj` | 11 enum(s) |
|     Audit Recorded At | XdTemporal | `uwiosm2q9ym3ewr4de910s70` | -- |
|   **NHANES Participant** | Cluster | `e3gwv95m8jjx7578urmx8ppz` | 1 components; 7 sub-cluster(s) |
|     Respondent Sequence Number (SEQN) | XdString | `uto4zszvpicva38wx77knz5y` | maxLen=8; pattern=`[0-9]{5,6}` |
|     **NHANES Blood Pressure** | Cluster | `k8t5396w5kh1zzf6vhp4ola2` | 5 components; 3 sub-cluster(s) |
|       Arm Selected (BPAARM) | XdToken | `f98c865cpjza5wwh3odh9nv3` | 2 enum(s) |
|       Coded Cuff Size (BPACSZ) | XdToken | `qv6ytjstrquvfr20cyfjqq2d` | 5 enum(s) |
|       Pulse Regular or Irregular (BPXPULS) | XdToken | `uy2fly38y0ghl10xgo4e7svh` | 2 enum(s) |
|       Maximum Inflation Level (BPXML1) | XdQuantity | `ujpg1m8po18ynniqpwhltxld` | units=Pressure |
|       Heart Rate | XdQuantity | `oy0jwif5pi86xtimzxzhapvu` | units=Rate |
|       **Blood Pressure Reading 1** | Cluster | `x69rhb0rc8sn1e6qkirhcnum` | 0 components; 1 sub-cluster(s) |
|         **Blood Pressure** | Cluster | `wyk9e1d74y5xrgv97o9y75ib` | 4 components; 1 sub-cluster(s) |
|           Observation Status | XdToken | `q9vmn1cvdclgr757aer5v1rg` | 8 enum(s) |
|           Diastolic Blood Pressure | XdQuantity | `s3qzwxxz9b42lcd2wryok8jd` | units=Pressure |
|           Systolic Blood Pressure | XdQuantity | `r1ve12xphsb5hu2yjmhksw5h` | units=Pressure |
|           Observation Date Time | XdTemporal | `dkyyj01tksb7h7akq2w7moum` | -- |
|           **Body Site (SNOMED CT)** | Cluster | `r5koa840csi3zcewts0uo0r5` | 3 components |
|             Code System: SNOMED CT | XdLink | `q75pzzv36or6dxgjrrbvmun5` | -- |
|             Body Site Code (SNOMED CT) | XdString | `vi7yvq0b8nler3g6alaamrzm` | maxLen=40; pattern=`[0-9]{6,18}` |
|             Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|       **Blood Pressure Reading 2** | Cluster | `so1r0ndetw0artjnbfirxd5y` | 0 components; 1 sub-cluster(s) |
|       **Blood Pressure Reading 3** | Cluster | `izygcyh1wupij0st4iy0ir1k` | 0 components; 1 sub-cluster(s) |
|     **NHANES Demographics** | Cluster | `b6bz6qun3frba85kw1a539h2` | 18 components |
|       Annual Household Income (INDHHIN2) | XdToken | `ex88a2s3ys6hm5pvv77j0q2u` | 14 enum(s) |
|       Citizenship Status (DMDCITZN) | XdToken | `m67ncwhc9s1j36f9w9qsrxfx` | 2 enum(s) |
|       Country of Birth (DMDBORN4) | XdToken | `nwsj84veb6u9g1v0h2a3a793` | 2 enum(s) |
|       Education Level - Adults 20+ (DMDEDUC2) | XdToken | `fqjd2lvp9jamdpf0f3kpkwnp` | 5 enum(s) |
|       Gender (RIAGENDR) | XdToken | `sigmhjzuw16w0k8op92lk9sd` | 2 enum(s) |
|       Marital Status (DMDMARTL) | XdToken | `i3uys2dmi257jkdzavsst5az` | 6 enum(s) |
|       Pregnancy Status at Exam (RIDEXPRG) | XdToken | `r0j6yo8zvo4q8x0ovdr6j9yz` | 3 enum(s) |
|       Race/Hispanic Origin with NH Asian (RIDRETH3) | XdToken | `hs44ipuqgvc3azbt3mirxtsz` | 6 enum(s) |
|       Veteran Status | XdToken | `eimlsgbawhm8aa4i6gbdrja0` | 2 enum(s) |
|       Are you pregnant now? | XdToken | `owjt9bcgisxfbco8qnddo2fq` | 3 enum(s) |
|       Current Educational Attainment | XdToken | `xtbtk7ro6s9247bcwt4ak4h1` | 24 enum(s) |
|       Marital Status | XdToken | `qsetd453kk9own8co1wmc5cz` | 8 enum(s) |
|       Race/Ethnicity Self-Identification | XdToken | `u5tietya3u56hbz2kos06ai7` | 7 enum(s) |
|       Administrative Gender | XdToken | `gxzbm758mhdz51xd4bawlfhh` | 4 enum(s) |
|       Age in Months at Screening (RIDAGEMN) | XdCount | `qg7or0c34grde4gprzwifukh` | units=Months |
|       Total Number of People in the Household (DMDHHSIZ) | XdCount | `qbp08a1gscple2aiuiwyfz2s` | units=Items |
|       Age | XdCount | `wuvdeiwoe5bna7nlhcl1c4h9` | units=years or months |
|       Ratio of Family Income to Poverty (INDFMPIR) | XdQuantity | `dwd4pk56w0pjchsyzl81fzya` | units=Sample Weight |
|     **NHANES Laboratory Results** | Cluster | `c73687ou0pkc7qy6n2kksfc7` | 23 components |
|       Basophils Number | XdQuantity | `ncskx5im3if41mqo9pm8ydx0` | units=Thousands per Microlitre |
|       Basophils Percent | XdQuantity | `wcasfq02d9hukvn2bar4r67d` | units=Percentage |
|       Eosinophils Number | XdQuantity | `f49ynlsmh5zex122r4i2jeqg` | units=Thousands per Microlitre |
|       Eosinophils Percent | XdQuantity | `zsikpg1vrhzoydvk26gpg6nb` | units=Percentage |
|       Hematocrit | XdQuantity | `kn0gsgklvqcbbz2f20dg1koy` | units=Percentage |
|       Hemoglobin | XdQuantity | `z9jeqoghnlvlyy8sgxk5lwne` | units=Grams per Decilitre |
|       Lymphocyte Number | XdQuantity | `cdzb3xhl10wivkk305sm09wf` | units=Thousands per Microlitre |
|       Lymphocyte Percent | XdQuantity | `ia77g23fvigr9b9dkx6a1rcl` | units=Percentage |
|       Mean Cell Hemoglobin | XdQuantity | `scmpca8vlisbmmfa3njyx2o2` | units=Picograms |
|       Mean Cell Hemoglobin Concentration | XdQuantity | `pf1abnd8c9cfwb4hw9lc65b0` | units=Grams per Decilitre |
|       Mean Cell Volume | XdQuantity | `sqjdwrx3kpuuxkwa69bodut2` | units=Femtolitres |
|       Mean Platelet Volume | XdQuantity | `n6mstjwsss62iruurp7utrn4` | units=Femtolitres |
|       Monocyte Number | XdQuantity | `hesbothq9s8ihc33ihsbv3bi` | units=Thousands per Microlitre |
|       Monocyte Percent | XdQuantity | `cyu9eutfs28y6tl8bsxwr3qe` | units=Percentage |
|       Nucleated Red Blood Cells | XdQuantity | `swvr4xwxui5idfg7r6tfa1mr` | units=Per 100 Cells |
|       Platelet Count | XdQuantity | `o3jk44vqom9ne0v4tiay1ys7` | units=Thousands per Microlitre |
|       Red Blood Cell Count | XdQuantity | `uraf13ojset6tivrdptohfbr` | units=Millions per Microlitre |
|       Red Cell Distribution Width | XdQuantity | `pf6ne2nf0ef5xeba7q73a2s8` | units=Percentage |
|       Segmented Neutrophils Number | XdQuantity | `a3bccid1kdgem2m5rix68o1y` | units=Thousands per Microlitre |
|       Segmented Neutrophils Percent | XdQuantity | `n13vv8g72h826o4o1jxm1o91` | units=Percentage |
|       Total Cholesterol | XdQuantity | `rl42ns60wqjt2jr4kgmfomsd` | units=Milligrams per Decilitre |
|       Total Cholesterol (SI) | XdQuantity | `qp5mdgab3s37zwqzyfzq8rvi` | units=Millimoles per Litre |
|       White Blood Cell Count | XdQuantity | `cujdlrpxv7byme6c5z3ai1ui` | units=Thousands per Microlitre |
|     **NHANES Medical Conditions** | Cluster | `mc8by65nv7wa59lw4oj54e2w` | 2 components; 1 sub-cluster(s) |
|       Doctor Ever Said You Were Overweight (MCQ080) | XdToken | `fwyb9ukfypotqkvahtygrjo5` | 2 enum(s) |
|       Still Have Asthma (MCQ035) | XdToken | `ejjthi5lftrx9a7rv3fedq6m` | 2 enum(s) |
|       **Chronic Condition Indicators** | Cluster | `wa0mknvfo83hej635n48s0ig` | 22 components |
|         Condition: Alzheimer's Disease or Related Disorder | XdToken | `d9z9mcx6gs9zbz4k6f0v738s` | 2 enum(s) |
|         Condition: Angina | XdToken | `o4d67oubyyunugx3la44f53u` | 2 enum(s) |
|         Condition: Arthritis | XdToken | `nd1v8jk7wtm1tthzw1f4987t` | 2 enum(s) |
|         Condition: Asthma | XdToken | `acr1xvqppf1b3rjsrst6tt4p` | 2 enum(s) |
|         Condition: Cancer | XdToken | `ix0my2v2z79s002g0r8orosf` | 2 enum(s) |
|         Condition: Chronic Bronchitis | XdToken | `jyx7rxfktazhgxgq84fxf6wr` | 2 enum(s) |
|         Condition: Congestive Heart Failure | XdToken | `hyqlz591lhj54sdt1a1mup70` | 2 enum(s) |
|         Condition: COPD | XdToken | `mijr18ynaqde2l8jps70l2g6` | 2 enum(s) |
|         Condition: Coronary Heart Disease | XdToken | `udbydjqj76l8kl6mi2s3v7vd` | 2 enum(s) |
|         Condition: Depression | XdToken | `of4crvmnrr3s5q5396kmt0jv` | 2 enum(s) |
|         Condition: Diabetes | XdToken | `fzpb9xr5jg2m3e3dzmvi1v3h` | 2 enum(s) |
|         Condition: Emphysema | XdToken | `sbulkq80j4fkbiql4zgje4qr` | 2 enum(s) |
|         Condition: Heart Attack | XdToken | `yshoeps2dm0j1ueusqs825v6` | 2 enum(s) |
|         Condition: High Blood Pressure | XdToken | `lvockfc8lce5p15wuwxc1kwa` | 2 enum(s) |
|         Condition: High Cholesterol | XdToken | `gp3jxw3xzs761ll6u5rvc6jr` | 2 enum(s) |
|         Condition Indicator Basis | XdToken | `hc79skkfionpgw87dsg5yrgw` | 2 enum(s) |
|         Condition: Kidney Disease | XdToken | `sw5rt0k2uap0e3xgl4rznfgu` | 2 enum(s) |
|         Condition: Liver Condition | XdToken | `atqkooccakulfhkt18c008fx` | 2 enum(s) |
|         Condition: Osteoporosis | XdToken | `l784ggegqcvrpnmw2yvo4il7` | 2 enum(s) |
|         Condition: Skin Cancer | XdToken | `xsohkckyof7y1xj8h1ab4pxu` | 2 enum(s) |
|         Condition: Stroke | XdToken | `zc6p008h5naqev8zngtzvyx9` | 2 enum(s) |
|         Condition: Thyroid Problem | XdToken | `p8u71b4lhct4ra0szgkex7xo` | 2 enum(s) |
|     **NHANES Physical Functioning** | Cluster | `ky7lvmote5jfn5gt6n89q79s` | 12 components |
|       Difficulty Dressing Yourself (PFQ061L) | XdToken | `p4jxl2rur1agjhdpvj2g9u4k` | 5 enum(s) |
|       Difficulty Getting In and Out of Bed (PFQ061J) | XdToken | `cy6k5rxvhvg2v27cfp7pjwyx` | 5 enum(s) |
|       Difficulty Lifting or Carrying (PFQ061E) | XdToken | `b1mxr233mgqvzr39c90ly8cv` | 5 enum(s) |
|       Difficulty Standing for Long Periods (PFQ061M) | XdToken | `vp4ow7t3q8w2phcft0qvyj4u` | 5 enum(s) |
|       Difficulty Standing Up from an Armless Chair (PFQ061I) | XdToken | `y52y4mpq95zcknal0be1uc7v` | 5 enum(s) |
|       Difficulty Stooping, Crouching or Kneeling (PFQ061D) | XdToken | `knrs4clih4pi26tm2zra1ai0` | 5 enum(s) |
|       Difficulty Walking a Quarter Mile (PFQ061B) | XdToken | `mktq5xr8slz67q85idl8bsky` | 5 enum(s) |
|       Difficulty Walking Between Rooms (PFQ061H) | XdToken | `crr2z3b2l7hlq1kvevppt8kt` | 5 enum(s) |
|       Difficulty Walking Up Ten Stairs (PFQ061C) | XdToken | `rot4z5ny8gdkfmimedcjl1te` | 5 enum(s) |
|       Experience Confusion or Memory Problems (PFQ057) | XdToken | `jxdk8rs1m133yzb52rfs08hy` | 2 enum(s) |
|       Limitations Keeping You from Working (PFQ049) | XdToken | `gxy0s65v35djnq875rzhcmby` | 2 enum(s) |
|       Need Special Equipment to Walk (PFQ054) | XdToken | `wh4zkqhos44fbb5p0b5c7w1d` | 2 enum(s) |
|     **NHANES Smoking** | Cluster | `u3nopo5pxqb1dwwk3u0fyp6e` | 6 components |
|       Do You Now Smoke Cigarettes (SMQ040) | XdToken | `mq5xicyh1n3d8ofhyroazip2` | 3 enum(s) |
|       Ever Used an E-cigarette (SMQ900) | XdToken | `gy1045dipmx8udv1bndk7hrv` | 2 enum(s) |
|       Smoked at Least 100 Cigarettes in Life (SMQ020) | XdToken | `lnbzdjsluc4ebnri7k4dvn2i` | 2 enum(s) |
|       Smoking Status | XdToken | `n7pn5ctqo81v0v418hez5zv5` | 5 enum(s) |
|       Age Started Smoking Cigarettes Regularly (SMD030) | XdCount | `wlfal1j4vnwy76szun72madm` | units=Years |
|       Average Cigarettes per Day, Past 30 Days (SMD650) | XdCount | `v9wj86qu70lda3tt2dh299wz` | units=Cigarettes |
|     **NHANES Survey Design** | Cluster | `mgqswj92qaeasqjjvfcyxon5` | 6 components |
|       Data Release Cycle (SDDSRVYR) | XdToken | `k52nvzllwurg016nvsulpm32` | 1 enum(s) |
|       Interview/Examination Status (RIDSTATR) | XdToken | `j9l0spojx47xnjqipfl9mzte` | 2 enum(s) |
|       Masked Variance Pseudo-PSU (SDMVPSU) | XdCount | `vxldr9jodr9eu5uol3g4c189` | units=Items |
|       Masked Variance Pseudo-Stratum (SDMVSTRA) | XdCount | `yksuiithtrif7jdrjpi4o7eg` | units=Items |
|       Full Sample 2 Year Interview Weight (WTINT2YR) | XdQuantity | `zmw9684hejwjsfcg6t71jkgl` | units=Sample Weight |
|       Full Sample 2 Year MEC Exam Weight (WTMEC2YR) | XdQuantity | `w7xdjmfmoev4of0gd76mtnto` | units=Sample Weight |
|   **PROV Activity** | Cluster | `vmikfu0irht9fmq7q02t3oqs` | 15 components |
|     Activity Description | XdString | `hhusuzzig19rs46ngz23k5g7` | maxLen=4000 |
|     Activity Identifier | XdString | `wr06h54xqqw2q9id8i9673jy` | maxLen=255 |
|     Activity Label | XdString | `r6hkunjm2q0hlxiknlc9ljix` | maxLen=255 |
|     Activity Location | XdString | `uzai5uey5p1fnn9ezj9u6vor` | maxLen=255 |
|     Activity Type | XdString | `jjzmhdxvbt97pq81iwqubtxk` | maxLen=255 |
|     Error Message | XdString | `xlgjqdpwdbn2re3mdh5yy2rk` | maxLen=4000 |
|     Had Plan Reference | XdString | `vhezo2cckpe92x4c3j2memeh` | maxLen=2000; pattern=`\S+` |
|     Used Entity Reference | XdString | `t0whhrqtnb54te4mk48i1ooj` | maxLen=2000; pattern=`\S+` |
|     Was Associated With Reference | XdString | `r48alj7hc3797qfjnf2uj71n` | maxLen=2000; pattern=`\S+` |
|     Was Ended By Reference | XdString | `ueb5g1ojzlwwt0mnds5zb6wl` | maxLen=2000; pattern=`\S+` |
|     Was Informed By Reference | XdString | `qh84jdzp1kxt85aq4ilo0svk` | maxLen=2000; pattern=`\S+` |
|     Was Started By Reference | XdString | `ginfqbk7q59ld2r4us8sjnv1` | maxLen=2000; pattern=`\S+` |
|     Activity Status | XdToken | `wl6j4ekcmu4hvt2m12zw4zp8` | 6 enum(s) |
|     Ended At | XdTemporal | `a5scyosu6j84vz350mqyrzl2` | -- |
|     Started At | XdTemporal | `sa4nl1kbpdr842fkucvfjkpq` | -- |
|   **PROV Agent** | Cluster | `c179ilk2ns15cd5rzzdfd6f6` | 9 components |
|     Acted On Behalf Of Reference | XdString | `og08xf6bu928uuz6t3y0e23f` | maxLen=2000; pattern=`\S+` |
|     Agent Description | XdString | `gb78cmuyo72hqs5apymdki7l` | maxLen=4000 |
|     Agent Email | XdString | `qb90a0sp9vvb6c5cbcf236ys` | maxLen=255 |
|     Agent Identifier | XdString | `w2ruemcfy35rw60jl1t9dew2` | maxLen=255 |
|     Agent Name | XdString | `xxe21o9ojzmy9wxxky1tnmog` | maxLen=255 |
|     Agent Organization Name | XdString | `eftvwi5byq6cdtd931qyxzw0` | maxLen=255 |
|     Software Name | XdString | `aa663ivutjf2fs4757t0bbzy` | maxLen=255 |
|     Software Version | XdString | `x0lebwtobgaelj5pev3258sd` | maxLen=60 |
|     PROV Agent Type | XdToken | `i16vqj89it3db7d3c5qjko9p` | 3 enum(s) |

## Structural Hierarchy

```
DM: NHANES Participant
  [Cluster] NHANES Participant Governed Record
    [Cluster] Audit Event
      [XdString] Audit Agent Reference
      [XdString] Audit Entity Reference
      [XdString] Audit Event Identifier
      [XdString] Data Subject Reference
      [XdString] On Behalf Of Reference
      [XdString] System Identifier
      [XdString] System Location Name
      [XdToken] Audit Event Action
      [XdToken] Audit Event Outcome
      [XdToken] Confidentiality
      [XdToken] Provenance Agent Type
      [XdToken] Purpose of Use
      [XdTemporal] Audit Recorded At
    [Cluster] NHANES Participant
      [XdString] Respondent Sequence Number (SEQN)
      [Cluster] NHANES Blood Pressure
        [XdToken] Arm Selected (BPAARM)
        [XdToken] Coded Cuff Size (BPACSZ)
        [XdToken] Pulse Regular or Irregular (BPXPULS)
        [XdQuantity] Maximum Inflation Level (BPXML1)
        [XdQuantity] Heart Rate
        [Cluster] Blood Pressure Reading 1
          [Cluster] Blood Pressure
            [XdToken] Observation Status
            [XdQuantity] Diastolic Blood Pressure
            [XdQuantity] Systolic Blood Pressure
            [XdTemporal] Observation Date Time
            [Cluster] Body Site (SNOMED CT)
              [XdLink] Code System: SNOMED CT
              [XdString] Body Site Code (SNOMED CT)
              [XdString] Code Display Text
        [Cluster] Blood Pressure Reading 2
          [Cluster] Blood Pressure (circular ref)
        [Cluster] Blood Pressure Reading 3
          [Cluster] Blood Pressure (circular ref)
      [Cluster] NHANES Demographics
        [XdToken] Annual Household Income (INDHHIN2)
        [XdToken] Citizenship Status (DMDCITZN)
        [XdToken] Country of Birth (DMDBORN4)
        [XdToken] Education Level - Adults 20+ (DMDEDUC2)
        [XdToken] Gender (RIAGENDR)
        [XdToken] Marital Status (DMDMARTL)
        [XdToken] Pregnancy Status at Exam (RIDEXPRG)
        [XdToken] Race/Hispanic Origin with NH Asian (RIDRETH3)
        [XdToken] Veteran Status
        [XdToken] Are you pregnant now?
        [XdToken] Current Educational Attainment
        [XdToken] Marital Status
        [XdToken] Race/Ethnicity Self-Identification
        [XdToken] Administrative Gender
        [XdCount] Age in Months at Screening (RIDAGEMN)
        [XdCount] Total Number of People in the Household (DMDHHSIZ)
        [XdCount] Age
        [XdQuantity] Ratio of Family Income to Poverty (INDFMPIR)
      [Cluster] NHANES Laboratory Results
        [XdQuantity] Basophils Number
        [XdQuantity] Basophils Percent
        [XdQuantity] Eosinophils Number
        [XdQuantity] Eosinophils Percent
        [XdQuantity] Hematocrit
        [XdQuantity] Hemoglobin
        [XdQuantity] Lymphocyte Number
        [XdQuantity] Lymphocyte Percent
        [XdQuantity] Mean Cell Hemoglobin
        [XdQuantity] Mean Cell Hemoglobin Concentration
        [XdQuantity] Mean Cell Volume
        [XdQuantity] Mean Platelet Volume
        [XdQuantity] Monocyte Number
        [XdQuantity] Monocyte Percent
        [XdQuantity] Nucleated Red Blood Cells
        [XdQuantity] Platelet Count
        [XdQuantity] Red Blood Cell Count
        [XdQuantity] Red Cell Distribution Width
        [XdQuantity] Segmented Neutrophils Number
        [XdQuantity] Segmented Neutrophils Percent
        [XdQuantity] Total Cholesterol
        [XdQuantity] Total Cholesterol (SI)
        [XdQuantity] White Blood Cell Count
      [Cluster] NHANES Medical Conditions
        [XdToken] Doctor Ever Said You Were Overweight (MCQ080)
        [XdToken] Still Have Asthma (MCQ035)
        [Cluster] Chronic Condition Indicators
          [XdToken] Condition: Alzheimer's Disease or Related Disorder
          [XdToken] Condition: Angina
          [XdToken] Condition: Arthritis
          [XdToken] Condition: Asthma
          [XdToken] Condition: Cancer
          [XdToken] Condition: Chronic Bronchitis
          [XdToken] Condition: Congestive Heart Failure
          [XdToken] Condition: COPD
          [XdToken] Condition: Coronary Heart Disease
          [XdToken] Condition: Depression
          [XdToken] Condition: Diabetes
          [XdToken] Condition: Emphysema
          [XdToken] Condition: Heart Attack
          [XdToken] Condition: High Blood Pressure
          [XdToken] Condition: High Cholesterol
          [XdToken] Condition Indicator Basis
          [XdToken] Condition: Kidney Disease
          [XdToken] Condition: Liver Condition
          [XdToken] Condition: Osteoporosis
          [XdToken] Condition: Skin Cancer
          [XdToken] Condition: Stroke
          [XdToken] Condition: Thyroid Problem
      [Cluster] NHANES Physical Functioning
        [XdToken] Difficulty Dressing Yourself (PFQ061L)
        [XdToken] Difficulty Getting In and Out of Bed (PFQ061J)
        [XdToken] Difficulty Lifting or Carrying (PFQ061E)
        [XdToken] Difficulty Standing for Long Periods (PFQ061M)
        [XdToken] Difficulty Standing Up from an Armless Chair (PFQ061I)
        [XdToken] Difficulty Stooping, Crouching or Kneeling (PFQ061D)
        [XdToken] Difficulty Walking a Quarter Mile (PFQ061B)
        [XdToken] Difficulty Walking Between Rooms (PFQ061H)
        [XdToken] Difficulty Walking Up Ten Stairs (PFQ061C)
        [XdToken] Experience Confusion or Memory Problems (PFQ057)
        [XdToken] Limitations Keeping You from Working (PFQ049)
        [XdToken] Need Special Equipment to Walk (PFQ054)
      [Cluster] NHANES Smoking
        [XdToken] Do You Now Smoke Cigarettes (SMQ040)
        [XdToken] Ever Used an E-cigarette (SMQ900)
        [XdToken] Smoked at Least 100 Cigarettes in Life (SMQ020)
        [XdToken] Smoking Status
        [XdCount] Age Started Smoking Cigarettes Regularly (SMD030)
        [XdCount] Average Cigarettes per Day, Past 30 Days (SMD650)
      [Cluster] NHANES Survey Design
        [XdToken] Data Release Cycle (SDDSRVYR)
        [XdToken] Interview/Examination Status (RIDSTATR)
        [XdCount] Masked Variance Pseudo-PSU (SDMVPSU)
        [XdCount] Masked Variance Pseudo-Stratum (SDMVSTRA)
        [XdQuantity] Full Sample 2 Year Interview Weight (WTINT2YR)
        [XdQuantity] Full Sample 2 Year MEC Exam Weight (WTMEC2YR)
    [Cluster] PROV Activity
      [XdString] Activity Description
      [XdString] Activity Identifier
      [XdString] Activity Label
      [XdString] Activity Location
      [XdString] Activity Type
      [XdString] Error Message
      [XdString] Had Plan Reference
      [XdString] Used Entity Reference
      [XdString] Was Associated With Reference
      [XdString] Was Ended By Reference
      [XdString] Was Informed By Reference
      [XdString] Was Started By Reference
      [XdToken] Activity Status
      [XdTemporal] Ended At
      [XdTemporal] Started At
    [Cluster] PROV Agent
      [XdString] Acted On Behalf Of Reference
      [XdString] Agent Description
      [XdString] Agent Email
      [XdString] Agent Identifier
      [XdString] Agent Name
      [XdString] Agent Organization Name
      [XdString] Software Name
      [XdString] Software Version
      [XdToken] PROV Agent Type
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| NHANES Participant Governed Record | `dcterms:publisher` | `https://axius-sdc.com` |
| NHANES Participant Governed Record | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| NHANES Participant Governed Record | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-participant-governed-record` |
| NHANES Participant Governed Record | `skos:exactMatch` | `http://www.w3.org/ns/prov#Entity` |
| Audit Event | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event` |
| Audit Event | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/AuditEvent` |
| Audit Agent Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Agent Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Agent Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-agent-reference` |
| Audit Agent Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.who` |
| Audit Agent Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bads7w1q6wmhn18u6dxwt28t` |
| Audit Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Entity Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-entity-reference` |
| Audit Entity Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.entity.what` |
| Audit Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-sjp1x177mlpq3howdltptm3c` |
| Audit Event Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-identifier` |
| Audit Event Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Data Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Data Subject Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Data Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/data-subject-reference` |
| Data Subject Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.patient` |
| Data Subject Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-x2rc9cg84d2famryqzdic0as` |
| On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| On Behalf Of Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/on-behalf-of-reference` |
| On Behalf Of Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/provenance-definitions.html#Provenance.agent.onBehalfOf` |
| On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-j9gvyx6u9pb7v1dd0m6joxd6` |
| System Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| System Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-identifier` |
| System Identifier | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.source.observer` |
| System Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-des67jo3ki9w0zgaz2i2t2cq` |
| System Location Name | `dcterms:publisher` | `https://axius-sdc.com` |
| System Location Name | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Location Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-location-name` |
| System Location Name | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.location` |
| System Location Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l6fwy1a2l5i43t308pknygp7` |
| Audit Event Action | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Action | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Action | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-action` |
| Audit Event Action | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-action` |
| Audit Event Action | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-o8lawuczf9vry55e98cjg12r` |
| Audit Event Outcome | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Outcome | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Outcome | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-outcome` |
| Audit Event Outcome | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-outcome` |
| Audit Event Outcome | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lgmleqp52a6kl268drrtfjk5` |
| Confidentiality | `dcterms:publisher` | `https://axius-sdc.com` |
| Confidentiality | `dcterms:source` | `http://terminology.hl7.org/` |
| Confidentiality | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/confidentiality` |
| Confidentiality | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-Confidentiality` |
| Confidentiality | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hp8q52t8tgmis92c4ljrfy7e` |
| Provenance Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Provenance Agent Type | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Provenance Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/provenance-agent-type` |
| Provenance Agent Type | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/provenance-participant-type` |
| Provenance Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-syt8l7pmb64eym2chcn43ai7` |
| Purpose of Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Purpose of Use | `dcterms:source` | `http://terminology.hl7.org/` |
| Purpose of Use | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/purpose-of-use` |
| Purpose of Use | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActReason` |
| Purpose of Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-y87ikto4p56zlkx4o2d63ain` |
| Audit Recorded At | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Recorded At | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Recorded At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-recorded-at` |
| Audit Recorded At | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.recorded` |
| NHANES Participant | `dcterms:publisher` | `https://axius-sdc.com` |
| NHANES Participant | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-participant` |
| NHANES Participant | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| NHANES Participant | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C41189` |
| Respondent Sequence Number (SEQN) | `dcterms:publisher` | `https://axius-sdc.com` |
| Respondent Sequence Number (SEQN) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-respondent-sequence-number` |
| Respondent Sequence Number (SEQN) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Respondent Sequence Number (SEQN) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#SEQN` |
| NHANES Blood Pressure | `dcterms:publisher` | `https://axius-sdc.com` |
| NHANES Blood Pressure | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-blood-pressure` |
| NHANES Blood Pressure | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| NHANES Blood Pressure | `skos:exactMatch` | `https://loinc.org/85354-9/` |
| Arm Selected (BPAARM) | `dcterms:publisher` | `https://axius-sdc.com` |
| Arm Selected (BPAARM) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-arm-selected` |
| Arm Selected (BPAARM) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Arm Selected (BPAARM) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/BPX_J.htm#BPAARM` |
| Coded Cuff Size (BPACSZ) | `dcterms:publisher` | `https://axius-sdc.com` |
| Coded Cuff Size (BPACSZ) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-coded-cuff-size` |
| Coded Cuff Size (BPACSZ) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Coded Cuff Size (BPACSZ) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/BPX_J.htm#BPACSZ` |
| Pulse Regular or Irregular (BPXPULS) | `dcterms:publisher` | `https://axius-sdc.com` |
| Pulse Regular or Irregular (BPXPULS) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-pulse-regularity` |
| Pulse Regular or Irregular (BPXPULS) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Pulse Regular or Irregular (BPXPULS) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/BPX_J.htm#BPXPULS` |
| Maximum Inflation Level (BPXML1) | `dcterms:publisher` | `https://axius-sdc.com` |
| Maximum Inflation Level (BPXML1) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-maximum-inflation-level` |
| Maximum Inflation Level (BPXML1) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Maximum Inflation Level (BPXML1) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/BPX_J.htm#BPXML1` |
| Heart Rate | `dcterms:publisher` | `https://axius-sdc.com` |
| Heart Rate | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Heart Rate | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/heart-rate` |
| Heart Rate | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Heart Rate | `skos:exactMatch` | `https://loinc.org/8867-4/` |
| Heart Rate | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uzyj5sccijtoppr2j7szwaj0` |
| Blood Pressure Reading 1 | `dcterms:publisher` | `https://axius-sdc.com` |
| Blood Pressure Reading 1 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-blood-pressure-reading-1` |
| Blood Pressure Reading 1 | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Blood Pressure Reading 1 | `skos:exactMatch` | `https://loinc.org/85354-9/` |
| Blood Pressure | `dcterms:publisher` | `https://axius-sdc.com` |
| Blood Pressure | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Blood Pressure | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/blood-pressure` |
| Blood Pressure | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/Observation` |
| Blood Pressure | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-aswsw3sct9bnujj53q8g2r5s` |
| Observation Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Observation Status | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Observation Status | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/observation-status` |
| Observation Status | `skos:closeMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.status` |
| Observation Status | `skos:exactMatch` | `http://hl7.org/fhir/observation-status` |
| Observation Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uulveklfu0gsttxdsb5w0daw` |
| Diastolic Blood Pressure | `dcterms:publisher` | `https://axius-sdc.com` |
| Diastolic Blood Pressure | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Diastolic Blood Pressure | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/diastolic-blood-pressure` |
| Diastolic Blood Pressure | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Diastolic Blood Pressure | `skos:exactMatch` | `https://loinc.org/8462-4/` |
| Diastolic Blood Pressure | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-on1yxktbzpmkrfha7vpy818u` |
| Systolic Blood Pressure | `dcterms:publisher` | `https://axius-sdc.com` |
| Systolic Blood Pressure | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Systolic Blood Pressure | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/systolic-blood-pressure` |
| Systolic Blood Pressure | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Systolic Blood Pressure | `skos:exactMatch` | `https://loinc.org/8480-6/` |
| Systolic Blood Pressure | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-zcqdrf41l9x3y4kc6kk472zi` |
| Observation Date Time | `dcterms:publisher` | `https://axius-sdc.com` |
| Observation Date Time | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Observation Date Time | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/observation-datetime` |
| Observation Date Time | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.effectiveDateTime` |
| Observation Date Time | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uwjplwpntsl4q5mckbmb7lhi` |
| Body Site (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Body Site (SNOMED CT) | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Body Site (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/body-site` |
| Body Site (SNOMED CT) | `skos:closeMatch` | `http://snomed.info/sct` |
| Body Site (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.bodySite` |
| Code System: SNOMED CT | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: SNOMED CT | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/system-snomed` |
| Code System: SNOMED CT | `skos:exactMatch` | `http://snomed.info/sct` |
| Code System: SNOMED CT | `dcterms:source` | `http://snomed.info/sct` |
| Body Site Code (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Body Site Code (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/body-site-code` |
| Body Site Code (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.bodySite` |
| Body Site Code (SNOMED CT) | `skos:exactMatch` | `http://snomed.info/sct` |
| Body Site Code (SNOMED CT) | `dcterms:source` | `http://snomed.info/sct` |
| Body Site Code (SNOMED CT) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w8ydi05lu9vtr4cxwvnc7cs5` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| Blood Pressure Reading 2 | `dcterms:publisher` | `https://axius-sdc.com` |
| Blood Pressure Reading 2 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-blood-pressure-reading-2` |
| Blood Pressure Reading 2 | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Blood Pressure Reading 2 | `skos:exactMatch` | `https://loinc.org/85354-9/` |
| Blood Pressure Reading 3 | `dcterms:publisher` | `https://axius-sdc.com` |
| Blood Pressure Reading 3 | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-blood-pressure-reading-3` |
| Blood Pressure Reading 3 | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Blood Pressure Reading 3 | `skos:exactMatch` | `https://loinc.org/85354-9/` |
| NHANES Demographics | `dcterms:publisher` | `https://axius-sdc.com` |
| NHANES Demographics | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-demographics` |
| NHANES Demographics | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| NHANES Demographics | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C16495` |
| Annual Household Income (INDHHIN2) | `dcterms:publisher` | `https://axius-sdc.com` |
| Annual Household Income (INDHHIN2) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-annual-household-income` |
| Annual Household Income (INDHHIN2) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Annual Household Income (INDHHIN2) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#INDHHIN2` |
| Citizenship Status (DMDCITZN) | `dcterms:publisher` | `https://axius-sdc.com` |
| Citizenship Status (DMDCITZN) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-citizenship-status` |
| Citizenship Status (DMDCITZN) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Citizenship Status (DMDCITZN) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#DMDCITZN` |
| Country of Birth (DMDBORN4) | `dcterms:publisher` | `https://axius-sdc.com` |
| Country of Birth (DMDBORN4) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-country-of-birth` |
| Country of Birth (DMDBORN4) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Country of Birth (DMDBORN4) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#DMDBORN4` |
| Education Level - Adults 20+ (DMDEDUC2) | `dcterms:publisher` | `https://axius-sdc.com` |
| Education Level - Adults 20+ (DMDEDUC2) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-education-level-adults` |
| Education Level - Adults 20+ (DMDEDUC2) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Education Level - Adults 20+ (DMDEDUC2) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#DMDEDUC2` |
| Gender (RIAGENDR) | `dcterms:publisher` | `https://axius-sdc.com` |
| Gender (RIAGENDR) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-gender-code` |
| Gender (RIAGENDR) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Gender (RIAGENDR) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#RIAGENDR` |
| Marital Status (DMDMARTL) | `dcterms:publisher` | `https://axius-sdc.com` |
| Marital Status (DMDMARTL) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-marital-status` |
| Marital Status (DMDMARTL) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Marital Status (DMDMARTL) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#DMDMARTL` |
| Pregnancy Status at Exam (RIDEXPRG) | `dcterms:publisher` | `https://axius-sdc.com` |
| Pregnancy Status at Exam (RIDEXPRG) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-pregnancy-status-at-exam` |
| Pregnancy Status at Exam (RIDEXPRG) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Pregnancy Status at Exam (RIDEXPRG) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#RIDEXPRG` |
| Race/Hispanic Origin with NH Asian (RIDRETH3) | `dcterms:publisher` | `https://axius-sdc.com` |
| Race/Hispanic Origin with NH Asian (RIDRETH3) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-race-hispanic-origin` |
| Race/Hispanic Origin with NH Asian (RIDRETH3) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Race/Hispanic Origin with NH Asian (RIDRETH3) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#RIDRETH3` |
| Veteran Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Veteran Status | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Veteran Status | `dcterms:identifier` | `https://axius-sdc.com/library/fair/veteran-status` |
| Veteran Status | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#DMQMILIZ` |
| Veteran Status | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C17742` |
| Are you pregnant now? | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C25742` |
| Are you pregnant now? | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C25471` |
| Are you pregnant now? | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C25180` |
| Are you pregnant now? | `dcterms:source` | `https://cde.nlm.nih.gov/deView?tinyId=LiUWCWluP` |
| Are you pregnant now? | `dcterms:publisher` | `http://www.wikidata.org/entity/Q390551` |
| Are you pregnant now? | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C25190` |
| Are you pregnant now? | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-a35l6khng8f63x6jgfs450lf` |
| Current Educational Attainment | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C17953` |
| Current Educational Attainment | `dcterms:source` | `https://cde.nlm.nih.gov/deView?tinyId=Co2d1RyYS3` |
| Current Educational Attainment | `dcterms:publisher` | `http://www.wikidata.org/entity/Q390551` |
| Current Educational Attainment | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C25190` |
| Current Educational Attainment | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-u0t7nkb38c0sk5baielllqld` |
| Marital Status | `dcterms:source` | `https://cde.nlm.nih.gov/deView?tinyId=C6SezX_mKG` |
| Marital Status | `dcterms:publisher` | `http://www.wikidata.org/entity/Q6973755` |
| Marital Status | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C25188` |
| Marital Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qmqis7vj5dmx3m9adbbvlb7r` |
| Race/Ethnicity Self-Identification | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C16564` |
| Race/Ethnicity Self-Identification | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C74528` |
| Race/Ethnicity Self-Identification | `dcterms:source` | `https://cde.nlm.nih.gov/deView?tinyId=LakF0YkywC` |
| Race/Ethnicity Self-Identification | `dcterms:publisher` | `http://www.wikidata.org/entity/Q6973755` |
| Race/Ethnicity Self-Identification | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C17049` |
| Race/Ethnicity Self-Identification | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hmc3dce8i1muhh9nr5bkbj92` |
| Administrative Gender | `dcterms:publisher` | `https://axius-sdc.com` |
| Administrative Gender | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Administrative Gender | `dcterms:identifier` | `https://axius-sdc.com/library/default/administrative-gender` |
| Administrative Gender | `skos:exactMatch` | `http://hl7.org/fhir/administrative-gender` |
| Administrative Gender | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tnyh2ude3db9smwfin0vai5h` |
| Age in Months at Screening (RIDAGEMN) | `dcterms:publisher` | `https://axius-sdc.com` |
| Age in Months at Screening (RIDAGEMN) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-age-in-months-at-screening` |
| Age in Months at Screening (RIDAGEMN) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Age in Months at Screening (RIDAGEMN) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#RIDAGEMN` |
| Total Number of People in the Household (DMDHHSIZ) | `dcterms:publisher` | `https://axius-sdc.com` |
| Total Number of People in the Household (DMDHHSIZ) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-household-size` |
| Total Number of People in the Household (DMDHHSIZ) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Total Number of People in the Household (DMDHHSIZ) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#DMDHHSIZ` |
| Age | `dcterms:source` | `https://cde.nlm.nih.gov/deView?tinyId=PDjBiGXjO` |
| Age | `dcterms:publisher` | `http://www.wikidata.org/entity/Q6973755` |
| Age | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C25150` |
| Age | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-cb4ti4afgfe9wd641tflfrdj` |
| Ratio of Family Income to Poverty (INDFMPIR) | `dcterms:publisher` | `https://axius-sdc.com` |
| Ratio of Family Income to Poverty (INDFMPIR) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-family-income-poverty-ratio` |
| Ratio of Family Income to Poverty (INDFMPIR) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Ratio of Family Income to Poverty (INDFMPIR) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#INDFMPIR` |
| NHANES Laboratory Results | `dcterms:publisher` | `https://axius-sdc.com` |
| NHANES Laboratory Results | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-laboratory-results` |
| NHANES Laboratory Results | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| NHANES Laboratory Results | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/Observation` |
| Basophils Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Basophils Number | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-basophil-count` |
| Basophils Number | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Basophils Number | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBDBANO` |
| Basophils Number | `skos:exactMatch` | `https://loinc.org/704-7/` |
| Basophils Percent | `dcterms:publisher` | `https://axius-sdc.com` |
| Basophils Percent | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-basophil-percent` |
| Basophils Percent | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Basophils Percent | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBXBAPCT` |
| Basophils Percent | `skos:exactMatch` | `https://loinc.org/706-2/` |
| Eosinophils Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Eosinophils Number | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-eosinophil-count` |
| Eosinophils Number | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Eosinophils Number | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBDEONO` |
| Eosinophils Number | `skos:exactMatch` | `https://loinc.org/711-2/` |
| Eosinophils Percent | `dcterms:publisher` | `https://axius-sdc.com` |
| Eosinophils Percent | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-eosinophil-percent` |
| Eosinophils Percent | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Eosinophils Percent | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBXEOPCT` |
| Eosinophils Percent | `skos:exactMatch` | `https://loinc.org/713-8/` |
| Hematocrit | `dcterms:publisher` | `https://axius-sdc.com` |
| Hematocrit | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-hematocrit` |
| Hematocrit | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Hematocrit | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBXHCT` |
| Hematocrit | `skos:exactMatch` | `https://loinc.org/4544-3/` |
| Hemoglobin | `dcterms:publisher` | `https://axius-sdc.com` |
| Hemoglobin | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-hemoglobin` |
| Hemoglobin | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Hemoglobin | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBXHGB` |
| Hemoglobin | `skos:exactMatch` | `https://loinc.org/718-7/` |
| Lymphocyte Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Lymphocyte Number | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-lymphocyte-count` |
| Lymphocyte Number | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Lymphocyte Number | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBDLYMNO` |
| Lymphocyte Number | `skos:exactMatch` | `https://loinc.org/731-0/` |
| Lymphocyte Percent | `dcterms:publisher` | `https://axius-sdc.com` |
| Lymphocyte Percent | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-lymphocyte-percent` |
| Lymphocyte Percent | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Lymphocyte Percent | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBXLYPCT` |
| Lymphocyte Percent | `skos:exactMatch` | `https://loinc.org/736-9/` |
| Mean Cell Hemoglobin | `dcterms:publisher` | `https://axius-sdc.com` |
| Mean Cell Hemoglobin | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-mean-cell-hemoglobin` |
| Mean Cell Hemoglobin | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Mean Cell Hemoglobin | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBXMCHSI` |
| Mean Cell Hemoglobin | `skos:exactMatch` | `https://loinc.org/785-6/` |
| Mean Cell Hemoglobin Concentration | `dcterms:publisher` | `https://axius-sdc.com` |
| Mean Cell Hemoglobin Concentration | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-mean-cell-hemoglobin-concentration` |
| Mean Cell Hemoglobin Concentration | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Mean Cell Hemoglobin Concentration | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBXMC` |
| Mean Cell Hemoglobin Concentration | `skos:exactMatch` | `https://loinc.org/786-4/` |
| Mean Cell Volume | `dcterms:publisher` | `https://axius-sdc.com` |
| Mean Cell Volume | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-mean-cell-volume` |
| Mean Cell Volume | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Mean Cell Volume | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBXMCVSI` |
| Mean Cell Volume | `skos:exactMatch` | `https://loinc.org/787-2/` |
| Mean Platelet Volume | `dcterms:publisher` | `https://axius-sdc.com` |
| Mean Platelet Volume | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-mean-platelet-volume` |
| Mean Platelet Volume | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Mean Platelet Volume | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBXMPSI` |
| Mean Platelet Volume | `skos:exactMatch` | `https://loinc.org/32623-1/` |
| Monocyte Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Monocyte Number | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-monocyte-count` |
| Monocyte Number | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Monocyte Number | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBDMONO` |
| Monocyte Number | `skos:exactMatch` | `https://loinc.org/742-7/` |
| Monocyte Percent | `dcterms:publisher` | `https://axius-sdc.com` |
| Monocyte Percent | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-monocyte-percent` |
| Monocyte Percent | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Monocyte Percent | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBXMOPCT` |
| Monocyte Percent | `skos:exactMatch` | `https://loinc.org/5905-5/` |
| Nucleated Red Blood Cells | `dcterms:publisher` | `https://axius-sdc.com` |
| Nucleated Red Blood Cells | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-nucleated-red-blood-cells` |
| Nucleated Red Blood Cells | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Nucleated Red Blood Cells | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBXNRBC` |
| Platelet Count | `dcterms:publisher` | `https://axius-sdc.com` |
| Platelet Count | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-platelet-count` |
| Platelet Count | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Platelet Count | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBXPLTSI` |
| Platelet Count | `skos:exactMatch` | `https://loinc.org/777-3/` |
| Red Blood Cell Count | `dcterms:publisher` | `https://axius-sdc.com` |
| Red Blood Cell Count | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-red-blood-cell-count` |
| Red Blood Cell Count | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Red Blood Cell Count | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBXRBCSI` |
| Red Blood Cell Count | `skos:exactMatch` | `https://loinc.org/789-8/` |
| Red Cell Distribution Width | `dcterms:publisher` | `https://axius-sdc.com` |
| Red Cell Distribution Width | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-red-cell-distribution-width` |
| Red Cell Distribution Width | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Red Cell Distribution Width | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBXRDW` |
| Red Cell Distribution Width | `skos:exactMatch` | `https://loinc.org/788-0/` |
| Segmented Neutrophils Number | `dcterms:publisher` | `https://axius-sdc.com` |
| Segmented Neutrophils Number | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-neutrophil-count` |
| Segmented Neutrophils Number | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Segmented Neutrophils Number | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBDNENO` |
| Segmented Neutrophils Number | `skos:exactMatch` | `https://loinc.org/751-8/` |
| Segmented Neutrophils Percent | `dcterms:publisher` | `https://axius-sdc.com` |
| Segmented Neutrophils Percent | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-neutrophil-percent` |
| Segmented Neutrophils Percent | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Segmented Neutrophils Percent | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBXNEPCT` |
| Segmented Neutrophils Percent | `skos:exactMatch` | `https://loinc.org/770-8/` |
| Total Cholesterol | `dcterms:publisher` | `https://axius-sdc.com` |
| Total Cholesterol | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-total-cholesterol` |
| Total Cholesterol | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Total Cholesterol | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/TCHOL_J.htm#LBXTC` |
| Total Cholesterol | `skos:exactMatch` | `https://loinc.org/2093-3/` |
| Total Cholesterol (SI) | `dcterms:publisher` | `https://axius-sdc.com` |
| Total Cholesterol (SI) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-total-cholesterol-si` |
| Total Cholesterol (SI) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Total Cholesterol (SI) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/TCHOL_J.htm#LBDTCSI` |
| Total Cholesterol (SI) | `skos:exactMatch` | `https://loinc.org/2093-3/` |
| White Blood Cell Count | `dcterms:publisher` | `https://axius-sdc.com` |
| White Blood Cell Count | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-white-blood-cell-count` |
| White Blood Cell Count | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| White Blood Cell Count | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/CBC_J.htm#LBXWBCSI` |
| White Blood Cell Count | `skos:exactMatch` | `https://loinc.org/6690-2/` |
| NHANES Medical Conditions | `dcterms:publisher` | `https://axius-sdc.com` |
| NHANES Medical Conditions | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-medical-conditions` |
| NHANES Medical Conditions | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| NHANES Medical Conditions | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C2991` |
| Doctor Ever Said You Were Overweight (MCQ080) | `dcterms:publisher` | `https://axius-sdc.com` |
| Doctor Ever Said You Were Overweight (MCQ080) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-doctor-said-overweight` |
| Doctor Ever Said You Were Overweight (MCQ080) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Doctor Ever Said You Were Overweight (MCQ080) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/MCQ_J.htm#MCQ080` |
| Still Have Asthma (MCQ035) | `dcterms:publisher` | `https://axius-sdc.com` |
| Still Have Asthma (MCQ035) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-still-have-asthma` |
| Still Have Asthma (MCQ035) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Still Have Asthma (MCQ035) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/MCQ_J.htm#MCQ035` |
| Chronic Condition Indicators | `dcterms:publisher` | `https://axius-sdc.com` |
| Chronic Condition Indicators | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Chronic Condition Indicators | `dcterms:identifier` | `https://axius-sdc.com/library/fair/chronic-condition-indicators` |
| Chronic Condition Indicators | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C2991` |
| Condition: Alzheimer's Disease or Related Disorder | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Alzheimer's Disease or Related Disorder | `dcterms:subject` | `http://snomed.info/id/26929004` |
| Condition: Alzheimer's Disease or Related Disorder | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Alzheimer's Disease or Related Disorder | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-alzheimers-disease` |
| Condition: Angina | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Angina | `dcterms:subject` | `http://snomed.info/id/194828000` |
| Condition: Angina | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Angina | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-angina` |
| Condition: Arthritis | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Arthritis | `dcterms:subject` | `http://snomed.info/id/3723001` |
| Condition: Arthritis | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Arthritis | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-arthritis` |
| Condition: Asthma | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Asthma | `dcterms:subject` | `http://snomed.info/id/195967001` |
| Condition: Asthma | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Asthma | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-asthma` |
| Condition: Cancer | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Cancer | `dcterms:subject` | `http://snomed.info/id/363346000` |
| Condition: Cancer | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Cancer | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-cancer` |
| Condition: Chronic Bronchitis | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Chronic Bronchitis | `dcterms:subject` | `http://snomed.info/id/63480004` |
| Condition: Chronic Bronchitis | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Chronic Bronchitis | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-chronic-bronchitis` |
| Condition: Congestive Heart Failure | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Congestive Heart Failure | `dcterms:subject` | `http://snomed.info/id/42343007` |
| Condition: Congestive Heart Failure | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Congestive Heart Failure | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-congestive-heart-failure` |
| Condition: COPD | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: COPD | `dcterms:subject` | `http://snomed.info/id/13645005` |
| Condition: COPD | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: COPD | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-copd` |
| Condition: Coronary Heart Disease | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Coronary Heart Disease | `dcterms:subject` | `http://snomed.info/id/53741008` |
| Condition: Coronary Heart Disease | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Coronary Heart Disease | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-coronary-heart-disease` |
| Condition: Depression | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Depression | `dcterms:subject` | `http://snomed.info/id/35489007` |
| Condition: Depression | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Depression | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-depression` |
| Condition: Diabetes | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Diabetes | `dcterms:subject` | `http://snomed.info/id/73211009` |
| Condition: Diabetes | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Diabetes | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-diabetes` |
| Condition: Emphysema | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Emphysema | `dcterms:subject` | `http://snomed.info/id/87433001` |
| Condition: Emphysema | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Emphysema | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-emphysema` |
| Condition: Heart Attack | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Heart Attack | `dcterms:subject` | `http://snomed.info/id/22298006` |
| Condition: Heart Attack | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Heart Attack | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-heart-attack` |
| Condition: High Blood Pressure | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: High Blood Pressure | `dcterms:subject` | `http://snomed.info/id/38341003` |
| Condition: High Blood Pressure | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: High Blood Pressure | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-high-blood-pressure` |
| Condition: High Cholesterol | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: High Cholesterol | `dcterms:subject` | `http://snomed.info/id/13644009` |
| Condition: High Cholesterol | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: High Cholesterol | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-high-cholesterol` |
| Condition Indicator Basis | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition Indicator Basis | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition Indicator Basis | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-indicator-basis` |
| Condition Indicator Basis | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C25596` |
| Condition: Kidney Disease | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Kidney Disease | `dcterms:subject` | `http://snomed.info/id/709044004` |
| Condition: Kidney Disease | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Kidney Disease | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-kidney-disease` |
| Condition: Liver Condition | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Liver Condition | `dcterms:subject` | `http://snomed.info/id/235856003` |
| Condition: Liver Condition | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Liver Condition | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-liver-condition` |
| Condition: Osteoporosis | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Osteoporosis | `dcterms:subject` | `http://snomed.info/id/64859006` |
| Condition: Osteoporosis | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Osteoporosis | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-osteoporosis` |
| Condition: Skin Cancer | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Skin Cancer | `dcterms:subject` | `http://snomed.info/id/372130007` |
| Condition: Skin Cancer | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Skin Cancer | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-skin-cancer` |
| Condition: Stroke | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Stroke | `dcterms:subject` | `http://snomed.info/id/230690007` |
| Condition: Stroke | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Stroke | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-stroke` |
| Condition: Thyroid Problem | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Thyroid Problem | `dcterms:subject` | `http://snomed.info/id/14304000` |
| Condition: Thyroid Problem | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Thyroid Problem | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-thyroid-problem` |
| NHANES Physical Functioning | `dcterms:publisher` | `https://axius-sdc.com` |
| NHANES Physical Functioning | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-physical-functioning` |
| NHANES Physical Functioning | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| NHANES Physical Functioning | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C20000` |
| Difficulty Dressing Yourself (PFQ061L) | `dcterms:publisher` | `https://axius-sdc.com` |
| Difficulty Dressing Yourself (PFQ061L) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-dressing` |
| Difficulty Dressing Yourself (PFQ061L) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Difficulty Dressing Yourself (PFQ061L) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/PFQ_J.htm#PFQ061L` |
| Difficulty Getting In and Out of Bed (PFQ061J) | `dcterms:publisher` | `https://axius-sdc.com` |
| Difficulty Getting In and Out of Bed (PFQ061J) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-getting-in-and-out-of-bed` |
| Difficulty Getting In and Out of Bed (PFQ061J) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Difficulty Getting In and Out of Bed (PFQ061J) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/PFQ_J.htm#PFQ061J` |
| Difficulty Lifting or Carrying (PFQ061E) | `dcterms:publisher` | `https://axius-sdc.com` |
| Difficulty Lifting or Carrying (PFQ061E) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-lifting-or-carrying` |
| Difficulty Lifting or Carrying (PFQ061E) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Difficulty Lifting or Carrying (PFQ061E) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/PFQ_J.htm#PFQ061E` |
| Difficulty Standing for Long Periods (PFQ061M) | `dcterms:publisher` | `https://axius-sdc.com` |
| Difficulty Standing for Long Periods (PFQ061M) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-standing-for-long-periods` |
| Difficulty Standing for Long Periods (PFQ061M) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Difficulty Standing for Long Periods (PFQ061M) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/PFQ_J.htm#PFQ061M` |
| Difficulty Standing Up from an Armless Chair (PFQ061I) | `dcterms:publisher` | `https://axius-sdc.com` |
| Difficulty Standing Up from an Armless Chair (PFQ061I) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-standing-up-from-chair` |
| Difficulty Standing Up from an Armless Chair (PFQ061I) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Difficulty Standing Up from an Armless Chair (PFQ061I) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/PFQ_J.htm#PFQ061I` |
| Difficulty Stooping, Crouching or Kneeling (PFQ061D) | `dcterms:publisher` | `https://axius-sdc.com` |
| Difficulty Stooping, Crouching or Kneeling (PFQ061D) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-stooping-crouching-kneeling` |
| Difficulty Stooping, Crouching or Kneeling (PFQ061D) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Difficulty Stooping, Crouching or Kneeling (PFQ061D) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/PFQ_J.htm#PFQ061D` |
| Difficulty Walking a Quarter Mile (PFQ061B) | `dcterms:publisher` | `https://axius-sdc.com` |
| Difficulty Walking a Quarter Mile (PFQ061B) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-walking-quarter-mile` |
| Difficulty Walking a Quarter Mile (PFQ061B) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Difficulty Walking a Quarter Mile (PFQ061B) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/PFQ_J.htm#PFQ061B` |
| Difficulty Walking Between Rooms (PFQ061H) | `dcterms:publisher` | `https://axius-sdc.com` |
| Difficulty Walking Between Rooms (PFQ061H) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-walking-between-rooms` |
| Difficulty Walking Between Rooms (PFQ061H) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Difficulty Walking Between Rooms (PFQ061H) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/PFQ_J.htm#PFQ061H` |
| Difficulty Walking Up Ten Stairs (PFQ061C) | `dcterms:publisher` | `https://axius-sdc.com` |
| Difficulty Walking Up Ten Stairs (PFQ061C) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-walking-up-ten-stairs` |
| Difficulty Walking Up Ten Stairs (PFQ061C) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Difficulty Walking Up Ten Stairs (PFQ061C) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/PFQ_J.htm#PFQ061C` |
| Experience Confusion or Memory Problems (PFQ057) | `dcterms:publisher` | `https://axius-sdc.com` |
| Experience Confusion or Memory Problems (PFQ057) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-confusion-memory-problems` |
| Experience Confusion or Memory Problems (PFQ057) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Experience Confusion or Memory Problems (PFQ057) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/PFQ_J.htm#PFQ057` |
| Limitations Keeping You from Working (PFQ049) | `dcterms:publisher` | `https://axius-sdc.com` |
| Limitations Keeping You from Working (PFQ049) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-limitations-keeping-from-working` |
| Limitations Keeping You from Working (PFQ049) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Limitations Keeping You from Working (PFQ049) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/PFQ_J.htm#PFQ049` |
| Need Special Equipment to Walk (PFQ054) | `dcterms:publisher` | `https://axius-sdc.com` |
| Need Special Equipment to Walk (PFQ054) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-need-special-equipment-to-walk` |
| Need Special Equipment to Walk (PFQ054) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Need Special Equipment to Walk (PFQ054) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/PFQ_J.htm#PFQ054` |
| NHANES Smoking | `dcterms:publisher` | `https://axius-sdc.com` |
| NHANES Smoking | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-smoking` |
| NHANES Smoking | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| NHANES Smoking | `skos:exactMatch` | `https://loinc.org/72166-2/` |
| Do You Now Smoke Cigarettes (SMQ040) | `dcterms:publisher` | `https://axius-sdc.com` |
| Do You Now Smoke Cigarettes (SMQ040) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-now-smoke-cigarettes` |
| Do You Now Smoke Cigarettes (SMQ040) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Do You Now Smoke Cigarettes (SMQ040) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/SMQ_J.htm#SMQ040` |
| Ever Used an E-cigarette (SMQ900) | `dcterms:publisher` | `https://axius-sdc.com` |
| Ever Used an E-cigarette (SMQ900) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-ever-used-e-cigarette` |
| Ever Used an E-cigarette (SMQ900) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Ever Used an E-cigarette (SMQ900) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/SMQ_J.htm#SMQ900` |
| Smoked at Least 100 Cigarettes in Life (SMQ020) | `dcterms:publisher` | `https://axius-sdc.com` |
| Smoked at Least 100 Cigarettes in Life (SMQ020) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-smoked-100-cigarettes` |
| Smoked at Least 100 Cigarettes in Life (SMQ020) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Smoked at Least 100 Cigarettes in Life (SMQ020) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/SMQ_J.htm#SMQ020` |
| Smoked at Least 100 Cigarettes in Life (SMQ020) | `skos:closeMatch` | `https://loinc.org/63581-3/` |
| Smoking Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Smoking Status | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Smoking Status | `dcterms:identifier` | `https://axius-sdc.com/library/fair/smoking-status` |
| Smoking Status | `skos:exactMatch` | `https://loinc.org/72166-2/` |
| Age Started Smoking Cigarettes Regularly (SMD030) | `dcterms:publisher` | `https://axius-sdc.com` |
| Age Started Smoking Cigarettes Regularly (SMD030) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-age-started-smoking` |
| Age Started Smoking Cigarettes Regularly (SMD030) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Age Started Smoking Cigarettes Regularly (SMD030) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/SMQ_J.htm#SMD030` |
| Average Cigarettes per Day, Past 30 Days (SMD650) | `dcterms:publisher` | `https://axius-sdc.com` |
| Average Cigarettes per Day, Past 30 Days (SMD650) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-cigarettes-per-day-past-30-days` |
| Average Cigarettes per Day, Past 30 Days (SMD650) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Average Cigarettes per Day, Past 30 Days (SMD650) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/SMQ_J.htm#SMD650` |
| NHANES Survey Design | `dcterms:publisher` | `https://axius-sdc.com` |
| NHANES Survey Design | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-survey-design` |
| NHANES Survey Design | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| NHANES Survey Design | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C142700` |
| Data Release Cycle (SDDSRVYR) | `dcterms:publisher` | `https://axius-sdc.com` |
| Data Release Cycle (SDDSRVYR) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-data-release-cycle` |
| Data Release Cycle (SDDSRVYR) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Data Release Cycle (SDDSRVYR) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#SDDSRVYR` |
| Interview/Examination Status (RIDSTATR) | `dcterms:publisher` | `https://axius-sdc.com` |
| Interview/Examination Status (RIDSTATR) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-interview-examination-status` |
| Interview/Examination Status (RIDSTATR) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Interview/Examination Status (RIDSTATR) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#RIDSTATR` |
| Masked Variance Pseudo-PSU (SDMVPSU) | `dcterms:publisher` | `https://axius-sdc.com` |
| Masked Variance Pseudo-PSU (SDMVPSU) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-masked-variance-psu` |
| Masked Variance Pseudo-PSU (SDMVPSU) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Masked Variance Pseudo-PSU (SDMVPSU) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#SDMVPSU` |
| Masked Variance Pseudo-Stratum (SDMVSTRA) | `dcterms:publisher` | `https://axius-sdc.com` |
| Masked Variance Pseudo-Stratum (SDMVSTRA) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-masked-variance-stratum` |
| Masked Variance Pseudo-Stratum (SDMVSTRA) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Masked Variance Pseudo-Stratum (SDMVSTRA) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#SDMVSTRA` |
| Full Sample 2 Year Interview Weight (WTINT2YR) | `dcterms:publisher` | `https://axius-sdc.com` |
| Full Sample 2 Year Interview Weight (WTINT2YR) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-interview-weight` |
| Full Sample 2 Year Interview Weight (WTINT2YR) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Full Sample 2 Year Interview Weight (WTINT2YR) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#WTINT2YR` |
| Full Sample 2 Year MEC Exam Weight (WTMEC2YR) | `dcterms:publisher` | `https://axius-sdc.com` |
| Full Sample 2 Year MEC Exam Weight (WTMEC2YR) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/nhanes-mec-exam-weight` |
| Full Sample 2 Year MEC Exam Weight (WTMEC2YR) | `dcterms:source` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Full Sample 2 Year MEC Exam Weight (WTMEC2YR) | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#WTMEC2YR` |
| PROV Activity | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Activity | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-activity` |
| PROV Activity | `skos:exactMatch` | `http://www.w3.org/ns/prov#Activity` |
| PROV Activity | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-description` |
| Activity Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Activity Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-m9xg6e182m1oq77ssrf9iujv` |
| Activity Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-identifier` |
| Activity Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Activity Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fpnn1dew0kcevc8ptohndc5t` |
| Activity Label | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Label | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-label` |
| Activity Label | `skos:exactMatch` | `http://www.w3.org/2000/01/rdf-schema#label` |
| Activity Label | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Label | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-n4kaez29vbknku2jy8n56gfm` |
| Activity Location | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Location | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-location` |
| Activity Location | `skos:exactMatch` | `http://www.w3.org/ns/prov#atLocation` |
| Activity Location | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Location | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ciuklf1kl8bphpudye4i47am` |
| Activity Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-type` |
| Activity Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#type` |
| Activity Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ceusvbe55b266gcdzf5qnurc` |
| Error Message | `dcterms:publisher` | `https://axius-sdc.com` |
| Error Message | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/error-message` |
| Error Message | `dcterms:source` | `https://schema.org/` |
| Error Message | `skos:exactMatch` | `https://schema.org/error` |
| Error Message | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-eakhqr9l9nbblppgxc5fq25n` |
| Had Plan Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Had Plan Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/had-plan-reference` |
| Had Plan Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#hadPlan` |
| Had Plan Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Had Plan Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-xvdfh1nzfar33yxmgl3jgvqo` |
| Used Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Used Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/used-entity-reference` |
| Used Entity Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#used` |
| Used Entity Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Used Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ixv0fa8xlde52mdeymr4zaka` |
| Was Associated With Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Associated With Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-associated-with-reference` |
| Was Associated With Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasAssociatedWith` |
| Was Associated With Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Associated With Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gs0e1hp2rpjl6qfg9v8d047f` |
| Was Ended By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Ended By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-ended-by-reference` |
| Was Ended By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasEndedBy` |
| Was Ended By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Ended By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-jr1e3n5kg31nqz1ynh28kitp` |
| Was Informed By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Informed By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-informed-by-reference` |
| Was Informed By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasInformedBy` |
| Was Informed By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Informed By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rz60y6aujd274j4i7jpyxvpr` |
| Was Started By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Started By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-started-by-reference` |
| Was Started By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasStartedBy` |
| Was Started By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Started By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kmodjk1e5xu9z94zgiaxx1hu` |
| Activity Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Status | `dcterms:source` | `https://w3id.org/dpv` |
| Activity Status | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-status` |
| Activity Status | `skos:closeMatch` | `https://w3id.org/dpv#ActivityStatus` |
| Activity Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yehcpzf43j0b5zp9ck59t9eg` |
| Ended At | `dcterms:publisher` | `https://axius-sdc.com` |
| Ended At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/ended-at-time` |
| Ended At | `skos:exactMatch` | `http://www.w3.org/ns/prov#endedAtTime` |
| Ended At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Started At | `dcterms:publisher` | `https://axius-sdc.com` |
| Started At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/started-at-time` |
| Started At | `skos:exactMatch` | `http://www.w3.org/ns/prov#startedAtTime` |
| Started At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent` |
| PROV Agent | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Acted On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/acted-on-behalf-of-reference` |
| Acted On Behalf Of Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#actedOnBehalfOf` |
| Acted On Behalf Of Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dce4w62jxjngjnmc5y26fq66` |
| Agent Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-description` |
| Agent Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Agent Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w79xppnskig5vq31er8gh7nk` |
| Agent Email | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Email | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-email` |
| Agent Email | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/mbox` |
| Agent Email | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Email | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yp6pm5xyovxhkjimrrb8h9xy` |
| Agent Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-identifier` |
| Agent Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Agent Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hhfnj5hd1yzt252jfq5pdjj1` |
| Agent Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-name` |
| Agent Name | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/name` |
| Agent Name | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yya0pdgjd2w0wlz5r3h516om` |
| Agent Organization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Organization Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-organization-name` |
| Agent Organization Name | `dcterms:source` | `https://schema.org/` |
| Agent Organization Name | `skos:exactMatch` | `https://schema.org/legalName` |
| Agent Organization Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ifw5zfe4oiijbxjn1ylc2wm3` |
| Software Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-name` |
| Software Name | `dcterms:source` | `https://schema.org/` |
| Software Name | `skos:exactMatch` | `https://schema.org/SoftwareApplication` |
| Software Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rsjfjz8m5z7a58h5793duqbs` |
| Software Version | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Version | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-version` |
| Software Version | `dcterms:source` | `https://schema.org/` |
| Software Version | `skos:exactMatch` | `https://schema.org/softwareVersion` |
| Software Version | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tep9wanrrtqfw0k76huv6tvd` |
| PROV Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent-type` |
| PROV Agent Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-nesxtz8c5o665swc9lhvqkjj` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "NHANES Participant" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-xy8upneajsb8vdcmnve01g6g.xsd)
- Example instance (dm-xy8upneajsb8vdcmnve01g6g.xml)
- HTML documentation (dm-xy8upneajsb8vdcmnve01g6g.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"NHANES Participant" SDC4 schema (dm-xy8upneajsb8vdcmnve01g6g.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"NHANES Participant" schema (dm-xy8upneajsb8vdcmnve01g6g.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "NHANES Participant" SDC4 schema (dm-xy8upneajsb8vdcmnve01g6g.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "NHANES Participant" data model (dm-xy8upneajsb8vdcmnve01g6g.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-xy8upneajsb8vdcmnve01g6g.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-xy8upneajsb8vdcmnve01g6g.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-xy8upneajsb8vdcmnve01g6g.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-xy8upneajsb8vdcmnve01g6g.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-xy8upneajsb8vdcmnve01g6g.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
