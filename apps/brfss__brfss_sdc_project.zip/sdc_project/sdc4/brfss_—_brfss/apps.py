"""
Django app configuration for brfss_—_brfss.
"""
from django.apps import AppConfig


class Brfss_—_brfssConfig(AppConfig):
    """App configuration for brfss_—_brfss."""

    default_auto_field = 'django.db.models.BigAutoField'
    name = 'brfss_—_brfss'

    def ready(self):
        """
        Import signals when app is ready.

        This ensures that signal handlers are registered when Django starts.
        """
        import brfss_—_brfss.signals  # noqa: F401
