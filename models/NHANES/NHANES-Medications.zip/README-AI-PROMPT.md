# NHANES — Medications

**Model ID**: `dm-g72xhdxvd7q53qnxx6dsczg5`
**Project**: FAIR Data Demo
**Description**: SDC4 data model for National Health and Nutrition Examination Survey (nhanes_medications) — FAIR Data Demo

### Dublin Core Metadata
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal

## Package Contents

- `dm-g72xhdxvd7q53qnxx6dsczg5.xsd` -- XML Schema Definition (data model structure)
- `dm-g72xhdxvd7q53qnxx6dsczg5.xml` -- XML instance example with sample data
- `dm-g72xhdxvd7q53qnxx6dsczg5-instance.json` -- JSON instance example (same structure as XML)
- `dm-g72xhdxvd7q53qnxx6dsczg5.jsonld` -- JSON-LD semantic schema description
- `dm-g72xhdxvd7q53qnxx6dsczg5.html` -- Human-readable model documentation
- `dm-g72xhdxvd7q53qnxx6dsczg5_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-g72xhdxvd7q53qnxx6dsczg5.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-g72xhdxvd7q53qnxx6dsczg5.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-g72xhdxvd7q53qnxx6dsczg5.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-g72xhdxvd7q53qnxx6dsczg5.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **nhanes-medications** | Cluster | `df4ef4clwf51373rjxnf7rul` | 11 components |
|   Generic drug code | XdString | `eoxjur7v0l8heudfh2ht2oqb` | minLen=1; maxLen=200 |
|   ICD-10-CM code 1 | XdString | `dmies2nxdbt0yp2sq6249a8i` | minLen=1; maxLen=200 |
|   ICD-10-CM code 2 | XdString | `gfzey96vu7jrstwfi1520u0u` | minLen=1; maxLen=200 |
|   ICD-10-CM code 3 | XdString | `rbgl2g3qv04owwyodn3hucf0` | minLen=1; maxLen=200 |
|   Dependent Sequence Number | XdString | `bxpnk5cd59ghc0xw2aswgjze` | maxLen=9 |
|   AE Description | XdString | `pp5v32ipc0xbva1hi5l3r91g` | minLen=1; maxLen=2000 |
|   Generic or investigational drug name of Medication | XdString | `t0am9e7j89dyzngjnphr8q26` | maxLen=255 |
|   Container Service Type | XdToken | `p6t91ija5d3v8ju06lxmrvca` | 4 enum(s) |
|   Number of days taken medicine | XdQuantity | `a4gsbuoc8ezh2a2wsf1tlhnk` | units=RXDDAYS_units |
|   Taken prescription medicine, past month | XdQuantity | `imrhad1ziiactitsimpfvl7i` | units=RXDUSE_units |
|   Prescription Date | XdTemporal | `cq6m46w59ouu1cu8tkw1fhib` | -- |

## Structural Hierarchy

```
DM: NHANES — Medications
  [Cluster] nhanes-medications
    [XdString] Generic drug code
    [XdString] ICD-10-CM code 1
    [XdString] ICD-10-CM code 2
    [XdString] ICD-10-CM code 3
    [XdString] Dependent Sequence Number
    [XdString] AE Description
    [XdString] Generic or investigational drug name of Medication
    [XdToken] Container Service Type
    [XdQuantity] Number of days taken medicine
    [XdQuantity] Taken prescription medicine, past month
    [XdTemporal] Prescription Date
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| nhanes-medications | `rdfs:isDefinedBy` | `http://semanticscience.org/resource/SIO_001382` |
| Generic drug code | `rdfs:isDefinedBy` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Generic drug code | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q7180748` |
| Generic drug code | `dcterms:subject` | `http://snomed.info/id/182832007` |
| ICD-10-CM code 1 | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q5969475` |
| ICD-10-CM code 1 | `rdfs:isDefinedBy` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| ICD-10-CM code 1 | `skos:closeMatch` | `http://snomed.info/id/439401001` |
| ICD-10-CM code 1 | `dcterms:subject` | `http://snomed.info/id/182832007` |
| ICD-10-CM code 2 | `rdfs:isDefinedBy` | `https://schema.org/code` |
| ICD-10-CM code 2 | `rdfs:isDefinedBy` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| ICD-10-CM code 2 | `dcterms:subject` | `http://snomed.info/id/182832007` |
| ICD-10-CM code 3 | `rdfs:isDefinedBy` | `https://schema.org/code` |
| ICD-10-CM code 3 | `rdfs:isDefinedBy` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| ICD-10-CM code 3 | `dcterms:subject` | `http://snomed.info/id/182832007` |
| Dependent Sequence Number | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q29635268` |
| Dependent Sequence Number | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1061489` |
| AE Description | `rdfs:isDefinedBy` | `https://uts.nlm.nih.gov/uts/umls/concept/C1623626` |
| AE Description | `rdf:type` | `https://schema.org/Text` |
| Generic or investigational drug name of Medication | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q390551` |
| Generic or investigational drug name of Medication | `rdfs:seeAlso` | `https://www.wikidata.org/wiki/Q208478` |
| Container Service Type | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q170585` |
| Container Service Type | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1061489` |
| Number of days taken medicine | `rdfs:isDefinedBy` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Number of days taken medicine | `dcterms:subject` | `http://snomed.info/id/182832007` |
| Taken prescription medicine, past month | `rdfs:isDefinedBy` | `http://www.ontology-of-units-of-measure.org/resource/om-2/month` |
| Taken prescription medicine, past month | `rdfs:isDefinedBy` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Taken prescription medicine, past month | `dcterms:subject` | `http://snomed.info/id/182832007` |
| Prescription Date | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q193521` |
| Prescription Date | `skos:broadMatch` | `https://schema.org/DateTime` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "NHANES — Medications" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-g72xhdxvd7q53qnxx6dsczg5.xsd)
- Example instance (dm-g72xhdxvd7q53qnxx6dsczg5.xml)
- HTML documentation (dm-g72xhdxvd7q53qnxx6dsczg5.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"NHANES — Medications" SDC4 schema (dm-g72xhdxvd7q53qnxx6dsczg5.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"NHANES — Medications" schema (dm-g72xhdxvd7q53qnxx6dsczg5.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "NHANES — Medications" SDC4 schema (dm-g72xhdxvd7q53qnxx6dsczg5.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "NHANES — Medications" data model (dm-g72xhdxvd7q53qnxx6dsczg5.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-g72xhdxvd7q53qnxx6dsczg5.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-g72xhdxvd7q53qnxx6dsczg5.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-g72xhdxvd7q53qnxx6dsczg5.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-g72xhdxvd7q53qnxx6dsczg5.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-g72xhdxvd7q53qnxx6dsczg5.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
