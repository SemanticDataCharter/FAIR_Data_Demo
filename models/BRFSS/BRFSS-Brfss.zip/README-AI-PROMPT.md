# BRFSS — Brfss

**Model ID**: `dm-ffq1c2tkbzexmxqnrxg48oqj`
**Project**: FAIR Data Demo
**Description**: SDC4 data model for Behavioral Risk Factor Surveillance System (brfss) — FAIR Data Demo

### Dublin Core Metadata
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal

## Package Contents

- `dm-ffq1c2tkbzexmxqnrxg48oqj.xsd` -- XML Schema Definition (data model structure)
- `dm-ffq1c2tkbzexmxqnrxg48oqj.xml` -- XML instance example with sample data
- `dm-ffq1c2tkbzexmxqnrxg48oqj-instance.json` -- JSON instance example (same structure as XML)
- `dm-ffq1c2tkbzexmxqnrxg48oqj.jsonld` -- JSON-LD semantic schema description
- `dm-ffq1c2tkbzexmxqnrxg48oqj.html` -- Human-readable model documentation
- `dm-ffq1c2tkbzexmxqnrxg48oqj_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-ffq1c2tkbzexmxqnrxg48oqj.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-ffq1c2tkbzexmxqnrxg48oqj.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-ffq1c2tkbzexmxqnrxg48oqj.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-ffq1c2tkbzexmxqnrxg48oqj.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **brfss** | Cluster | `rd06dge0m5z2u5s1if9u905b` | 326 components |
|   Age Told Had Cancer | XdString | `p4w0n9787r2xwd5ekc5jn8qs` | minLen=1; maxLen=200; 3 enum(s) |
|   Any Firearms in Home | XdString | `a4yxvbcuntuyl3e35nn4ngdf` | minLen=1; maxLen=200; 4 enum(s) |
|   Any Firearms Loaded | XdString | `jjbn5jotdid4i2utdzqzyc1r` | minLen=1; maxLen=200; 4 enum(s) |
|   Any Loaded Firearms Also Unlocked | XdString | `zp6p8qb89w083irwkdb8a0ml` | minLen=1; maxLen=200; 4 enum(s) |
|   Are you 18 years of age or older? | XdString | `h1cnekyn5482zasugd7971lu` | minLen=1; maxLen=200; 1 enum(s) |
|   Are You Doing Anything to Keep From Getting Pregnant? | XdString | `xdijqxn94ox8v8sg5l8y3bpy` | minLen=1; maxLen=200; 15 enum(s) |
|   Are you male or female? | XdString | `jxo0034hxyy5t5q82ly4jatz` | minLen=1; maxLen=200; 5 enum(s) |
|   Are you male or female? | XdString | `pznacl3p5tul0wog5j3roaio` | minLen=1; maxLen=200; 2 enum(s) |
|   Are you male or female? | XdString | `qmcbgoh0afzv6h0fpowmamm1` | minLen=1; maxLen=200; 4 enum(s) |
|   Asked during checkup if you drink alchohol | XdString | `q852kr76prjwhhw2hb08t8a4` | minLen=1; maxLen=200; 4 enum(s) |
|   Asked in person or by form how much you drink? | XdString | `oba5a7vmnyy8lxo98rnx86vj` | minLen=1; maxLen=200; 4 enum(s) |
|   Asked whether you drank [5 FOR MEN /4 FOR WOMEN] or more alcoholic drinks on an occasion? | XdString | `zsvosfp6gnzdiwictxzwtxur` | minLen=1; maxLen=200; 4 enum(s) |
|   Child´s sex at birth | XdString | `qjus7soypr53n8nj6kje28mg` | minLen=1; maxLen=200; 3 enum(s) |
|   Child still have asthma? | XdString | `xa5vot1z62qk6idrzbyhovpg` | minLen=1; maxLen=200; 4 enum(s) |
|   Computed drink-occasions-per-day | XdString | `gsfg2stxz7svogl3hcty0f9c` | minLen=1; maxLen=200; 3 enum(s) |
|   Computed number of drinks of alcohol beverages per week | XdString | `sfj7p74msngohmrc68vt6d5p` | minLen=1; maxLen=200; 3 enum(s) |
|   Correct Phone Number? | XdString | `w7xejt6iph0dj7vao4fju46v` | minLen=7; maxLen=20; 2 enum(s) |
|   Currently Have Physical Pain From Cancer Or Treatment? | XdString | `sb6d71r1vl3bgaif36ojtctn` | minLen=1; maxLen=200; 4 enum(s) |
|   Currently Receiving Treatment for Cancer | XdString | `sz90v0fc80g3ckwf283xb6fd` | minLen=1; maxLen=200; 7 enum(s) |
|   Did an adult make sure basic needs were met | XdString | `pnaj34uaa8qyfjn52izknnlq` | minLen=1; maxLen=200; 7 enum(s) |
|   Did an adult make you feel safe and protected | XdString | `aub4n5e6mpw7c8at1ebzngpa` | minLen=1; maxLen=200; 7 enum(s) |
|   Did Health Insurance Pay For All Of Your Cancer Treatment | XdString | `mu96hgfei3lsyrtrwvaz3ycg` | exactLen=17; 4 enum(s) |
|   Did you cough up phlegm? | XdString | `qcx0zoakn4cxa0vkbpv2tjdy` | minLen=1; maxLen=200; 4 enum(s) |
|   Did you dab marijuana or cannabis? | XdString | `eypok22qzxklocbs41fpxuft` | minLen=1; maxLen=200; 4 enum(s) |
|   Did you do anything to keep from getting pregnant? | XdString | `okdv5ktn57g2nmdihy68y05a` | minLen=1; maxLen=200; 4 enum(s) |
|   Did you eat marijuana or cannabis? | XdString | `dpbjlyttkjztvr520b957afo` | minLen=1; maxLen=200; 4 enum(s) |
|   Did you have a cough? | XdString | `br3b9c5i2aka2r2kzcff3csv` | minLen=1; maxLen=200; 4 enum(s) |
|   Did you have shortness of breath? | XdString | `v17b2236z9npvzo97jqd51j2` | minLen=1; maxLen=200; 4 enum(s) |
|   Did You Receive a Summary of Cancer Treatments Received | XdString | `ij6vtmo4n57mz6b8xo2cyhu9` | minLen=1; maxLen=200; 4 enum(s) |
|   Did you smoke marijuana or cannabis? | XdString | `av0ay717ubhbdjmr70inrbo6` | minLen=1; maxLen=200; 4 enum(s) |
|   Did you talk about the advantages or disadvantages of P.S.A. test | XdString | `nvh8655g1cwnl87uyqy41n98` | minLen=1; maxLen=200; 6 enum(s) |
|   Did you use marijuana or cannabis some other way? | XdString | `mshl0x9bmbcyt5tv2snnyb15` | minLen=1; maxLen=200; 4 enum(s) |
|   Did you vape marijuana or cannabis? | XdString | `lgl5k8tqvkcnskvt67gzx364` | minLen=1; maxLen=200; 4 enum(s) |
|   Does confusion or memory loss interfere with work or social activities | XdString | `v2h5t219mpfuhclfdga5lwyo` | minLen=1; maxLen=200; 7 enum(s) |
|   Does Person Being Cared For Have Alzheimer´s Disease? | XdString | `l2hx0wp1g7m7vrdhjq8gfmbt` | minLen=1; maxLen=200; 4 enum(s) |
|   Do you also have a landline telephone? | XdString | `yl7wjzqmv0rgkt3frgotowz2` | minLen=1; maxLen=200; 4 enum(s) |
|   Do you consider yourself to be transgender? | XdString | `itjsvp8fepj5t2ak3d38pub7` | minLen=1; maxLen=200; 6 enum(s) |
|   Do you currently live in ____(state)____? | XdString | `c910ew7x4qz0pwl2tfk4nymq` | minLen=1; maxLen=200; 2 enum(s) |
|   Do you expect to have a relative you will need to provide care for? | XdString | `p7fis3fw6wtao1thmtnqrj4d` | minLen=1; maxLen=200; 4 enum(s) |
|   Do you live in a private residence? | XdString | `znd4ea2fc0r186ingiibgg70` | minLen=1; maxLen=200; 2 enum(s) |
|   Do you live in college housing? | XdString | `ip96b77kchvis92hp20occgm` | minLen=1; maxLen=200; 1 enum(s) |
|   Do you live in college housing? | XdString | `sxv1kzxpi9r7691tvd6o15ej` | minLen=1; maxLen=200; 1 enum(s) |
|   Do you usually smoke menthol cigarettes? | XdString | `x6h7vt2zluqskubm0pzueopu` | minLen=1; maxLen=200; 4 enum(s) |
|   Do you usually use menthol e-cigarettes? | XdString | `j2sjcx8y2g5pka1r92wfktpo` | minLen=1; maxLen=200; 4 enum(s) |
|   During the past 30 days, on how many days did you use marijuana or hashish? | XdString | `pt230t8mq8x21eanwpef5k9s` | minLen=1; maxLen=200; 4 enum(s) |
|   Ever been told by a doctor or other health professional that you have pre-diabetes or borderline diabetes? | XdString | `t0p1bzyhaa2pjo9rxs6gnkyg` | minLen=1; maxLen=200; 5 enum(s) |
|   Ever Denied Insurance Coverage Because Of Your Cancer? | XdString | `qe2unwumfhk9rdahi6xcfneh` | minLen=1; maxLen=200; 4 enum(s) |
|   Ever Had Feet Sores or Irritations Lasting More Than Four Weeks | XdString | `gxkzkrvcjsv4sq4hqw2vhzgp` | minLen=1; maxLen=200; 4 enum(s) |
|   Ever Had PSA Test | XdString | `bwlkowxdd9jajrfq2uc09wok` | minLen=1; maxLen=200; 4 enum(s) |
|   Ever Receive Instructions From A Doctor For Follow-Up Check-Ups | XdString | `nwh5gke44r1798fc4dnx86gl` | minLen=1; maxLen=200; 4 enum(s) |
|   Given up day-to-day chores due to confusion or memory loss | XdString | `scel65pkdj4d4h9ag1f7gboz` | minLen=1; maxLen=200; 7 enum(s) |
|   Have you discussed your confusion or memory loss with a health care professional? | XdString | `zcjc37cauhmwq97flqdp5vvc` | minLen=1; maxLen=200; 4 enum(s) |
|   Have you ever been given a breathing test? | XdString | `jl6xn744cjf6sq7bnogln3l9` | minLen=1; maxLen=200; 4 enum(s) |
|   Have you ever had an H.P.V. vaccination? | XdString | `rgrjxzk9kcj6cf5hvccnbwlj` | minLen=1; maxLen=200; 5 enum(s) |
|   Have you ever had the shingles or zoster vaccine? | XdString | `n30ruts48e9o2nmr4cis1w50` | minLen=1; maxLen=200; 4 enum(s) |
|   Have you experienced confusion or memory loss that is happening more often or is getting worse? | XdString | `vb48x56iuggm6zestf9yle7h` | minLen=1; maxLen=200; 4 enum(s) |
|   Have you have sexual intercourse? | XdString | `f4rn7jot2zxjydrbyq86946m` | minLen=1; maxLen=200; 4 enum(s) |
|   Have you heard of heated tobacco products? | XdString | `n0dujq8t8qxw7u1nxeox92g5` | minLen=1; maxLen=200; 4 enum(s) |
|   How do other people usually classify you in this country? | XdString | `a6yorxwcncsv94ve7r6azlpm` | minLen=1; maxLen=200; 10 enum(s) |
|   How do you feel you were treated at work compared to people of other races in past 12 months? | XdString | `qj8fbbwjfur4m2zkn4gvhbyy` | minLen=1; maxLen=200; 7 enum(s) |
|   How Long Provided Care For Person. | XdString | `e9y5f1crc1uxg601qf08dho6` | minLen=1; maxLen=200; 7 enum(s) |
|   How many hours a week are you been able to work | XdString | `j9uq2wgte72bgryy97px0gks` | minLen=1; maxLen=200 |
|   How Many Hours Do You Provide Care For Person? | XdString | `tznfb3f1esb43aacgv2wlf2d` | minLen=1; maxLen=200; 6 enum(s) |
|   How many HPV shots did you receive? | XdString | `m9s2tp6v6riohm72pqln9oer` | minLen=1; maxLen=200; 4 enum(s) |
|   How Many Types of Cancer? | XdString | `zbzp2fztjz0rsyau2hhfwtdf` | minLen=1; maxLen=200; 5 enum(s) |
|   How many years have you smoked tobacco products? | XdString | `oa6g7smiparilrawogmd09fe` | minLen=1; maxLen=200; 4 enum(s) |
|   How Often Did Anyone Ever Force You to Have Sex? | XdString | `srjueb10um3seeruvykcdt8m` | minLen=1; maxLen=200; 5 enum(s) |
|   How Often Did Anyone Ever Touch You Sexually? | XdString | `rdp3gofodsale3psriccsfrb` | minLen=1; maxLen=200; 5 enum(s) |
|   How Often Did Anyone Make You Touch Them Sexually? | XdString | `fe5evm9w6pygxnnnslso8reo` | minLen=1; maxLen=200; 5 enum(s) |
|   How Often Did A Parent Physically Hurt You In Any Way? | XdString | `bplukfqvvo2zrqtw90b6vfpn` | minLen=1; maxLen=200; 5 enum(s) |
|   How Often Did A Parent Swear At You? | XdString | `pc5p8o5y3wc7zj2j9v48jxt6` | minLen=1; maxLen=200; 5 enum(s) |
|   How Often Did Your Parents Beat Each Other Up? | XdString | `qmhmykkmhb0ep6ltqpv5vlmy` | minLen=1; maxLen=200; 5 enum(s) |
|   How often do you think about your race? | XdString | `w7vv03jyi6e1f8f8c7ucgbeb` | minLen=1; maxLen=200; 9 enum(s) |
|   Instructions Written or Printed | XdString | `yx40vcmj2fx4ehr9lzi3x0xm` | exactLen=17; 4 enum(s) |
|   Intend to get COVID-19 vaccination | XdString | `ytrd3gws2uxqg9gswxju8ph9` | minLen=1; maxLen=200; 5 enum(s) |
|   Interval Since Last Smoked | XdString | `hwjz5o9a9s3gmriacwe2tfka` | minLen=1; maxLen=200; 10 enum(s) |
|   Is Pain Under Control? | XdString | `wbo8zc6dhe3lf0khhrdon43a` | minLen=1; maxLen=200; 6 enum(s) |
|   Is this a cell phone? | XdString | `o15akywdp66cqi6wkvu49hl4` | minLen=1; maxLen=200; 1 enum(s) |
|   Last Eye Exam Where Pupils Were Dilated | XdString | `bdd1dkjfqkcsvblg1hfz4vtf` | minLen=1; maxLen=200; 7 enum(s) |
|   Last Visited Dentist or Dental Clinic | XdString | `ur5sbcde8xg05zsmwdsg5d9r` | minLen=1; maxLen=200; 7 enum(s) |
|   Live With Anyone Depressed, Mentally Ill, Or Suicidal? | XdString | `jn4esgcmnpr1yg80sw5mpxpd` | minLen=1; maxLen=200; 4 enum(s) |
|   Live With Anyone Who Served TIme in Prison or Jail? | XdString | `ul5yxg5f9wvp5ybyvc1x3dh5` | minLen=1; maxLen=200; 4 enum(s) |
|   Live With Anyone Who Used Illegal Drugs or Abused Prescriptions? | XdString | `sndxjv0x1jsapb321feag6lk` | minLen=1; maxLen=200; 4 enum(s) |
|   Live With a Problem Drinker/Alcoholic? | XdString | `opfg5th7vpmkl3gke89jeyvb` | minLen=1; maxLen=200; 4 enum(s) |
|   Managed household tasks | XdString | `guv9ah9xeebrsdof3b4tdsnz` | minLen=1; maxLen=200; 4 enum(s) |
|   Managed personal care | XdString | `y4s2k1l9fxb1mfertskpzi5o` | minLen=1; maxLen=200; 4 enum(s) |
|   Month/Year of first COVID-19 vaccination | XdString | `j1ctoimoxdn4en40rhdnn1pu` | minLen=1; maxLen=200; 3 enum(s) |
|   Month/Year of second COVID-19 vaccination | XdString | `digbki1kll1kvwcq9snlx7lp` | minLen=1; maxLen=200; 3 enum(s) |
|   Need assistance with day-to_day activities due to confusion or memory loss | XdString | `hmzi44te3yhhmy36qspnijw7` | minLen=1; maxLen=200; 7 enum(s) |
|   Now Taking Insulin | XdString | `ws73k5mhwwz2lvwxbi4bqkvo` | minLen=1; maxLen=200; 4 enum(s) |
|   Number of Adult men in Household | XdString | `axbjsfrqzb3g8kcv8or2i9yp` | minLen=1; maxLen=200; 7 enum(s) |
|   Number of Adults in Household | XdString | `kv658k9gxgjgsuszj4glt9aj` | minLen=1; maxLen=200; 3 enum(s) |
|   Number of Adult women in Household | XdString | `b3zoh4ro94q02nzn53p55fti` | minLen=1; maxLen=200; 7 enum(s) |
|   Number of COVID-19 vaccinations received | XdString | `ima14nb5vxzz9y0mqqulf0sp` | minLen=1; maxLen=200; 6 enum(s) |
|   Number of Permanent Teeth Removed | XdString | `emf890l1cpwi6dhe8b1upy3l` | minLen=1; maxLen=200; 6 enum(s) |
|   Offered advice about what level of drinking is harmful or risky? | XdString | `pp5jixhj98v58f3xv3fsf23l` | minLen=1; maxLen=200; 4 enum(s) |
|   Participate In Clinical Trial As Part Of Cancer Treatment? | XdString | `yer5uf6xfvm4bx2yejd5je79` | minLen=1; maxLen=200; 4 enum(s) |
|   Provided regular care for family or friend | XdString | `jyzu69p6fn9php8e9tgh0w9s` | minLen=1; maxLen=200; 5 enum(s) |
|   Received at least one COVID-19 vaccination | XdString | `fhql7nu3qfc6y7mf024bopch` | minLen=1; maxLen=200; 4 enum(s) |
|   Relationship Of Person To Whom You Are Giving Care? | XdString | `v9vow51yc8ebob1zdpvxtuq3` | minLen=1; maxLen=200; 17 enum(s) |
|   Safe time to talk | XdString | `az4gx3c5f9krg29pl4v863d0` | minLen=1; maxLen=200; 1 enum(s) |
|   Sexual orientation | XdString | `zuczzj1kbti4qgxvb5nj4d2g` | minLen=1; maxLen=200; 6 enum(s) |
|   Sexual orientation | XdString | `jfn1hjz1i4qn0zv0xlratfe5` | minLen=1; maxLen=200; 6 enum(s) |
|   Still have Chronic Fatigue Syndrome or Myalgic Encephalomyelitis | XdString | `r1ql14mwgsv54af9yeyjvnoi` | minLen=1; maxLen=200 |
|   Stopped Smoking in past 12 months | XdString | `l4kom6v9wp21vwn97ggnav05` | minLen=1; maxLen=200; 4 enum(s) |
|   Times Checked for Glycosylated Hemoglobin | XdString | `pybkrb2dcydbgd6upci04nww` | minLen=1; maxLen=200; 5 enum(s) |
|   Time Since Most Recent PSA Test | XdString | `q4vgat12m9c3st7id9gzw4rs` | minLen=1; maxLen=200; 7 enum(s) |
|   Times past 30 days felt physical symptoms because of treatment due to your race | XdString | `abtyp285cenjl0oxlqul4edq` | minLen=1; maxLen=200; 4 enum(s) |
|   Told had Chronic Fatigue Syndrome (CFS) or (Myalgic Encephalomyelitis) ME | XdString | `y67xzfs5uajp40sxewj1j6vy` | minLen=1; maxLen=200 |
|   Type of Cancer | XdString | `tn99rw3x0ydsn6zccclu7lkt` | minLen=1; maxLen=200; 32 enum(s) |
|   USEMRJN4 | XdString | `ttwwqbbs91acobpbgnnk74ag` | minLen=1; maxLen=200 |
|   Were you advised to reduce or quit your drinking? | XdString | `vvbm494l82dfglaty5iui8ql` | minLen=1; maxLen=200; 4 enum(s) |
|   Were Your Parents Divorced/Seperated? | XdString | `lnsxo4qnue3cjh7qaebdkjhj` | minLen=1; maxLen=200; 5 enum(s) |
|   Were you treated worse than, the same, or better than people of other races? | XdString | `w9o9oe5ys899mcd2qfryvjt6` | minLen=1; maxLen=200; 7 enum(s) |
|   What did you do to keep you from getting pregnant? | XdString | `eiodgyyaciy2t7872rme8imh` | minLen=1; maxLen=200; 14 enum(s) |
|   What Is The Major Health Problem, Illness, Disability For Care For Person? | XdString | `pdnq9flqa6ec8xqs7anjkodu` | minLen=1; maxLen=200; 17 enum(s) |
|   What is your preferred birth control method? | XdString | `x0lq9sdg4i2h8t9g4jg1t7ns` | minLen=1; maxLen=200; 16 enum(s) |
|   What type of diabetes do you have? | XdString | `c9jo7m8n33x6nvnqln6uxn05` | minLen=1; maxLen=200; 4 enum(s) |
|   What Type of Doctor Provides Majority of Your Care | XdString | `fu01lav25ebr53lhb7ktq3a2` | minLen=1; maxLen=200; 12 enum(s) |
|   What was main reason for not doing anything to keep you from getting pregnant? | XdString | `az4ih6g3hcgxqb9qcoey72pj` | minLen=1; maxLen=200; 16 enum(s) |
|   What was the MAIN reason you had this PSA test? | XdString | `qwblthdy5nckobsv0pqq9t1m` | minLen=1; maxLen=200; 5 enum(s) |
|   When seeking health care past 12 months, was experience worse, same, better than people of other races? | XdString | `g2c98l0jvlbq1tubvtwd4ufc` | minLen=1; maxLen=200; 7 enum(s) |
|   When was the last time a they took a photo of the back of your eye? | XdString | `gse7o1fr7kj14vqdlxhoz49y` | minLen=1; maxLen=200; 7 enum(s) |
|   When was the last time you took a course or class in how to manage your diabetes? | XdString | `f2kgj7uxc832ze20sahbhpdx` | minLen=1; maxLen=200; 9 enum(s) |
|   When was your last blood test for high blood sugar? | XdString | `e8ngz5cnjku5nugg1ky9ej2r` | minLen=1; maxLen=200; 9 enum(s) |
|   When you need help with day-to-day activities are you able to get it | XdString | `lnkgxfhrsj6gm6s1itwcxigg` | minLen=1; maxLen=200; 7 enum(s) |
|   Where did you get what you used to prevent pregnancy? | XdString | `wz4ffpqxstpcl0745olt433c` | minLen=1; maxLen=200; 12 enum(s) |
|   Where did you get your last flu shot/vaccine? | XdString | `cgckfkmsk058lmr9355ca1iy` | minLen=1; maxLen=200; 13 enum(s) |
|   Who first suggested this PSA test? | XdString | `b81aqbwckpthawtqkqhmm0gb` | minLen=1; maxLen=200; 5 enum(s) |
|   Will you get COVID-19 vaccination? | XdString | `abkeji0l78vz5qssv4oiar5m` | minLen=1; maxLen=200; 6 enum(s) |
|   Years smoked reported packs per day | XdString | `h7goqorv94mfrn9rge32sru7` | minLen=1; maxLen=200; 1 enum(s) |
|   Accident State | XdToken | `jc58nr637jfd2ho5iycua4lw` | 56 enum(s) |
|   Marital status | XdToken | `qmqis7vj5dmx3m9adbbvlb7r` | 1 enum(s) |
|   Pregnancy status | XdToken | `cdwi4klrxwpomenewf5sz2hu` | 1 enum(s) |
|   Annual Sequence Number | XdCount | `lgpbp4ds3lw9tma1k9qtqw20` | units=SEQNO_units |
|   Interview Date | XdCount | `pkhqwjitqte8vcigj72z2z9c` | units=IDATE_units |
|   Interview Day | XdCount | `a3dpca5ge7orm8xdxl47c9h4` | units=IDAY_units |
|   Interview Month | XdCount | `ptay2izlzt44di3ocmwi75or` | units=IMONTH_units |
|   Interview Year | XdCount | `i7bblawg1w9vqolnvuxnxa9l` | units=IYEAR_units |
|   Age | XdCount | `cb4ti4afgfe9wd641tflfrdj` | units=Time Units |
|   Adult flu shot/spray past 12 mos | XdQuantity | `i5igyikh9loow8r5uf2lki7n` | units=FLUSHOT7_units |
|   Adults aged 18+ that have had permanent teeth extracted | XdQuantity | `ybwkdwgurojv7s85o5x8680m` | units=_EXTETH3_units |
|   Adults aged 65+ who have had all their natural teeth extracted | XdQuantity | `r5tmcu7326a36ebmf0bpw3pb` | units=_ALTETH3_units |
|   Adults that have visited a dentist, dental hygenist or dental clinic within the past year | XdQuantity | `ivd0vwqfxx8td6cf5k1ow8k1` | units=_DENVST3_units |
|   Adults with good or better health | XdQuantity | `yum8kxp4q88kj4ft21xu6snz` | units=_RFHLTH_units |
|   Are you 18 years of age or older? | XdQuantity | `fw0qeps245x0v22e1j43u5e6` | units=LADULT1_units |
|   Are You A Veteran | XdQuantity | `ikjn7ur4yd4sdsta8k1ho35r` | units=VETERAN3_units |
|   Are you deaf or do you have serious difficulty hearing? | XdQuantity | `gdhurbjjp0jee643noke2blz` | units=DEAF_units |
|   Are you male or female? | XdQuantity | `f7fhkza4hsrr2agz9qf2r4ew` | units=LANDSEX1_units |
|   Avg alcoholic drinks per day in past 30 | XdQuantity | `htpd3pmhah8pqd29mukk5wdw` | units=AVEDRNK3_units |
|   Binge Drinking | XdQuantity | `hkkovfz4t2o7nxb4lzbpp9cz` | units=DRNK3GE5_units |
|   Binge Drinking Calculated Variable | XdQuantity | `n0c8v5twxeolomr7ynesu7wd` | units=_RFBING6_units |
|   Blind or Difficulty seeing | XdQuantity | `j76k8rbzkuiemid1di6lc7v0` | units=BLIND_units |
|   Calculated non-Hispanic Race including multiracial | XdQuantity | `k5ap1ymzlqajv9luquuksmn2` | units=_MRACE2_units |
|   Calculated sex variable | XdQuantity | `f3apc1ipvz2m1bx5hbwsc00j` | units=_SEX_units |
|   Cellular Telephone | XdQuantity | `obqg86yl6rix83kzqtqe3fpi` | units=CELPHON1_units |
|   Child Hispanic, Latino/a, or Spanish origin calculated variable | XdQuantity | `cw819akghzvnld6w81yn0dsf` | units=_CHISPNC_units |
|   Child Non-Hispanic Race including Multiracial | XdQuantity | `a70gzqyklhcpyg1h61mn9smy` | units=_CRACE2_units |
|   Computed Asthma Status | XdQuantity | `glhn7hgjes66t7qbdga7t6a7` | units=_ASTHMS1_units |
|   Computed body mass index categories | XdQuantity | `n5cm7c5foof63rjewuerdtpt` | units=_BMI5CAT_units |
|   Computed Five level race/ethnicity category. | XdQuantity | `r3uiku6laqeepuldfd4w3opa` | units=_RACEGR4_units |
|   Computed Height in Inches | XdQuantity | `wqam75p0vr0jfsqz4cbyahnt` | units=HTIN4_units |
|   Computed Height in Meters | XdQuantity | `mk04y2wxaul9wje1d2e699wh` | units=HTM4_units |
|   Computed income categories | XdQuantity | `js62r6sl022ytnzojn2ae10y` | units=_INCOMG1_units |
|   Computed level of education completed categories | XdQuantity | `uub49893wlobm525jxomo8fj` | units=_EDUCAG_units |
|   Computed Mental Health Status | XdQuantity | `i7gssagyinc8rzchlsf3fhrn` | units=_MENT14D_units |
|   Computed number of children in household | XdQuantity | `e0b0txcj6s7nrp4xuf4lqyp2` | units=_CHLDCNT_units |
|   Computed Physical Health Status | XdQuantity | `k1b82tjseebk8090m29szivo` | units=_PHYS14D_units |
|   Computed Preferred Race | XdQuantity | `vsi09maxyy9bqqodnmw53w8f` | units=_PRACE2_units |
|   Computed Race-Ethnicity grouping | XdQuantity | `rhlcako8y0479099gcm7etme` | units=_RACE1_units |
|   Computed race groups used for internet prevalence tables | XdQuantity | `xh4k4m2cvaoojgxvqh84jrxa` | units=_RACEPR1_units |
|   Computed Smoking Status | XdQuantity | `sow0ho082kz0fwq5u91bi11f` | units=_SMOKER3_units |
|   Computed Weight in Kilograms | XdQuantity | `j96ehmxm5bgqusguq4bdj634` | units=WTKG3_units |
|   Correct telephone number? | XdQuantity | `taaqpfgl79w8kmd5icwv0smb` | units=CTELENM1_units |
|   Could Not Afford To See Doctor | XdQuantity | `p75o028b2if5v65bnac3zaqa` | units=MEDCOST1_units |
|   CPDEMO1C | XdQuantity | `g46mlb32co4iy0mzebt598b2` | units=CPDEMO1C_units |
|   Current Asthma Calculated Variable | XdQuantity | `gkyu6urzy3bphtzvc2qalrnt` | units=_CASTHM1_units |
|   Current E-cigarette User Calculated Variable | XdQuantity | `e61drqhiwnbydt4ydyhm0qxa` | units=_CURECI2_units |
|   Current Smoking Calculated Variable | XdQuantity | `dji9zzn7gmnqsdq3fkqgktde` | units=_RFSMOK3_units |
|   Days in past 30 had alcoholic beverage | XdQuantity | `y88h8l7cf8pqakgfkaon6ll6` | units=ALCDAY4_units |
|   Design weight use in raking | XdQuantity | `v5ew61lj6n31ze8qr63ysp2f` | units=_WT2RAKE_units |
|   DIABAGE4 | XdQuantity | `h5w5nwm7pq1uzpz7uzo9szat` | units=DIABAGE4_units |
|   Did you have a CT or CAT scan? | XdQuantity | `bgzw1ozsw7ko8dleo2kj84et` | units=LCSCTSC1_units |
|   Difficulty Concentrating or Remembering | XdQuantity | `xtnl3nxf1tgn2oti4c8z6uim` | units=DECIDE_units |
|   Difficulty Doing Errands Alone | XdQuantity | `p6c2yu5i7r83gyz457oa715i` | units=DIFFALON_units |
|   Difficulty Dressing or Bathing | XdQuantity | `atjmbnb7enj3ezrw35bq19la` | units=DIFFDRES_units |
|   Difficulty Walking or Climbing Stairs | XdQuantity | `gckmyw76rajyu07wfb0egm00` | units=DIFFWALK_units |
|   Do Any High Risk Situations Apply | XdQuantity | `g37cjo5qydixzk1l4rlt5nrl` | units=HIVRISK5_units |
|   Do you now use e-cigarettes, or vaping products every day, some days, or not at all? | XdQuantity | `pznq8hl57e58m5prvqzt3a4e` | units=ECIGNOW2_units |
|   Drink any alcoholic beverages in past 30 days | XdQuantity | `a5nf6bbaoacrxtjs8ojygred` | units=DRNKANY6_units |
|   Dual Phone Use Categories | XdQuantity | `v3429yglabpkx6l11pta0ow3` | units=_DUALUSE_units |
|   Dual Phone Use Correction Factor | XdQuantity | `djohuxibiz3ad3bx2raeva9j` | units=_DUALCOR_units |
|   During the past 12 months have you received food stamps | XdQuantity | `qj6h9lhm4ja3at6c8jjkihxu` | units=FOODSTMP_units |
|   Education Level | XdQuantity | `qhvdor5a6czxn7qlghmdxnfg` | units=EDUCA_units |
|   Ever been tested for HIV calculated variable | XdQuantity | `yrhg051q6nfnrs3twfyqu30h` | units=_AIDTST4_units |
|   Ever Diagnosed with Angina or Coronary Heart Disease | XdQuantity | `bb2of5otgbfqpxlm398kcmfi` | units=CVDCRHD4_units |
|   Ever Diagnosed with a Stroke | XdQuantity | `w7ftbfaufocbfwlk73i5tag1` | units=CVDSTRK3_units |
|   Ever Diagnosed with Heart Attack | XdQuantity | `phej7keynj8cqytljcaz2csk` | units=CVDINFR4_units |
|   Ever had a colonoscopy, sigmoidoscopy, or both | XdQuantity | `io0wxk0uhlqbm7k9vvjgqwu5` | units=COLNSIGM_units |
|   Ever had any other kind of test for colorectal cancer | XdQuantity | `on1zikxcq357wlzqu7jz2w8k` | units=COLNCNCR_units |
|   Ever had a virtual colonoscopy | XdQuantity | `fd8s7ljndmrrnefl5ec984df` | units=VIRCOLO1_units |
|   Ever had CHD or MI | XdQuantity | `gdtjhraa20wmp8in044slrha` | units=_MICHD_units |
|   Ever Had Sigmoidoscopy/Colonoscopy | XdQuantity | `uj9pw0hp2e7b211e4m7d5v9j` | units=HADSIGM4_units |
|   Ever had stool DNA test? | XdQuantity | `j4odq2u3jmfnrv8l8ptg9q12` | units=STOOLDN2_units |
|   Ever had stool test? | XdQuantity | `hdff20h32rfdo4s0zhjqz3uu` | units=SMALSTOL_units |
|   Ever tested H.I.V. | XdQuantity | `rk682jah866qqd7qvf9497ik` | units=HIVTST7_units |
|   Ever Told Had Asthma | XdQuantity | `ifk006im6086n6wi7i6s7iiv` | units=ASTHMA3_units |
|   (Ever told) you had a depressive disorder | XdQuantity | `feldjyvk490va939oagmvzzn` | units=ADDEPEV3_units |
|   Ever told you had C.O.P.D. emphysema or chronic bronchitis? | XdQuantity | `s30mti073f3ucx56ncwd85x1` | units=CHCCOPD3_units |
|   (Ever told) you had diabetes | XdQuantity | `jiknuhzx99z17zd7dxfg8bte` | units=DIABETE4_units |
|   (Ever told) (you had) melanoma or any other types of cancer? | XdQuantity | `ghisv54gz9oaoebv942gtpu2` | units=CHCOCNC1_units |
|   (Ever told) (you had) skin cancer that is not melanoma? | XdQuantity | `hs8jfn9pwbza3hxi2stwi4sq` | units=CHCSCNC1_units |
|   Ever told you have kidney disease? | XdQuantity | `l351s47nr7rw9037dcs1lij8` | units=CHCKDNY2_units |
|   Exercise in Past 30 Days | XdQuantity | `y5g474udodkx9e0zg2nj85q8` | units=EXERANY2_units |
|   File Month | XdQuantity | `xeyd57z8vdsz3zl223q0drft` | units=FMONTH_units |
|   Final child weight: Land-line and Cell-Phone data | XdQuantity | `oizhhs620vvdzwodp6k5ehll` | units=_CLLCPWT_units |
|   Final Disposition | XdQuantity | `xio8bzoppq4ie1ncftamv3ed` | units=DISPCODE_units |
|   Final weight: Land-line and cell-phone data | XdQuantity | `jpn4h8qzwyd57odeudt8lj83` | units=_LLCPWT_units |
|   Flu Shot Calculated Variable | XdQuantity | `gfrjga0idq84o1avaz8fi1ze` | units=_FLSHOT7_units |
|   Four level child age | XdQuantity | `plpqk85z1v2i3ecnrs33cuup` | units=CAGEG_units |
|   Frequency of Days Now Smoking | XdQuantity | `alr4urwn3rcnipzbk80lrpuc` | units=SMOKDAY2_units |
|   Gender of child | XdQuantity | `fifo62l7o3pt7bosit7a0bgw` | units=RCSGEND1_units |
|   General Health | XdQuantity | `serl81fog17gmp4uqzkwv52m` | units=GENHLTH_units |
|   Had colonoscopy calculated variable | XdQuantity | `z3v03y4mwvcq96ubpk9pozgj` | units=_HADCOLN_units |
|   Had Hysterectomy | XdQuantity | `ia9p35rf8bbn1yl6giazg4oj` | units=HADHYST2_units |
|   Had sigmoidoscopy calculated variable | XdQuantity | `pz3jc34p13pfyrym55ig6bpl` | units=_HADSIGM_units |
|   Has a lack of reliable transportation kept you from appointments, meetings, work, or getting things needed | XdQuantity | `gdynzlffx64b6bmb5kf6f053` | units=SDHTRNSP_units |
|   Have an 3 month or longer covid symptoms? | XdQuantity | `um1szqwjbzjpnlthkv0izxyy` | units=COVIDSMP_units |
|   Have an H.P.V. test and recent cervical cancer screening | XdQuantity | `mpfkqf6h5ravk7ghzxa2s4ct` | units=CRVCLHPV_units |
|   Have any health insurance | XdQuantity | `al1vnmswlu32qkthyel8kyd2` | units=_HLTHPLN_units |
|   Have a PAP test and recent cervical cancer screening | XdQuantity | `fsouplgx1gk2f9oj2wtu90a4` | units=CRVCLPAP_units |
|   Have Personal Health Care Provider? | XdQuantity | `i5k79nga3bgvufo4abn7g6x8` | units=PERSDOC3_units |
|   Have you ever been told you tested positive for COVID 19? | XdQuantity | `qoihqusqjneud4esegb3ch6l` | units=COVIDPOS_units |
|   Have you ever had a cervical cancer screening test? | XdQuantity | `lsctb3hyge22aqs9za3utury` | units=CERVSCRN_units |
|   Have You Ever Had a Mammogram | XdQuantity | `uz7r34yzz4sn191mzjs3qk1x` | units=HADMAM_units |
|   Have you lost employment or had hours reduced? | XdQuantity | `gdmbmll3093yzzrea4uhrumz` | units=SDHEMPLY_units |
|   Heavy Alcohol Consumption Calculated Variable | XdQuantity | `n8rkon326b6y06ob6x9b93o3` | units=_RFDRHV8_units |
|   Hispanic, Latino/a, or Spanish origin calculated variable | XdQuantity | `i98893ur39wcpn5vexeg16ar` | units=_HISPANC_units |
|   Hlth pro ever said child has asthma | XdQuantity | `h5d8pkwjz3mqfz4a7kdlvx9d` | units=CASTHDX2_units |
|   Household Landline Telephones | XdQuantity | `xxzg4tlh9qszedvu9a6foenw` | units=NUMHHOL4_units |
|   How Long since Last Mammogram | XdQuantity | `ocbj606gsh7twip9dlc0ip7q` | units=HOWLONG_units |
|   How long since you had colonoscopy | XdQuantity | `j6h17hgy3mmaloq6gqkwg55m` | units=COLNTES1_units |
|   How long since you had sigmoidoscopy | XdQuantity | `dl82xqhk094xppoqmyf4zazk` | units=SIGMTES1_units |
|   How long since you had stool DNA | XdQuantity | `d8g14d48fmwyuwmo6ol4n2ff` | units=SDNATES1_units |
|   How long since you had stool test? | XdQuantity | `wjkh4ufiou9lj9a5tyy4syxr` | units=STOLTEST_units |
|   How long since you had virtual colonoscopy | XdQuantity | `c2tuvvxiwv53ls1ecwda9pgx` | units=VCLNTES2_units |
|   How Much Time Do You Sleep | XdQuantity | `gr00kh5zypw1act27nftz6b5` | units=SLEPTIM1_units |
|   How often did the food that you bought not last, and you didn’t have money to get more? | XdQuantity | `xj10pq8yqj15jobn2rls5sfk` | units=SDHFOOD1_units |
|   How often do you feel socially isolated from others? | XdQuantity | `v89n2d14hmqbgqtqu0vsnuvs` | units=SDHISOLT_units |
|   How often get emotional support needed | XdQuantity | `tm6qbqbub7ktmyexk20ahkmt` | units=EMTSUPRT_units |
|   How often have you felt this kind of stress? | XdQuantity | `h7u79noyxpl9b95xpjbw87rt` | units=SDHSTRE1_units |
|   How old when you first started smoking? | XdQuantity | `j7k4xrxmqzldwrktkmh4ta6o` | units=LCSFIRST_units |
|   How old when you last smoked? | XdQuantity | `btd6ocozlnfl7l7lrest4imw` | units=LCSLAST_units |
|   Imputed race/ethnicity value | XdQuantity | `uwsuwdkqzx3qgrb0e7l9l9gq` | units=_IMPRACE_units |
|   Language identifier | XdQuantity | `b82ew5gxqgkopq36bgcii7i3` | units=QSTLANG_units |
|   Leisure Time Physical Activity Calculated Variable | XdQuantity | `g08fesmv5932t9ttnlnkdjc2` | units=_TOTINDA_units |
|   Length of time since last routine checkup | XdQuantity | `ov28sjh0pxd674if30q7ejy1` | units=CHECKUP1_units |
|   Lifetime Asthma Calculated Variable | XdQuantity | `vk4tsi4kiidtkhv69u6icsxx` | units=_LTASTH1_units |
|   Lung cancer screening recommendation status | XdQuantity | `xd76ggz9qpdxwr7ccfp9sky9` | units=_LCSREC_units |
|   Metropolitan Status | XdQuantity | `c19ybupdwtx82bwthb3wgvh8` | units=_METSTAT_units |
|   Metropolitan Status Code | XdQuantity | `rj05dj4174czin8ffhpj6czm` | units=MSCODE_units |
|   Month and Year of Last HIV Test | XdQuantity | `cth1j00jwyrngveovrybsf8t` | units=HIVTSTD3_units |
|   Most drinks on single occasion past 30 days | XdQuantity | `fw86gigqgr4iapyg5pzj8q0w` | units=MAXDRNKS_units |
|   Number of Adults in Household | XdQuantity | `b0z9vv9kibdiy5dv2t0s1n6x` | units=NUMADULT_units |
|   Number of Children in Household | XdQuantity | `geghojpnfz8fpgu0hqdxg39a` | units=CHILDREN_units |
|   Number of Days Mental Health Not Good | XdQuantity | `rk7l5zpqt18pdw3eusv0u7nb` | units=MENTHLTH_units |
|   Number of Days Physical Health Not Good | XdQuantity | `tab7sz3efawip1rxpoc3cbyg` | units=PHYSHLTH_units |
|   Number of packs of cigarettes smoked per day | XdQuantity | `dvbxvzqf7yn0f7ptfp8arv1e` | units=_PACKDAY_units |
|   Number of years since quit smoking cigarettes | XdQuantity | `g8fzdlcyy0kvareyxwggmder` | units=_YRSQUIT_units |
|   Number of years smoked cigarettes | XdQuantity | `yvwjq2pn15fkdcjk4crfyg9n` | units=_YRSSMOK_units |
|   NUMPHON4 | XdQuantity | `jdbbi0ur0baxthg1wv1h8r9h` | units=NUMPHON4_units |
|   On average, how many cigarettes do you smoke each day? | XdQuantity | `o9tv75s6ipl92pgqggkkmm6i` | units=LCSNUMCG_units |
|   Overweight or obese calculated variable | XdQuantity | `kdqiqq2lo2phonxs7g9v1jc7` | units=_RFBMI5_units |
|   Own or Rent Home | XdQuantity | `vtlpqqyck51hm8dofn4ozebu` | units=RENTHOM1_units |
|   Pneumonia shot ever | XdQuantity | `zc8jxydcyygfwfp157gcomyr` | units=PNEUVAC4_units |
|   Pneumonia Vaccination Calculated Variable | XdQuantity | `u4s8orhlyo4kdbxvycphrni4` | units=_PNEUMO3_units |
|   Poor Physical or Mental Health | XdQuantity | `g8fg7olxlnoxqu35uup7tgz5` | units=POORHLTH_units |
|   Preferred Child Race Categories | XdQuantity | `p4199myntpqsbe2km8bltifm` | units=_CPRACE2_units |
|   Primary Sampling Unit | XdQuantity | `gtkt68khi07hxu9yu84n3y5x` | units=_PSU_units |
|   Private Residence? | XdQuantity | `r3z244d1848mzcp4dgdvixya` | units=PVTRESD1_units |
|   Questionnaire Version Identifier | XdQuantity | `l46m9c5jnvc6c7ybq4y1llur` | units=QSTVER_units |
|   _RACEG22 | XdQuantity | `ps2aikhmpjyexahgjpsbg8u5` | units=_RACEG22_units |
|   Raw weighting factor used in raking | XdQuantity | `sftykmoinqwwt7h7ephae16b` | units=_RAWRAKE_units |
|   Received Tetanus Shot Since 2005? | XdQuantity | `kul4r6vvyezdcl2qude5rf81` | units=TETANUS1_units |
|   Relationship to child | XdQuantity | `ff75rq9ofn5cwaobgmo8a87x` | units=RCSRLTN2_units |
|   Reported age in five-year age categories calculated variable | XdQuantity | `kiz9jxkrvz0m0bkcmi1qukd9` | units=_AGEG5YR_units |
|   Reported age in two age groups calculated variable | XdQuantity | `e8c5osoaws34c5r3t3gakuda` | units=_AGE65YR_units |
|   Resident of State | XdQuantity | `tfodnjhefshn6eyktvsby72p` | units=STATERE1_units |
|   Respondents aged 18-64 with health insurance | XdQuantity | `pty3rjlewg4knst4ypku1h5u` | units=_HCVU652_units |
|   Respondents aged 45-75 who have fully met the USPSTF recommendations | XdQuantity | `evw8skku4jwuat34o4svx2ou` | units=_CRCREC2_units |
|   Respondents aged 45-75 who have had a colonoscopy within the past ten years | XdQuantity | `b1g6i3z6udq8ykptzdb07fbx` | units=_CLNSCP1_units |
|   Respondents aged 45-75 who have had a sigmoidoscopy within the past five years | XdQuantity | `zxp8egi7ueot42wxmp5jjmgp` | units=_SGMSCP1_units |
|   Respondents aged 45-75 who have had a sigmoidoscopy within the past ten years | XdQuantity | `scdi1amd3bm05wh2z3d2jw35` | units=_SGMS101_units |
|   Respondents aged 45-75 who have had a stool DNA test within the past three years | XdQuantity | `hv21s7uvhscg9b3dswxcdy8x` | units=_STOLDN1_units |
|   Respondents aged 45-75 who have had a stool test within the past year | XdQuantity | `n3axm1c3105qrdfvdw24kewf` | units=_RFBLDS5_units |
|   Respondents aged 45-75 who have had a virtual colonoscopy within the past five years | XdQuantity | `ycdwg4m4kxkw53jci21dq2qz` | units=_VIRCOL1_units |
|   Respondents diagnosed with arthritis | XdQuantity | `m8ybhe4mpa7t2sbeemyjwd7b` | units=_DRDXAR2_units |
|   Respondent selection | XdQuantity | `mx4i08uxaqywkrcsl2jjyo27` | units=RESPSLCT_units |
|   Sample Design Stratification Variable | XdQuantity | `uwvzyp9t2pmr1qfdya77bgop` | units=_STSTR_units |
|   Satisfaction with life | XdQuantity | `h8kfx67pxsxeih53lgcs4f7x` | units=LSATISFY_units |
|   _SBONTI1 | XdQuantity | `nw6d0xc4mm6q6y73sls6bns8` | units=_SBONTI1_units |
|   Sex of Respondent | XdQuantity | `vdgjhn7ciuuywzvp2jfkyrgr` | units=SEXVAR_units |
|   Smoked at Least 100 Cigarettes | XdQuantity | `u002kli6alzd8v0t36l4c7ia` | units=SMOKE100_units |
|   Smoking Group | XdQuantity | `iuiai6aix5ex5dxhf66wmdnn` | units=_SMOKGRP_units |
|   Still Have Asthma | XdQuantity | `cbyv0b85l3a6oun9hrfvfc77` | units=ASTHNOW_units |
|   Stratum weight | XdQuantity | `sysmf6lhzcsxa250r8k6mfye` | units=_STRWT_units |
|   Time since last cervical cancer screening test | XdQuantity | `ejrk3v5dkeq3idqmot530b9i` | units=CRVCLCNC_units |
|   Time Since Last Sigmoidoscopy/Colonoscopy | XdQuantity | `tp0yliyg0iapsl1lfpmf4x44` | units=LASTSIG4_units |
|   Told Had Arthritis | XdQuantity | `t7etyaw9aoo5js2iigo7ci4k` | units=HAVARTH4_units |
|   Truncated design weight used in adult combined land line and cell phone raking | XdQuantity | `nwu0goway06eko1330nmzld3` | units=_LLCPWT2_units |
|   Urban/Rural Status | XdQuantity | `ovx6gyqvueucw9b411cf7rxk` | units=_URBSTAT_units |
|   Use of Smokeless Tobacco Products | XdQuantity | `byx6ancbrdf1defuxrnuiea4` | units=USENOW3_units |
|   Was test part of Cologuard test? | XdQuantity | `wowgwgepvbc72qjtwiwwqc1d` | units=BLDSTFIT_units |
|   Were any CT or CAT scans done to check for lung cancer? | XdQuantity | `vi7847or65i9og3dm8te7or5` | units=LCSSCNCR_units |
|   Were you not able to pay utility bills or threatened to lose service? | XdQuantity | `gl85yi2b3q7vjgiiw8zwtah2` | units=SDHUTILS_units |
|   Were you not able to pay your bills? | XdQuantity | `md50o8pxrqv20zcc93ceggt6` | units=SDHBILLS_units |
|   What is Primary Source of Health Insurance? | XdQuantity | `kkbi2oiji4pzsscw7knjufz0` | units=PRIMINSR_units |
|   When did you have your most recent CT or CAT scan? | XdQuantity | `xefrxnk88eu0eyx1k6k1oblf` | units=LCSCTWHN_units |
|   When did you receive your most recent seasonal flu shot/spray? | XdQuantity | `vbgy4f7ipcq79hnjr3yn44fo` | units=FLSHTMY3_units |
|   Which was the primary symptom that you experienced? | XdQuantity | `ee0gptb3fsjqjxjwm0no71mi` | units=COVIDPRM_units |
|   Women respondents aged 40+ who have had a mammogram in the past two years | XdQuantity | `jpd0xpalt83bo5wpz6ff689p` | units=_RFMAM22_units |
|   Women respondents aged 50-74 that have had a mammogram in the past two years | XdQuantity | `s65vqufhvjbi9co74x9gupsm` | units=_MAM5023_units |
|   Taxable Income | XdQuantity | `q1sbdhsdk8glmdr8q1x3mlte` | min=0.00000; units=Cordova Córdoba (COR) |
|   BMI | XdQuantity | `wpojnsuwae37rfsnj9xpbcun` | units=kg/m² (BMI) |
|   Body Weight | XdQuantity | `csn8ymg324e0upnzku4aqrcq` | units=Mass/Weight (SI - Metric) |
|   Height | XdQuantity | `xh1ptg8cn9dqt71jnm74v48l` | units=Length/Distance (SI - Metric) |

## Structural Hierarchy

```
DM: BRFSS — Brfss
  [Cluster] brfss
    [XdString] Age Told Had Cancer
    [XdString] Any Firearms in Home
    [XdString] Any Firearms Loaded
    [XdString] Any Loaded Firearms Also Unlocked
    [XdString] Are you 18 years of age or older?
    [XdString] Are You Doing Anything to Keep From Getting Pregnant?
    [XdString] Are you male or female?
    [XdString] Are you male or female?
    [XdString] Are you male or female?
    [XdString] Asked during checkup if you drink alchohol
    [XdString] Asked in person or by form how much you drink?
    [XdString] Asked whether you drank [5 FOR MEN /4 FOR WOMEN] or more alcoholic drinks on an occasion?
    [XdString] Child´s sex at birth
    [XdString] Child still have asthma?
    [XdString] Computed drink-occasions-per-day
    [XdString] Computed number of drinks of alcohol beverages per week
    [XdString] Correct Phone Number?
    [XdString] Currently Have Physical Pain From Cancer Or Treatment?
    [XdString] Currently Receiving Treatment for Cancer
    [XdString] Did an adult make sure basic needs were met
    [XdString] Did an adult make you feel safe and protected
    [XdString] Did Health Insurance Pay For All Of Your Cancer Treatment
    [XdString] Did you cough up phlegm?
    [XdString] Did you dab marijuana or cannabis?
    [XdString] Did you do anything to keep from getting pregnant?
    [XdString] Did you eat marijuana or cannabis?
    [XdString] Did you have a cough?
    [XdString] Did you have shortness of breath?
    [XdString] Did You Receive a Summary of Cancer Treatments Received
    [XdString] Did you smoke marijuana or cannabis?
    [XdString] Did you talk about the advantages or disadvantages of P.S.A. test
    [XdString] Did you use marijuana or cannabis some other way?
    [XdString] Did you vape marijuana or cannabis?
    [XdString] Does confusion or memory loss interfere with work or social activities
    [XdString] Does Person Being Cared For Have Alzheimer´s Disease?
    [XdString] Do you also have a landline telephone?
    [XdString] Do you consider yourself to be transgender?
    [XdString] Do you currently live in ____(state)____?
    [XdString] Do you expect to have a relative you will need to provide care for?
    [XdString] Do you live in a private residence?
    [XdString] Do you live in college housing?
    [XdString] Do you live in college housing?
    [XdString] Do you usually smoke menthol cigarettes?
    [XdString] Do you usually use menthol e-cigarettes?
    [XdString] During the past 30 days, on how many days did you use marijuana or hashish?
    [XdString] Ever been told by a doctor or other health professional that you have pre-diabetes or borderline diabetes?
    [XdString] Ever Denied Insurance Coverage Because Of Your Cancer?
    [XdString] Ever Had Feet Sores or Irritations Lasting More Than Four Weeks
    [XdString] Ever Had PSA Test
    [XdString] Ever Receive Instructions From A Doctor For Follow-Up Check-Ups
    [XdString] Given up day-to-day chores due to confusion or memory loss
    [XdString] Have you discussed your confusion or memory loss with a health care professional?
    [XdString] Have you ever been given a breathing test?
    [XdString] Have you ever had an H.P.V. vaccination?
    [XdString] Have you ever had the shingles or zoster vaccine?
    [XdString] Have you experienced confusion or memory loss that is happening more often or is getting worse?
    [XdString] Have you have sexual intercourse?
    [XdString] Have you heard of heated tobacco products?
    [XdString] How do other people usually classify you in this country?
    [XdString] How do you feel you were treated at work compared to people of other races in past 12 months?
    [XdString] How Long Provided Care For Person.
    [XdString] How many hours a week are you been able to work
    [XdString] How Many Hours Do You Provide Care For Person?
    [XdString] How many HPV shots did you receive?
    [XdString] How Many Types of Cancer?
    [XdString] How many years have you smoked tobacco products?
    [XdString] How Often Did Anyone Ever Force You to Have Sex?
    [XdString] How Often Did Anyone Ever Touch You Sexually?
    [XdString] How Often Did Anyone Make You Touch Them Sexually?
    [XdString] How Often Did A Parent Physically Hurt You In Any Way?
    [XdString] How Often Did A Parent Swear At You?
    [XdString] How Often Did Your Parents Beat Each Other Up?
    [XdString] How often do you think about your race?
    [XdString] Instructions Written or Printed
    [XdString] Intend to get COVID-19 vaccination
    [XdString] Interval Since Last Smoked
    [XdString] Is Pain Under Control?
    [XdString] Is this a cell phone?
    [XdString] Last Eye Exam Where Pupils Were Dilated
    [XdString] Last Visited Dentist or Dental Clinic
    [XdString] Live With Anyone Depressed, Mentally Ill, Or Suicidal?
    [XdString] Live With Anyone Who Served TIme in Prison or Jail?
    [XdString] Live With Anyone Who Used Illegal Drugs or Abused Prescriptions?
    [XdString] Live With a Problem Drinker/Alcoholic?
    [XdString] Managed household tasks
    [XdString] Managed personal care
    [XdString] Month/Year of first COVID-19 vaccination
    [XdString] Month/Year of second COVID-19 vaccination
    [XdString] Need assistance with day-to_day activities due to confusion or memory loss
    [XdString] Now Taking Insulin
    [XdString] Number of Adult men in Household
    [XdString] Number of Adults in Household
    [XdString] Number of Adult women in Household
    [XdString] Number of COVID-19 vaccinations received
    [XdString] Number of Permanent Teeth Removed
    [XdString] Offered advice about what level of drinking is harmful or risky?
    [XdString] Participate In Clinical Trial As Part Of Cancer Treatment?
    [XdString] Provided regular care for family or friend
    [XdString] Received at least one COVID-19 vaccination
    [XdString] Relationship Of Person To Whom You Are Giving Care?
    [XdString] Safe time to talk
    [XdString] Sexual orientation
    [XdString] Sexual orientation
    [XdString] Still have Chronic Fatigue Syndrome or Myalgic Encephalomyelitis
    [XdString] Stopped Smoking in past 12 months
    [XdString] Times Checked for Glycosylated Hemoglobin
    [XdString] Time Since Most Recent PSA Test
    [XdString] Times past 30 days felt physical symptoms because of treatment due to your race
    [XdString] Told had Chronic Fatigue Syndrome (CFS) or (Myalgic Encephalomyelitis) ME
    [XdString] Type of Cancer
    [XdString] USEMRJN4
    [XdString] Were you advised to reduce or quit your drinking?
    [XdString] Were Your Parents Divorced/Seperated?
    [XdString] Were you treated worse than, the same, or better than people of other races?
    [XdString] What did you do to keep you from getting pregnant?
    [XdString] What Is The Major Health Problem, Illness, Disability For Care For Person?
    [XdString] What is your preferred birth control method?
    [XdString] What type of diabetes do you have?
    [XdString] What Type of Doctor Provides Majority of Your Care
    [XdString] What was main reason for not doing anything to keep you from getting pregnant?
    [XdString] What was the MAIN reason you had this PSA test?
    [XdString] When seeking health care past 12 months, was experience worse, same, better than people of other races?
    [XdString] When was the last time a they took a photo of the back of your eye?
    [XdString] When was the last time you took a course or class in how to manage your diabetes?
    [XdString] When was your last blood test for high blood sugar?
    [XdString] When you need help with day-to-day activities are you able to get it
    [XdString] Where did you get what you used to prevent pregnancy?
    [XdString] Where did you get your last flu shot/vaccine?
    [XdString] Who first suggested this PSA test?
    [XdString] Will you get COVID-19 vaccination?
    [XdString] Years smoked reported packs per day
    [XdToken] Accident State
    [XdToken] Marital status
    [XdToken] Pregnancy status
    [XdCount] Annual Sequence Number
    [XdCount] Interview Date
    [XdCount] Interview Day
    [XdCount] Interview Month
    [XdCount] Interview Year
    [XdCount] Age
    [XdQuantity] Adult flu shot/spray past 12 mos
    [XdQuantity] Adults aged 18+ that have had permanent teeth extracted
    [XdQuantity] Adults aged 65+ who have had all their natural teeth extracted
    [XdQuantity] Adults that have visited a dentist, dental hygenist or dental clinic within the past year
    [XdQuantity] Adults with good or better health
    [XdQuantity] Are you 18 years of age or older?
    [XdQuantity] Are You A Veteran
    [XdQuantity] Are you deaf or do you have serious difficulty hearing?
    [XdQuantity] Are you male or female?
    [XdQuantity] Avg alcoholic drinks per day in past 30
    [XdQuantity] Binge Drinking
    [XdQuantity] Binge Drinking Calculated Variable
    [XdQuantity] Blind or Difficulty seeing
    [XdQuantity] Calculated non-Hispanic Race including multiracial
    [XdQuantity] Calculated sex variable
    [XdQuantity] Cellular Telephone
    [XdQuantity] Child Hispanic, Latino/a, or Spanish origin calculated variable
    [XdQuantity] Child Non-Hispanic Race including Multiracial
    [XdQuantity] Computed Asthma Status
    [XdQuantity] Computed body mass index categories
    [XdQuantity] Computed Five level race/ethnicity category.
    [XdQuantity] Computed Height in Inches
    [XdQuantity] Computed Height in Meters
    [XdQuantity] Computed income categories
    [XdQuantity] Computed level of education completed categories
    [XdQuantity] Computed Mental Health Status
    [XdQuantity] Computed number of children in household
    [XdQuantity] Computed Physical Health Status
    [XdQuantity] Computed Preferred Race
    [XdQuantity] Computed Race-Ethnicity grouping
    [XdQuantity] Computed race groups used for internet prevalence tables
    [XdQuantity] Computed Smoking Status
    [XdQuantity] Computed Weight in Kilograms
    [XdQuantity] Correct telephone number?
    [XdQuantity] Could Not Afford To See Doctor
    [XdQuantity] CPDEMO1C
    [XdQuantity] Current Asthma Calculated Variable
    [XdQuantity] Current E-cigarette User Calculated Variable
    [XdQuantity] Current Smoking Calculated Variable
    [XdQuantity] Days in past 30 had alcoholic beverage
    [XdQuantity] Design weight use in raking
    [XdQuantity] DIABAGE4
    [XdQuantity] Did you have a CT or CAT scan?
    [XdQuantity] Difficulty Concentrating or Remembering
    [XdQuantity] Difficulty Doing Errands Alone
    [XdQuantity] Difficulty Dressing or Bathing
    [XdQuantity] Difficulty Walking or Climbing Stairs
    [XdQuantity] Do Any High Risk Situations Apply
    [XdQuantity] Do you now use e-cigarettes, or vaping products every day, some days, or not at all?
    [XdQuantity] Drink any alcoholic beverages in past 30 days
    [XdQuantity] Dual Phone Use Categories
    [XdQuantity] Dual Phone Use Correction Factor
    [XdQuantity] During the past 12 months have you received food stamps
    [XdQuantity] Education Level
    [XdQuantity] Ever been tested for HIV calculated variable
    [XdQuantity] Ever Diagnosed with Angina or Coronary Heart Disease
    [XdQuantity] Ever Diagnosed with a Stroke
    [XdQuantity] Ever Diagnosed with Heart Attack
    [XdQuantity] Ever had a colonoscopy, sigmoidoscopy, or both
    [XdQuantity] Ever had any other kind of test for colorectal cancer
    [XdQuantity] Ever had a virtual colonoscopy
    [XdQuantity] Ever had CHD or MI
    [XdQuantity] Ever Had Sigmoidoscopy/Colonoscopy
    [XdQuantity] Ever had stool DNA test?
    [XdQuantity] Ever had stool test?
    [XdQuantity] Ever tested H.I.V.
    [XdQuantity] Ever Told Had Asthma
    [XdQuantity] (Ever told) you had a depressive disorder
    [XdQuantity] Ever told you had C.O.P.D. emphysema or chronic bronchitis?
    [XdQuantity] (Ever told) you had diabetes
    [XdQuantity] (Ever told) (you had) melanoma or any other types of cancer?
    [XdQuantity] (Ever told) (you had) skin cancer that is not melanoma?
    [XdQuantity] Ever told you have kidney disease?
    [XdQuantity] Exercise in Past 30 Days
    [XdQuantity] File Month
    [XdQuantity] Final child weight: Land-line and Cell-Phone data
    [XdQuantity] Final Disposition
    [XdQuantity] Final weight: Land-line and cell-phone data
    [XdQuantity] Flu Shot Calculated Variable
    [XdQuantity] Four level child age
    [XdQuantity] Frequency of Days Now Smoking
    [XdQuantity] Gender of child
    [XdQuantity] General Health
    [XdQuantity] Had colonoscopy calculated variable
    [XdQuantity] Had Hysterectomy
    [XdQuantity] Had sigmoidoscopy calculated variable
    [XdQuantity] Has a lack of reliable transportation kept you from appointments, meetings, work, or getting things needed
    [XdQuantity] Have an 3 month or longer covid symptoms?
    [XdQuantity] Have an H.P.V. test and recent cervical cancer screening
    [XdQuantity] Have any health insurance
    [XdQuantity] Have a PAP test and recent cervical cancer screening
    [XdQuantity] Have Personal Health Care Provider?
    [XdQuantity] Have you ever been told you tested positive for COVID 19?
    [XdQuantity] Have you ever had a cervical cancer screening test?
    [XdQuantity] Have You Ever Had a Mammogram
    [XdQuantity] Have you lost employment or had hours reduced?
    [XdQuantity] Heavy Alcohol Consumption Calculated Variable
    [XdQuantity] Hispanic, Latino/a, or Spanish origin calculated variable
    [XdQuantity] Hlth pro ever said child has asthma
    [XdQuantity] Household Landline Telephones
    [XdQuantity] How Long since Last Mammogram
    [XdQuantity] How long since you had colonoscopy
    [XdQuantity] How long since you had sigmoidoscopy
    [XdQuantity] How long since you had stool DNA
    [XdQuantity] How long since you had stool test?
    [XdQuantity] How long since you had virtual colonoscopy
    [XdQuantity] How Much Time Do You Sleep
    [XdQuantity] How often did the food that you bought not last, and you didn’t have money to get more?
    [XdQuantity] How often do you feel socially isolated from others?
    [XdQuantity] How often get emotional support needed
    [XdQuantity] How often have you felt this kind of stress?
    [XdQuantity] How old when you first started smoking?
    [XdQuantity] How old when you last smoked?
    [XdQuantity] Imputed race/ethnicity value
    [XdQuantity] Language identifier
    [XdQuantity] Leisure Time Physical Activity Calculated Variable
    [XdQuantity] Length of time since last routine checkup
    [XdQuantity] Lifetime Asthma Calculated Variable
    [XdQuantity] Lung cancer screening recommendation status
    [XdQuantity] Metropolitan Status
    [XdQuantity] Metropolitan Status Code
    [XdQuantity] Month and Year of Last HIV Test
    [XdQuantity] Most drinks on single occasion past 30 days
    [XdQuantity] Number of Adults in Household
    [XdQuantity] Number of Children in Household
    [XdQuantity] Number of Days Mental Health Not Good
    [XdQuantity] Number of Days Physical Health Not Good
    [XdQuantity] Number of packs of cigarettes smoked per day
    [XdQuantity] Number of years since quit smoking cigarettes
    [XdQuantity] Number of years smoked cigarettes
    [XdQuantity] NUMPHON4
    [XdQuantity] On average, how many cigarettes do you smoke each day?
    [XdQuantity] Overweight or obese calculated variable
    [XdQuantity] Own or Rent Home
    [XdQuantity] Pneumonia shot ever
    [XdQuantity] Pneumonia Vaccination Calculated Variable
    [XdQuantity] Poor Physical or Mental Health
    [XdQuantity] Preferred Child Race Categories
    [XdQuantity] Primary Sampling Unit
    [XdQuantity] Private Residence?
    [XdQuantity] Questionnaire Version Identifier
    [XdQuantity] _RACEG22
    [XdQuantity] Raw weighting factor used in raking
    [XdQuantity] Received Tetanus Shot Since 2005?
    [XdQuantity] Relationship to child
    [XdQuantity] Reported age in five-year age categories calculated variable
    [XdQuantity] Reported age in two age groups calculated variable
    [XdQuantity] Resident of State
    [XdQuantity] Respondents aged 18-64 with health insurance
    [XdQuantity] Respondents aged 45-75 who have fully met the USPSTF recommendations
    [XdQuantity] Respondents aged 45-75 who have had a colonoscopy within the past ten years
    [XdQuantity] Respondents aged 45-75 who have had a sigmoidoscopy within the past five years
    [XdQuantity] Respondents aged 45-75 who have had a sigmoidoscopy within the past ten years
    [XdQuantity] Respondents aged 45-75 who have had a stool DNA test within the past three years
    [XdQuantity] Respondents aged 45-75 who have had a stool test within the past year
    [XdQuantity] Respondents aged 45-75 who have had a virtual colonoscopy within the past five years
    [XdQuantity] Respondents diagnosed with arthritis
    [XdQuantity] Respondent selection
    [XdQuantity] Sample Design Stratification Variable
    [XdQuantity] Satisfaction with life
    [XdQuantity] _SBONTI1
    [XdQuantity] Sex of Respondent
    [XdQuantity] Smoked at Least 100 Cigarettes
    [XdQuantity] Smoking Group
    [XdQuantity] Still Have Asthma
    [XdQuantity] Stratum weight
    [XdQuantity] Time since last cervical cancer screening test
    [XdQuantity] Time Since Last Sigmoidoscopy/Colonoscopy
    [XdQuantity] Told Had Arthritis
    [XdQuantity] Truncated design weight used in adult combined land line and cell phone raking
    [XdQuantity] Urban/Rural Status
    [XdQuantity] Use of Smokeless Tobacco Products
    [XdQuantity] Was test part of Cologuard test?
    [XdQuantity] Were any CT or CAT scans done to check for lung cancer?
    [XdQuantity] Were you not able to pay utility bills or threatened to lose service?
    [XdQuantity] Were you not able to pay your bills?
    [XdQuantity] What is Primary Source of Health Insurance?
    [XdQuantity] When did you have your most recent CT or CAT scan?
    [XdQuantity] When did you receive your most recent seasonal flu shot/spray?
    [XdQuantity] Which was the primary symptom that you experienced?
    [XdQuantity] Women respondents aged 40+ who have had a mammogram in the past two years
    [XdQuantity] Women respondents aged 50-74 that have had a mammogram in the past two years
    [XdQuantity] Taxable Income
    [XdQuantity] BMI
    [XdQuantity] Body Weight
    [XdQuantity] Height
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| Age Told Had Cancer | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Age Told Had Cancer | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Age Told Had Cancer | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Any Firearms in Home | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Any Firearms in Home | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Any Firearms in Home | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Any Firearms Loaded | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Any Firearms Loaded | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Any Firearms Loaded | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Any Loaded Firearms Also Unlocked | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Any Loaded Firearms Also Unlocked | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Any Loaded Firearms Also Unlocked | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Are you 18 years of age or older? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Are you 18 years of age or older? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Are you 18 years of age or older? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Are You Doing Anything to Keep From Getting Pregnant? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Are You Doing Anything to Keep From Getting Pregnant? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Are You Doing Anything to Keep From Getting Pregnant? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Are you male or female? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Are you male or female? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Are you male or female? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Are you male or female? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Are you male or female? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Are you male or female? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Are you male or female? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Are you male or female? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Are you male or female? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Asked during checkup if you drink alchohol | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Asked during checkup if you drink alchohol | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Asked during checkup if you drink alchohol | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Asked in person or by form how much you drink? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Asked in person or by form how much you drink? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Asked in person or by form how much you drink? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Asked whether you drank [5 FOR MEN /4 FOR WOMEN] or more alcoholic drinks on an occasion? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Asked whether you drank [5 FOR MEN /4 FOR WOMEN] or more alcoholic drinks on an occasion? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Asked whether you drank [5 FOR MEN /4 FOR WOMEN] or more alcoholic drinks on an occasion? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Child´s sex at birth | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Child´s sex at birth | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Child´s sex at birth | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Child still have asthma? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Child still have asthma? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Child still have asthma? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Computed drink-occasions-per-day | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Computed drink-occasions-per-day | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Computed drink-occasions-per-day | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Computed number of drinks of alcohol beverages per week | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Computed number of drinks of alcohol beverages per week | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Computed number of drinks of alcohol beverages per week | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Correct Phone Number? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Correct Phone Number? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Correct Phone Number? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Currently Have Physical Pain From Cancer Or Treatment? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Currently Have Physical Pain From Cancer Or Treatment? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Currently Have Physical Pain From Cancer Or Treatment? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Currently Receiving Treatment for Cancer | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Currently Receiving Treatment for Cancer | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Currently Receiving Treatment for Cancer | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Did an adult make sure basic needs were met | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Did an adult make sure basic needs were met | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Did an adult make sure basic needs were met | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Did an adult make you feel safe and protected | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Did an adult make you feel safe and protected | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Did an adult make you feel safe and protected | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Did Health Insurance Pay For All Of Your Cancer Treatment | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Did Health Insurance Pay For All Of Your Cancer Treatment | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Did Health Insurance Pay For All Of Your Cancer Treatment | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Did you cough up phlegm? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Did you cough up phlegm? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Did you cough up phlegm? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Did you dab marijuana or cannabis? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Did you dab marijuana or cannabis? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Did you dab marijuana or cannabis? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Did you do anything to keep from getting pregnant? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Did you do anything to keep from getting pregnant? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Did you do anything to keep from getting pregnant? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Did you eat marijuana or cannabis? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Did you eat marijuana or cannabis? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Did you eat marijuana or cannabis? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Did you have a cough? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Did you have a cough? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Did you have a cough? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Did you have shortness of breath? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Did you have shortness of breath? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Did you have shortness of breath? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Did You Receive a Summary of Cancer Treatments Received | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Did You Receive a Summary of Cancer Treatments Received | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Did You Receive a Summary of Cancer Treatments Received | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Did you smoke marijuana or cannabis? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Did you smoke marijuana or cannabis? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Did you smoke marijuana or cannabis? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Did you talk about the advantages or disadvantages of P.S.A. test | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Did you talk about the advantages or disadvantages of P.S.A. test | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Did you talk about the advantages or disadvantages of P.S.A. test | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Did you use marijuana or cannabis some other way? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Did you use marijuana or cannabis some other way? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Did you use marijuana or cannabis some other way? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Did you vape marijuana or cannabis? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Did you vape marijuana or cannabis? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Did you vape marijuana or cannabis? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Does confusion or memory loss interfere with work or social activities | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Does confusion or memory loss interfere with work or social activities | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Does confusion or memory loss interfere with work or social activities | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Does Person Being Cared For Have Alzheimer´s Disease? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Does Person Being Cared For Have Alzheimer´s Disease? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Does Person Being Cared For Have Alzheimer´s Disease? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Do you also have a landline telephone? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Do you also have a landline telephone? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Do you also have a landline telephone? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Do you consider yourself to be transgender? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Do you consider yourself to be transgender? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Do you consider yourself to be transgender? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Do you currently live in ____(state)____? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Do you currently live in ____(state)____? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Do you currently live in ____(state)____? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Do you expect to have a relative you will need to provide care for? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Do you expect to have a relative you will need to provide care for? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Do you expect to have a relative you will need to provide care for? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Do you live in a private residence? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Do you live in a private residence? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Do you live in a private residence? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Do you live in college housing? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Do you live in college housing? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Do you live in college housing? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Do you live in college housing? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Do you live in college housing? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Do you live in college housing? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Do you usually smoke menthol cigarettes? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Do you usually smoke menthol cigarettes? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Do you usually smoke menthol cigarettes? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Do you usually use menthol e-cigarettes? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Do you usually use menthol e-cigarettes? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Do you usually use menthol e-cigarettes? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| During the past 30 days, on how many days did you use marijuana or hashish? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| During the past 30 days, on how many days did you use marijuana or hashish? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| During the past 30 days, on how many days did you use marijuana or hashish? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Ever been told by a doctor or other health professional that you have pre-diabetes or borderline diabetes? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever been told by a doctor or other health professional that you have pre-diabetes or borderline diabetes? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever been told by a doctor or other health professional that you have pre-diabetes or borderline diabetes? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Ever Denied Insurance Coverage Because Of Your Cancer? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever Denied Insurance Coverage Because Of Your Cancer? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever Denied Insurance Coverage Because Of Your Cancer? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Ever Had Feet Sores or Irritations Lasting More Than Four Weeks | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever Had Feet Sores or Irritations Lasting More Than Four Weeks | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever Had Feet Sores or Irritations Lasting More Than Four Weeks | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Ever Had PSA Test | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever Had PSA Test | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever Had PSA Test | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Ever Receive Instructions From A Doctor For Follow-Up Check-Ups | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever Receive Instructions From A Doctor For Follow-Up Check-Ups | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever Receive Instructions From A Doctor For Follow-Up Check-Ups | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Given up day-to-day chores due to confusion or memory loss | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Given up day-to-day chores due to confusion or memory loss | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Given up day-to-day chores due to confusion or memory loss | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Have you discussed your confusion or memory loss with a health care professional? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Have you discussed your confusion or memory loss with a health care professional? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Have you discussed your confusion or memory loss with a health care professional? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Have you ever been given a breathing test? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Have you ever been given a breathing test? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Have you ever been given a breathing test? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Have you ever had an H.P.V. vaccination? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Have you ever had an H.P.V. vaccination? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Have you ever had an H.P.V. vaccination? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Have you ever had the shingles or zoster vaccine? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Have you ever had the shingles or zoster vaccine? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Have you ever had the shingles or zoster vaccine? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Have you experienced confusion or memory loss that is happening more often or is getting worse? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Have you experienced confusion or memory loss that is happening more often or is getting worse? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Have you experienced confusion or memory loss that is happening more often or is getting worse? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Have you have sexual intercourse? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Have you have sexual intercourse? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Have you have sexual intercourse? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Have you heard of heated tobacco products? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Have you heard of heated tobacco products? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Have you heard of heated tobacco products? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| How do other people usually classify you in this country? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How do other people usually classify you in this country? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How do other people usually classify you in this country? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| How do you feel you were treated at work compared to people of other races in past 12 months? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How do you feel you were treated at work compared to people of other races in past 12 months? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How do you feel you were treated at work compared to people of other races in past 12 months? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| How Long Provided Care For Person. | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How Long Provided Care For Person. | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How Long Provided Care For Person. | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| How many hours a week are you been able to work | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How many hours a week are you been able to work | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How many hours a week are you been able to work | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| How Many Hours Do You Provide Care For Person? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How Many Hours Do You Provide Care For Person? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How Many Hours Do You Provide Care For Person? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| How many HPV shots did you receive? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How many HPV shots did you receive? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How many HPV shots did you receive? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| How Many Types of Cancer? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How Many Types of Cancer? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How Many Types of Cancer? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| How many years have you smoked tobacco products? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How many years have you smoked tobacco products? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How many years have you smoked tobacco products? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| How Often Did Anyone Ever Force You to Have Sex? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How Often Did Anyone Ever Force You to Have Sex? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How Often Did Anyone Ever Force You to Have Sex? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| How Often Did Anyone Ever Touch You Sexually? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How Often Did Anyone Ever Touch You Sexually? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How Often Did Anyone Ever Touch You Sexually? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| How Often Did Anyone Make You Touch Them Sexually? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How Often Did Anyone Make You Touch Them Sexually? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How Often Did Anyone Make You Touch Them Sexually? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| How Often Did A Parent Physically Hurt You In Any Way? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How Often Did A Parent Physically Hurt You In Any Way? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How Often Did A Parent Physically Hurt You In Any Way? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| How Often Did A Parent Swear At You? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How Often Did A Parent Swear At You? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How Often Did A Parent Swear At You? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| How Often Did Your Parents Beat Each Other Up? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How Often Did Your Parents Beat Each Other Up? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How Often Did Your Parents Beat Each Other Up? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| How often do you think about your race? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How often do you think about your race? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How often do you think about your race? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Instructions Written or Printed | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Instructions Written or Printed | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Instructions Written or Printed | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Intend to get COVID-19 vaccination | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Intend to get COVID-19 vaccination | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Intend to get COVID-19 vaccination | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Interval Since Last Smoked | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Interval Since Last Smoked | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Interval Since Last Smoked | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Is Pain Under Control? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Is Pain Under Control? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Is Pain Under Control? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Is this a cell phone? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Is this a cell phone? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Is this a cell phone? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Last Eye Exam Where Pupils Were Dilated | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Last Eye Exam Where Pupils Were Dilated | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Last Eye Exam Where Pupils Were Dilated | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Last Visited Dentist or Dental Clinic | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Last Visited Dentist or Dental Clinic | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Last Visited Dentist or Dental Clinic | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Live With Anyone Depressed, Mentally Ill, Or Suicidal? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Live With Anyone Depressed, Mentally Ill, Or Suicidal? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Live With Anyone Depressed, Mentally Ill, Or Suicidal? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Live With Anyone Who Served TIme in Prison or Jail? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Live With Anyone Who Served TIme in Prison or Jail? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Live With Anyone Who Served TIme in Prison or Jail? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Live With Anyone Who Used Illegal Drugs or Abused Prescriptions? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Live With Anyone Who Used Illegal Drugs or Abused Prescriptions? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Live With Anyone Who Used Illegal Drugs or Abused Prescriptions? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Live With a Problem Drinker/Alcoholic? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Live With a Problem Drinker/Alcoholic? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Live With a Problem Drinker/Alcoholic? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Managed household tasks | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Managed household tasks | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Managed household tasks | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Managed personal care | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Managed personal care | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Managed personal care | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Month/Year of first COVID-19 vaccination | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Month/Year of first COVID-19 vaccination | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Month/Year of first COVID-19 vaccination | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Month/Year of second COVID-19 vaccination | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Month/Year of second COVID-19 vaccination | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Month/Year of second COVID-19 vaccination | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Need assistance with day-to_day activities due to confusion or memory loss | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Need assistance with day-to_day activities due to confusion or memory loss | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Need assistance with day-to_day activities due to confusion or memory loss | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Now Taking Insulin | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Now Taking Insulin | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Now Taking Insulin | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Number of Adult men in Household | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Number of Adult men in Household | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Number of Adult men in Household | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Number of Adults in Household | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Number of Adults in Household | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Number of Adults in Household | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Number of Adult women in Household | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Number of Adult women in Household | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Number of Adult women in Household | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Number of COVID-19 vaccinations received | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Number of COVID-19 vaccinations received | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Number of COVID-19 vaccinations received | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Number of Permanent Teeth Removed | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Number of Permanent Teeth Removed | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Number of Permanent Teeth Removed | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Offered advice about what level of drinking is harmful or risky? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Offered advice about what level of drinking is harmful or risky? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Offered advice about what level of drinking is harmful or risky? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Participate In Clinical Trial As Part Of Cancer Treatment? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Participate In Clinical Trial As Part Of Cancer Treatment? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Participate In Clinical Trial As Part Of Cancer Treatment? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Provided regular care for family or friend | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Provided regular care for family or friend | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Provided regular care for family or friend | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Received at least one COVID-19 vaccination | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Received at least one COVID-19 vaccination | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Received at least one COVID-19 vaccination | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Relationship Of Person To Whom You Are Giving Care? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Relationship Of Person To Whom You Are Giving Care? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Relationship Of Person To Whom You Are Giving Care? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Safe time to talk | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Safe time to talk | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Safe time to talk | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Sexual orientation | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Sexual orientation | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Sexual orientation | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Sexual orientation | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Sexual orientation | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Sexual orientation | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Still have Chronic Fatigue Syndrome or Myalgic Encephalomyelitis | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Still have Chronic Fatigue Syndrome or Myalgic Encephalomyelitis | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Still have Chronic Fatigue Syndrome or Myalgic Encephalomyelitis | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Stopped Smoking in past 12 months | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Stopped Smoking in past 12 months | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Stopped Smoking in past 12 months | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Times Checked for Glycosylated Hemoglobin | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Times Checked for Glycosylated Hemoglobin | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Times Checked for Glycosylated Hemoglobin | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Time Since Most Recent PSA Test | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Time Since Most Recent PSA Test | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Time Since Most Recent PSA Test | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Times past 30 days felt physical symptoms because of treatment due to your race | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Times past 30 days felt physical symptoms because of treatment due to your race | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Times past 30 days felt physical symptoms because of treatment due to your race | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Told had Chronic Fatigue Syndrome (CFS) or (Myalgic Encephalomyelitis) ME | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Told had Chronic Fatigue Syndrome (CFS) or (Myalgic Encephalomyelitis) ME | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Told had Chronic Fatigue Syndrome (CFS) or (Myalgic Encephalomyelitis) ME | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Type of Cancer | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Type of Cancer | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Type of Cancer | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| USEMRJN4 | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| USEMRJN4 | `dcterms:subject` | `http://snomed.info/id/410188000` |
| USEMRJN4 | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Were you advised to reduce or quit your drinking? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Were you advised to reduce or quit your drinking? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Were you advised to reduce or quit your drinking? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Were Your Parents Divorced/Seperated? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Were Your Parents Divorced/Seperated? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Were Your Parents Divorced/Seperated? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Were you treated worse than, the same, or better than people of other races? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Were you treated worse than, the same, or better than people of other races? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Were you treated worse than, the same, or better than people of other races? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| What did you do to keep you from getting pregnant? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| What did you do to keep you from getting pregnant? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| What did you do to keep you from getting pregnant? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| What Is The Major Health Problem, Illness, Disability For Care For Person? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| What Is The Major Health Problem, Illness, Disability For Care For Person? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| What Is The Major Health Problem, Illness, Disability For Care For Person? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| What is your preferred birth control method? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| What is your preferred birth control method? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| What is your preferred birth control method? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| What type of diabetes do you have? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| What type of diabetes do you have? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| What type of diabetes do you have? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| What Type of Doctor Provides Majority of Your Care | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| What Type of Doctor Provides Majority of Your Care | `dcterms:subject` | `http://snomed.info/id/410188000` |
| What Type of Doctor Provides Majority of Your Care | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| What was main reason for not doing anything to keep you from getting pregnant? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| What was main reason for not doing anything to keep you from getting pregnant? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| What was main reason for not doing anything to keep you from getting pregnant? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| What was the MAIN reason you had this PSA test? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| What was the MAIN reason you had this PSA test? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| What was the MAIN reason you had this PSA test? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| When seeking health care past 12 months, was experience worse, same, better than people of other races? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| When seeking health care past 12 months, was experience worse, same, better than people of other races? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| When seeking health care past 12 months, was experience worse, same, better than people of other races? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| When was the last time a they took a photo of the back of your eye? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| When was the last time a they took a photo of the back of your eye? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| When was the last time a they took a photo of the back of your eye? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| When was the last time you took a course or class in how to manage your diabetes? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| When was the last time you took a course or class in how to manage your diabetes? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| When was the last time you took a course or class in how to manage your diabetes? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| When was your last blood test for high blood sugar? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| When was your last blood test for high blood sugar? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| When was your last blood test for high blood sugar? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| When you need help with day-to-day activities are you able to get it | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| When you need help with day-to-day activities are you able to get it | `dcterms:subject` | `http://snomed.info/id/410188000` |
| When you need help with day-to-day activities are you able to get it | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Where did you get what you used to prevent pregnancy? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Where did you get what you used to prevent pregnancy? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Where did you get what you used to prevent pregnancy? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Where did you get your last flu shot/vaccine? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Where did you get your last flu shot/vaccine? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Where did you get your last flu shot/vaccine? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Who first suggested this PSA test? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Who first suggested this PSA test? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Who first suggested this PSA test? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Will you get COVID-19 vaccination? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Will you get COVID-19 vaccination? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Will you get COVID-19 vaccination? | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Years smoked reported packs per day | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Years smoked reported packs per day | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Years smoked reported packs per day | `rdfs:isDefinedBy` | `sdc4:XdStringType/xdstring-language` |
| Accident State | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q5690718` |
| Accident State | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1061489` |
| Marital status | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q11213` |
| Marital status | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q2798750` |
| Marital status | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q390551` |
| Pregnancy status | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q390551` |
| Pregnancy status | `rdfs:seeAlso` | `https://www.wikidata.org/wiki/Q208478` |
| Annual Sequence Number | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Annual Sequence Number | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Annual Sequence Number | `rdfs:isDefinedBy` | `sdc4:XdCountType/xdcount-value` |
| Interview Date | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Interview Date | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q12952511` |
| Interview Date | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Interview Day | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Interview Day | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q465018` |
| Interview Day | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Interview Month | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Interview Month | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q236` |
| Interview Month | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Interview Year | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Interview Year | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Interview Year | `rdfs:isDefinedBy` | `sdc4:XdCountType/xdcount-value` |
| Age | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q84263196` |
| Age | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q11213` |
| Age | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q390551` |
| Adult flu shot/spray past 12 mos | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Adult flu shot/spray past 12 mos | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Adult flu shot/spray past 12 mos | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Adults aged 18+ that have had permanent teeth extracted | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Adults aged 18+ that have had permanent teeth extracted | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Adults aged 18+ that have had permanent teeth extracted | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Adults aged 65+ who have had all their natural teeth extracted | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Adults aged 65+ who have had all their natural teeth extracted | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Adults aged 65+ who have had all their natural teeth extracted | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Adults that have visited a dentist, dental hygenist or dental clinic within the past year | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Adults that have visited a dentist, dental hygenist or dental clinic within the past year | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Adults that have visited a dentist, dental hygenist or dental clinic within the past year | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Adults with good or better health | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Adults with good or better health | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Adults with good or better health | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Are you 18 years of age or older? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Are you 18 years of age or older? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Are you 18 years of age or older? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Are You A Veteran | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Are You A Veteran | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Are You A Veteran | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Are you deaf or do you have serious difficulty hearing? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Are you deaf or do you have serious difficulty hearing? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Are you deaf or do you have serious difficulty hearing? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Are you male or female? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Are you male or female? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Are you male or female? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Avg alcoholic drinks per day in past 30 | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Avg alcoholic drinks per day in past 30 | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Avg alcoholic drinks per day in past 30 | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Binge Drinking | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Binge Drinking | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Binge Drinking | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Binge Drinking Calculated Variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Binge Drinking Calculated Variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Binge Drinking Calculated Variable | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Blind or Difficulty seeing | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Blind or Difficulty seeing | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Blind or Difficulty seeing | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Calculated non-Hispanic Race including multiracial | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Calculated non-Hispanic Race including multiracial | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Calculated non-Hispanic Race including multiracial | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Calculated sex variable | `rdfs:isDefinedBy` | `http://semanticscience.org/resource/SIO_010029` |
| Calculated sex variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Calculated sex variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Cellular Telephone | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Cellular Telephone | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Cellular Telephone | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Child Hispanic, Latino/a, or Spanish origin calculated variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Child Hispanic, Latino/a, or Spanish origin calculated variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Child Hispanic, Latino/a, or Spanish origin calculated variable | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Child Non-Hispanic Race including Multiracial | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Child Non-Hispanic Race including Multiracial | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Child Non-Hispanic Race including Multiracial | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Computed Asthma Status | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Computed Asthma Status | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Computed Asthma Status | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Computed body mass index categories | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Computed body mass index categories | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Computed body mass index categories | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Computed Five level race/ethnicity category. | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Computed Five level race/ethnicity category. | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Computed Five level race/ethnicity category. | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Computed Height in Inches | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Computed Height in Inches | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Computed Height in Inches | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Computed Height in Meters | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Computed Height in Meters | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Computed Height in Meters | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Computed income categories | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Computed income categories | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Computed income categories | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Computed level of education completed categories | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Computed level of education completed categories | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Computed level of education completed categories | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Computed Mental Health Status | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Computed Mental Health Status | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Computed Mental Health Status | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Computed number of children in household | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Computed number of children in household | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Computed number of children in household | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Computed Physical Health Status | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Computed Physical Health Status | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Computed Physical Health Status | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Computed Preferred Race | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Computed Preferred Race | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Computed Preferred Race | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Computed Race-Ethnicity grouping | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Computed Race-Ethnicity grouping | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Computed Race-Ethnicity grouping | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Computed race groups used for internet prevalence tables | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Computed race groups used for internet prevalence tables | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Computed race groups used for internet prevalence tables | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Computed Smoking Status | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Computed Smoking Status | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Computed Smoking Status | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Computed Weight in Kilograms | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Computed Weight in Kilograms | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Computed Weight in Kilograms | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Correct telephone number? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Correct telephone number? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Correct telephone number? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Could Not Afford To See Doctor | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Could Not Afford To See Doctor | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Could Not Afford To See Doctor | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| CPDEMO1C | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| CPDEMO1C | `dcterms:subject` | `http://snomed.info/id/410188000` |
| CPDEMO1C | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Current Asthma Calculated Variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Current Asthma Calculated Variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Current Asthma Calculated Variable | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Current E-cigarette User Calculated Variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Current E-cigarette User Calculated Variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Current E-cigarette User Calculated Variable | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Current Smoking Calculated Variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Current Smoking Calculated Variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Current Smoking Calculated Variable | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Days in past 30 had alcoholic beverage | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Days in past 30 had alcoholic beverage | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Days in past 30 had alcoholic beverage | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Design weight use in raking | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Design weight use in raking | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Design weight use in raking | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| DIABAGE4 | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| DIABAGE4 | `dcterms:subject` | `http://snomed.info/id/410188000` |
| DIABAGE4 | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Did you have a CT or CAT scan? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Did you have a CT or CAT scan? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Did you have a CT or CAT scan? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Difficulty Concentrating or Remembering | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Difficulty Concentrating or Remembering | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Difficulty Concentrating or Remembering | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Difficulty Doing Errands Alone | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Difficulty Doing Errands Alone | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Difficulty Doing Errands Alone | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Difficulty Dressing or Bathing | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Difficulty Dressing or Bathing | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Difficulty Dressing or Bathing | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Difficulty Walking or Climbing Stairs | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Difficulty Walking or Climbing Stairs | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Difficulty Walking or Climbing Stairs | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Do Any High Risk Situations Apply | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Do Any High Risk Situations Apply | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Do Any High Risk Situations Apply | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Do you now use e-cigarettes, or vaping products every day, some days, or not at all? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Do you now use e-cigarettes, or vaping products every day, some days, or not at all? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Do you now use e-cigarettes, or vaping products every day, some days, or not at all? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Drink any alcoholic beverages in past 30 days | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Drink any alcoholic beverages in past 30 days | `skos:closeMatch` | `http://snomed.info/id/160573003` |
| Drink any alcoholic beverages in past 30 days | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Drink any alcoholic beverages in past 30 days | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Dual Phone Use Categories | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Dual Phone Use Categories | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Dual Phone Use Categories | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Dual Phone Use Correction Factor | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Dual Phone Use Correction Factor | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Dual Phone Use Correction Factor | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| During the past 12 months have you received food stamps | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| During the past 12 months have you received food stamps | `dcterms:subject` | `http://snomed.info/id/410188000` |
| During the past 12 months have you received food stamps | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Education Level | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Education Level | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Education Level | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Ever been tested for HIV calculated variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever been tested for HIV calculated variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever been tested for HIV calculated variable | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Ever Diagnosed with Angina or Coronary Heart Disease | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever Diagnosed with Angina or Coronary Heart Disease | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever Diagnosed with Angina or Coronary Heart Disease | `skos:closeMatch` | `http://snomed.info/id/53741008` |
| Ever Diagnosed with Angina or Coronary Heart Disease | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Ever Diagnosed with a Stroke | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever Diagnosed with a Stroke | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever Diagnosed with a Stroke | `skos:closeMatch` | `http://snomed.info/id/230690007` |
| Ever Diagnosed with a Stroke | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Ever Diagnosed with Heart Attack | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever Diagnosed with Heart Attack | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever Diagnosed with Heart Attack | `skos:closeMatch` | `http://snomed.info/id/22298006` |
| Ever Diagnosed with Heart Attack | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Ever had a colonoscopy, sigmoidoscopy, or both | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever had a colonoscopy, sigmoidoscopy, or both | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever had a colonoscopy, sigmoidoscopy, or both | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Ever had any other kind of test for colorectal cancer | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever had any other kind of test for colorectal cancer | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever had any other kind of test for colorectal cancer | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Ever had a virtual colonoscopy | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever had a virtual colonoscopy | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever had a virtual colonoscopy | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Ever had CHD or MI | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever had CHD or MI | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever had CHD or MI | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Ever Had Sigmoidoscopy/Colonoscopy | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever Had Sigmoidoscopy/Colonoscopy | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever Had Sigmoidoscopy/Colonoscopy | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Ever had stool DNA test? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever had stool DNA test? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever had stool DNA test? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Ever had stool test? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever had stool test? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever had stool test? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Ever tested H.I.V. | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever tested H.I.V. | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever tested H.I.V. | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Ever Told Had Asthma | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever Told Had Asthma | `skos:closeMatch` | `http://snomed.info/id/195967001` |
| Ever Told Had Asthma | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever Told Had Asthma | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| (Ever told) you had a depressive disorder | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| (Ever told) you had a depressive disorder | `dcterms:subject` | `http://snomed.info/id/410188000` |
| (Ever told) you had a depressive disorder | `skos:closeMatch` | `http://snomed.info/id/35489007` |
| (Ever told) you had a depressive disorder | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Ever told you had C.O.P.D. emphysema or chronic bronchitis? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever told you had C.O.P.D. emphysema or chronic bronchitis? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever told you had C.O.P.D. emphysema or chronic bronchitis? | `skos:closeMatch` | `http://snomed.info/id/13645005` |
| Ever told you had C.O.P.D. emphysema or chronic bronchitis? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| (Ever told) you had diabetes | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| (Ever told) you had diabetes | `dcterms:subject` | `http://snomed.info/id/410188000` |
| (Ever told) you had diabetes | `skos:closeMatch` | `http://snomed.info/id/73211009` |
| (Ever told) you had diabetes | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| (Ever told) (you had) melanoma or any other types of cancer? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| (Ever told) (you had) melanoma or any other types of cancer? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| (Ever told) (you had) melanoma or any other types of cancer? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| (Ever told) (you had) skin cancer that is not melanoma? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| (Ever told) (you had) skin cancer that is not melanoma? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| (Ever told) (you had) skin cancer that is not melanoma? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Ever told you have kidney disease? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Ever told you have kidney disease? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Ever told you have kidney disease? | `skos:closeMatch` | `http://snomed.info/id/709044004` |
| Ever told you have kidney disease? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Exercise in Past 30 Days | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Exercise in Past 30 Days | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Exercise in Past 30 Days | `skos:closeMatch` | `http://snomed.info/id/256235009` |
| Exercise in Past 30 Days | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| File Month | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| File Month | `dcterms:subject` | `http://snomed.info/id/410188000` |
| File Month | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Final child weight: Land-line and Cell-Phone data | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Final child weight: Land-line and Cell-Phone data | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Final child weight: Land-line and Cell-Phone data | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Final Disposition | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Final Disposition | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Final Disposition | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Final weight: Land-line and cell-phone data | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Final weight: Land-line and cell-phone data | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Final weight: Land-line and cell-phone data | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Flu Shot Calculated Variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Flu Shot Calculated Variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Flu Shot Calculated Variable | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Four level child age | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Four level child age | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Four level child age | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Frequency of Days Now Smoking | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Frequency of Days Now Smoking | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Frequency of Days Now Smoking | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Gender of child | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Gender of child | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Gender of child | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| General Health | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| General Health | `skos:closeMatch` | `https://loinc.org/11323-3` |
| General Health | `dcterms:subject` | `http://snomed.info/id/410188000` |
| General Health | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Had colonoscopy calculated variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Had colonoscopy calculated variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Had colonoscopy calculated variable | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Had Hysterectomy | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Had Hysterectomy | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Had Hysterectomy | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Had sigmoidoscopy calculated variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Had sigmoidoscopy calculated variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Had sigmoidoscopy calculated variable | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Has a lack of reliable transportation kept you from appointments, meetings, work, or getting things needed | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Has a lack of reliable transportation kept you from appointments, meetings, work, or getting things needed | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Has a lack of reliable transportation kept you from appointments, meetings, work, or getting things needed | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Have an 3 month or longer covid symptoms? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Have an 3 month or longer covid symptoms? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Have an 3 month or longer covid symptoms? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Have an H.P.V. test and recent cervical cancer screening | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Have an H.P.V. test and recent cervical cancer screening | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Have an H.P.V. test and recent cervical cancer screening | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Have any health insurance | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Have any health insurance | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Have any health insurance | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Have a PAP test and recent cervical cancer screening | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Have a PAP test and recent cervical cancer screening | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Have a PAP test and recent cervical cancer screening | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Have Personal Health Care Provider? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Have Personal Health Care Provider? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Have Personal Health Care Provider? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Have you ever been told you tested positive for COVID 19? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Have you ever been told you tested positive for COVID 19? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Have you ever been told you tested positive for COVID 19? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Have you ever had a cervical cancer screening test? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Have you ever had a cervical cancer screening test? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Have you ever had a cervical cancer screening test? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Have You Ever Had a Mammogram | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Have You Ever Had a Mammogram | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Have You Ever Had a Mammogram | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Have you lost employment or had hours reduced? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Have you lost employment or had hours reduced? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Have you lost employment or had hours reduced? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Heavy Alcohol Consumption Calculated Variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Heavy Alcohol Consumption Calculated Variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Heavy Alcohol Consumption Calculated Variable | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Hispanic, Latino/a, or Spanish origin calculated variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Hispanic, Latino/a, or Spanish origin calculated variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Hispanic, Latino/a, or Spanish origin calculated variable | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Hlth pro ever said child has asthma | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Hlth pro ever said child has asthma | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Hlth pro ever said child has asthma | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Household Landline Telephones | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Household Landline Telephones | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Household Landline Telephones | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| How Long since Last Mammogram | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How Long since Last Mammogram | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How Long since Last Mammogram | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| How long since you had colonoscopy | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How long since you had colonoscopy | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How long since you had colonoscopy | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| How long since you had sigmoidoscopy | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How long since you had sigmoidoscopy | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How long since you had sigmoidoscopy | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| How long since you had stool DNA | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How long since you had stool DNA | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How long since you had stool DNA | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| How long since you had stool test? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How long since you had stool test? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How long since you had stool test? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| How long since you had virtual colonoscopy | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How long since you had virtual colonoscopy | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How long since you had virtual colonoscopy | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| How Much Time Do You Sleep | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How Much Time Do You Sleep | `skos:closeMatch` | `https://loinc.org/65968-0` |
| How Much Time Do You Sleep | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How Much Time Do You Sleep | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| How often did the food that you bought not last, and you didn’t have money to get more? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How often did the food that you bought not last, and you didn’t have money to get more? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How often did the food that you bought not last, and you didn’t have money to get more? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| How often do you feel socially isolated from others? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How often do you feel socially isolated from others? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How often do you feel socially isolated from others? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| How often get emotional support needed | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How often get emotional support needed | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How often get emotional support needed | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| How often have you felt this kind of stress? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How often have you felt this kind of stress? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How often have you felt this kind of stress? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| How old when you first started smoking? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How old when you first started smoking? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How old when you first started smoking? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| How old when you last smoked? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| How old when you last smoked? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| How old when you last smoked? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Imputed race/ethnicity value | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Imputed race/ethnicity value | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Imputed race/ethnicity value | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Language identifier | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Language identifier | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Language identifier | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Leisure Time Physical Activity Calculated Variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Leisure Time Physical Activity Calculated Variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Leisure Time Physical Activity Calculated Variable | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Length of time since last routine checkup | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Length of time since last routine checkup | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Length of time since last routine checkup | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Lifetime Asthma Calculated Variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Lifetime Asthma Calculated Variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Lifetime Asthma Calculated Variable | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Lung cancer screening recommendation status | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Lung cancer screening recommendation status | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Lung cancer screening recommendation status | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Metropolitan Status | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Metropolitan Status | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Metropolitan Status | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Metropolitan Status Code | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Metropolitan Status Code | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Metropolitan Status Code | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Month and Year of Last HIV Test | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Month and Year of Last HIV Test | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Month and Year of Last HIV Test | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Most drinks on single occasion past 30 days | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Most drinks on single occasion past 30 days | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Most drinks on single occasion past 30 days | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Number of Adults in Household | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Number of Adults in Household | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Number of Adults in Household | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Number of Children in Household | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Number of Children in Household | `rdfs:isDefinedBy` | `https://schema.org/children` |
| Number of Children in Household | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Number of Days Mental Health Not Good | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Number of Days Mental Health Not Good | `skos:closeMatch` | `https://loinc.org/77850-3` |
| Number of Days Mental Health Not Good | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Number of Days Mental Health Not Good | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Number of Days Physical Health Not Good | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Number of Days Physical Health Not Good | `skos:closeMatch` | `https://loinc.org/77849-5` |
| Number of Days Physical Health Not Good | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Number of Days Physical Health Not Good | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Number of packs of cigarettes smoked per day | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Number of packs of cigarettes smoked per day | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Number of packs of cigarettes smoked per day | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Number of years since quit smoking cigarettes | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Number of years since quit smoking cigarettes | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Number of years since quit smoking cigarettes | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Number of years smoked cigarettes | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Number of years smoked cigarettes | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Number of years smoked cigarettes | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| NUMPHON4 | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| NUMPHON4 | `dcterms:subject` | `http://snomed.info/id/410188000` |
| NUMPHON4 | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| On average, how many cigarettes do you smoke each day? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| On average, how many cigarettes do you smoke each day? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| On average, how many cigarettes do you smoke each day? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Overweight or obese calculated variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Overweight or obese calculated variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Overweight or obese calculated variable | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Own or Rent Home | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Own or Rent Home | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Own or Rent Home | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Pneumonia shot ever | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Pneumonia shot ever | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Pneumonia shot ever | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Pneumonia Vaccination Calculated Variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Pneumonia Vaccination Calculated Variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Pneumonia Vaccination Calculated Variable | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Poor Physical or Mental Health | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Poor Physical or Mental Health | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Poor Physical or Mental Health | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Preferred Child Race Categories | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Preferred Child Race Categories | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Preferred Child Race Categories | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Primary Sampling Unit | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Primary Sampling Unit | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Primary Sampling Unit | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Private Residence? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Private Residence? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Private Residence? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Questionnaire Version Identifier | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Questionnaire Version Identifier | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Questionnaire Version Identifier | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| _RACEG22 | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Raw weighting factor used in raking | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Raw weighting factor used in raking | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Raw weighting factor used in raking | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Received Tetanus Shot Since 2005? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Received Tetanus Shot Since 2005? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Received Tetanus Shot Since 2005? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Relationship to child | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Relationship to child | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Relationship to child | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Reported age in five-year age categories calculated variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Reported age in five-year age categories calculated variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Reported age in five-year age categories calculated variable | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Reported age in two age groups calculated variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Reported age in two age groups calculated variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Reported age in two age groups calculated variable | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Resident of State | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Resident of State | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Resident of State | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Respondents aged 18-64 with health insurance | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Respondents aged 18-64 with health insurance | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Respondents aged 18-64 with health insurance | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Respondents aged 45-75 who have fully met the USPSTF recommendations | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Respondents aged 45-75 who have fully met the USPSTF recommendations | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Respondents aged 45-75 who have fully met the USPSTF recommendations | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Respondents aged 45-75 who have had a colonoscopy within the past ten years | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Respondents aged 45-75 who have had a colonoscopy within the past ten years | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Respondents aged 45-75 who have had a colonoscopy within the past ten years | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Respondents aged 45-75 who have had a sigmoidoscopy within the past five years | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Respondents aged 45-75 who have had a sigmoidoscopy within the past five years | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Respondents aged 45-75 who have had a sigmoidoscopy within the past five years | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Respondents aged 45-75 who have had a sigmoidoscopy within the past ten years | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Respondents aged 45-75 who have had a sigmoidoscopy within the past ten years | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Respondents aged 45-75 who have had a sigmoidoscopy within the past ten years | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Respondents aged 45-75 who have had a stool DNA test within the past three years | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Respondents aged 45-75 who have had a stool DNA test within the past three years | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Respondents aged 45-75 who have had a stool DNA test within the past three years | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Respondents aged 45-75 who have had a stool test within the past year | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Respondents aged 45-75 who have had a stool test within the past year | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Respondents aged 45-75 who have had a stool test within the past year | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Respondents aged 45-75 who have had a virtual colonoscopy within the past five years | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Respondents aged 45-75 who have had a virtual colonoscopy within the past five years | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Respondents aged 45-75 who have had a virtual colonoscopy within the past five years | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Respondents diagnosed with arthritis | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Respondents diagnosed with arthritis | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Respondents diagnosed with arthritis | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Respondent selection | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Respondent selection | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Respondent selection | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Sample Design Stratification Variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Sample Design Stratification Variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Sample Design Stratification Variable | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Satisfaction with life | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Satisfaction with life | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Satisfaction with life | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| _SBONTI1 | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Sex of Respondent | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Sex of Respondent | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Sex of Respondent | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Smoked at Least 100 Cigarettes | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Smoked at Least 100 Cigarettes | `skos:closeMatch` | `https://loinc.org/72166-2` |
| Smoked at Least 100 Cigarettes | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Smoked at Least 100 Cigarettes | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Smoking Group | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Smoking Group | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Smoking Group | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Still Have Asthma | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Still Have Asthma | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Still Have Asthma | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Stratum weight | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Stratum weight | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Stratum weight | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Time since last cervical cancer screening test | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Time since last cervical cancer screening test | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Time since last cervical cancer screening test | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Time Since Last Sigmoidoscopy/Colonoscopy | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Time Since Last Sigmoidoscopy/Colonoscopy | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Time Since Last Sigmoidoscopy/Colonoscopy | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Told Had Arthritis | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Told Had Arthritis | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Told Had Arthritis | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Truncated design weight used in adult combined land line and cell phone raking | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Truncated design weight used in adult combined land line and cell phone raking | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Truncated design weight used in adult combined land line and cell phone raking | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Urban/Rural Status | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Urban/Rural Status | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Urban/Rural Status | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Use of Smokeless Tobacco Products | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Use of Smokeless Tobacco Products | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Use of Smokeless Tobacco Products | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Was test part of Cologuard test? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Was test part of Cologuard test? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Was test part of Cologuard test? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Were any CT or CAT scans done to check for lung cancer? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Were any CT or CAT scans done to check for lung cancer? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Were any CT or CAT scans done to check for lung cancer? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Were you not able to pay utility bills or threatened to lose service? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Were you not able to pay utility bills or threatened to lose service? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Were you not able to pay utility bills or threatened to lose service? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Were you not able to pay your bills? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Were you not able to pay your bills? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Were you not able to pay your bills? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| What is Primary Source of Health Insurance? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| What is Primary Source of Health Insurance? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| What is Primary Source of Health Insurance? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| When did you have your most recent CT or CAT scan? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| When did you have your most recent CT or CAT scan? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| When did you have your most recent CT or CAT scan? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| When did you receive your most recent seasonal flu shot/spray? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| When did you receive your most recent seasonal flu shot/spray? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| When did you receive your most recent seasonal flu shot/spray? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Which was the primary symptom that you experienced? | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Which was the primary symptom that you experienced? | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Which was the primary symptom that you experienced? | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Women respondents aged 40+ who have had a mammogram in the past two years | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Women respondents aged 40+ who have had a mammogram in the past two years | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Women respondents aged 40+ who have had a mammogram in the past two years | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Women respondents aged 50-74 that have had a mammogram in the past two years | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Women respondents aged 50-74 that have had a mammogram in the past two years | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Women respondents aged 50-74 that have had a mammogram in the past two years | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Taxable Income | `rdfs:isDefinedBy` | `https://schema.org/MonetaryAmount` |
| Taxable Income | `skos:broadMatch` | `http://qudt.org/vocab/quantitykind/Currency` |
| Taxable Income | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q786825` |
| BMI | `rdfs:isDefinedBy` | `https://uts.nlm.nih.gov/uts/umls/concept/C1305855` |
| BMI | `rdfs:isDefinedBy` | `https://www.nhlbi.nih.gov/calculate-your-bmi` |
| BMI | `rdf:type` | `https://schema.org/Number` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "BRFSS — Brfss" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-ffq1c2tkbzexmxqnrxg48oqj.xsd)
- Example instance (dm-ffq1c2tkbzexmxqnrxg48oqj.xml)
- HTML documentation (dm-ffq1c2tkbzexmxqnrxg48oqj.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"BRFSS — Brfss" SDC4 schema (dm-ffq1c2tkbzexmxqnrxg48oqj.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"BRFSS — Brfss" schema (dm-ffq1c2tkbzexmxqnrxg48oqj.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "BRFSS — Brfss" SDC4 schema (dm-ffq1c2tkbzexmxqnrxg48oqj.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "BRFSS — Brfss" data model (dm-ffq1c2tkbzexmxqnrxg48oqj.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-ffq1c2tkbzexmxqnrxg48oqj.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-ffq1c2tkbzexmxqnrxg48oqj.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-ffq1c2tkbzexmxqnrxg48oqj.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-ffq1c2tkbzexmxqnrxg48oqj.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-ffq1c2tkbzexmxqnrxg48oqj.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
