# CMS Beneficiary

**Model ID**: `dm-fnv3zi2btk3s0sfodjsc25eb`
**Project**: FAIR Data Demo
**Description**: SDC4 data model for CMS DE-SynPUF (Medicare Claims Synthetic Data) (cms_beneficiary) — FAIR Data Demo

### Dublin Core Metadata
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal

## Package Contents

- `dm-fnv3zi2btk3s0sfodjsc25eb.xsd` -- XML Schema Definition (data model structure)
- `dm-fnv3zi2btk3s0sfodjsc25eb.xml` -- XML instance example with sample data
- `dm-fnv3zi2btk3s0sfodjsc25eb-instance.json` -- JSON instance example (same structure as XML)
- `dm-fnv3zi2btk3s0sfodjsc25eb.jsonld` -- JSON-LD semantic schema description
- `dm-fnv3zi2btk3s0sfodjsc25eb.html` -- Human-readable model documentation
- `dm-fnv3zi2btk3s0sfodjsc25eb_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-fnv3zi2btk3s0sfodjsc25eb.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-fnv3zi2btk3s0sfodjsc25eb.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-fnv3zi2btk3s0sfodjsc25eb.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-fnv3zi2btk3s0sfodjsc25eb.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **CMS Beneficiary Governed Record** | Cluster | `io2h28pi3yktedurk8ye3oq0` | 0 components; 4 sub-cluster(s) |
|   **Audit Event** | Cluster | `t2tvd3wylxrstdeu5aw6gkw1` | 13 components |
|     Audit Agent Reference | XdString | `dkc2ccj5te35z9gd4bu1blcq` | maxLen=2000; pattern=`\S+` |
|     Audit Entity Reference | XdString | `gcjyjrnp0wsfoelcp4m05c67` | maxLen=2000; pattern=`\S+` |
|     Audit Event Identifier | XdString | `fjhgr5fyqxt2crmg2cb5c513` | maxLen=255 |
|     Data Subject Reference | XdString | `sndpbhm3xbd6qtbyxmvh3i0e` | maxLen=2000; pattern=`\S+` |
|     On Behalf Of Reference | XdString | `nf1air1zbj8v9w66jozdxmyl` | maxLen=2000; pattern=`\S+` |
|     System Identifier | XdString | `h3kdbvdtyalpvik97saaf0an` | maxLen=255 |
|     System Location Name | XdString | `ujir739mf1g8ajeczs9nzh9m` | maxLen=255 |
|     Audit Event Action | XdToken | `ce1c8sydkov8bkv4dgdmwe5x` | 5 enum(s) |
|     Audit Event Outcome | XdToken | `rpz1czz06jhpahmfz30rblvp` | 4 enum(s) |
|     Confidentiality | XdToken | `vbctgmdcwps5b3r3l6sboa6y` | 6 enum(s) |
|     Provenance Agent Type | XdToken | `jujsdur1igws8orw6tvvlqco` | 13 enum(s) |
|     Purpose of Use | XdToken | `d1evlz8yvdlwt6ia9fjq4pgj` | 11 enum(s) |
|     Audit Recorded At | XdTemporal | `uwiosm2q9ym3ewr4de910s70` | -- |
|   **CMS Beneficiary** | Cluster | `kkdy1kjdruxvx8s1ra8eh231` | 2 components; 4 sub-cluster(s) |
|     Beneficiary Code (DESYNPUF_ID) | XdString | `zshx6rx7ca1j00eda9kxyh6h` | maxLen=16; pattern=`[0-9A-F]{16}` |
|     End-Stage Renal Disease Indicator (BENE_ESRD_IND) | XdToken | `pczjiz8bjdg20api47gmeq0e` | 2 enum(s) |
|     **Chronic Condition Indicators** | Cluster | `wa0mknvfo83hej635n48s0ig` | 22 components |
|       Condition: Alzheimer's Disease or Related Disorder | XdToken | `d9z9mcx6gs9zbz4k6f0v738s` | 2 enum(s) |
|       Condition: Angina | XdToken | `o4d67oubyyunugx3la44f53u` | 2 enum(s) |
|       Condition: Arthritis | XdToken | `nd1v8jk7wtm1tthzw1f4987t` | 2 enum(s) |
|       Condition: Asthma | XdToken | `acr1xvqppf1b3rjsrst6tt4p` | 2 enum(s) |
|       Condition: Cancer | XdToken | `ix0my2v2z79s002g0r8orosf` | 2 enum(s) |
|       Condition: Chronic Bronchitis | XdToken | `jyx7rxfktazhgxgq84fxf6wr` | 2 enum(s) |
|       Condition: Congestive Heart Failure | XdToken | `hyqlz591lhj54sdt1a1mup70` | 2 enum(s) |
|       Condition: COPD | XdToken | `mijr18ynaqde2l8jps70l2g6` | 2 enum(s) |
|       Condition: Coronary Heart Disease | XdToken | `udbydjqj76l8kl6mi2s3v7vd` | 2 enum(s) |
|       Condition: Depression | XdToken | `of4crvmnrr3s5q5396kmt0jv` | 2 enum(s) |
|       Condition: Diabetes | XdToken | `fzpb9xr5jg2m3e3dzmvi1v3h` | 2 enum(s) |
|       Condition: Emphysema | XdToken | `sbulkq80j4fkbiql4zgje4qr` | 2 enum(s) |
|       Condition: Heart Attack | XdToken | `yshoeps2dm0j1ueusqs825v6` | 2 enum(s) |
|       Condition: High Blood Pressure | XdToken | `lvockfc8lce5p15wuwxc1kwa` | 2 enum(s) |
|       Condition: High Cholesterol | XdToken | `gp3jxw3xzs761ll6u5rvc6jr` | 2 enum(s) |
|       Condition Indicator Basis | XdToken | `hc79skkfionpgw87dsg5yrgw` | 2 enum(s) |
|       Condition: Kidney Disease | XdToken | `sw5rt0k2uap0e3xgl4rznfgu` | 2 enum(s) |
|       Condition: Liver Condition | XdToken | `atqkooccakulfhkt18c008fx` | 2 enum(s) |
|       Condition: Osteoporosis | XdToken | `l784ggegqcvrpnmw2yvo4il7` | 2 enum(s) |
|       Condition: Skin Cancer | XdToken | `xsohkckyof7y1xj8h1ab4pxu` | 2 enum(s) |
|       Condition: Stroke | XdToken | `zc6p008h5naqev8zngtzvyx9` | 2 enum(s) |
|       Condition: Thyroid Problem | XdToken | `p8u71b4lhct4ra0szgkex7xo` | 2 enum(s) |
|     **CMS Annual Amounts** | Cluster | `vas0n7gpt46lxe3t2klb0ihw` | 9 components |
|       Carrier Annual Beneficiary Responsibility | XdQuantity | `nr2ylxsejuy6awcwqts30rpv` | units=Currency |
|       Carrier Annual Medicare Reimbursement | XdQuantity | `uqamp46mdscugwy7z99jaxsp` | units=Currency |
|       Carrier Annual Primary Payer Reimbursement | XdQuantity | `qbla2qbmgnvijbzpvgsivygy` | units=Currency |
|       Inpatient Annual Beneficiary Responsibility | XdQuantity | `xk3apd6exhme1to143takg17` | units=Currency |
|       Inpatient Annual Medicare Reimbursement | XdQuantity | `ir7e2d7vwws6yisjvxgfm7ou` | units=Currency |
|       Inpatient Annual Primary Payer Reimbursement | XdQuantity | `afusetixnkfrt5zheumblskw` | units=Currency |
|       Outpatient Annual Beneficiary Responsibility | XdQuantity | `gxyr702hyrvi5bxp2rn9avd5` | units=Currency |
|       Outpatient Annual Medicare Reimbursement | XdQuantity | `hnvzazgaw60pz193376698lu` | units=Currency |
|       Outpatient Annual Primary Payer Reimbursement | XdQuantity | `wl1enu6oomssv6fn1kvvdx9f` | units=Currency |
|     **CMS Beneficiary Demographics** | Cluster | `frvayvpr4jkzykc8ykchaev6` | 9 components |
|       Deceased Indicator | XdBoolean | `fnr5q1tfq42ez9jia9dqueho` | -- |
|       County Code (BENE_COUNTY_CD) | XdString | `hb937iiq8di6mrtn10j8n1vk` | maxLen=3; pattern=`[0-9]{1,3}` |
|       State Code (SP_STATE_CODE) | XdString | `n8s2hvs4vrt5bwdykfzna5a6` | maxLen=2; pattern=`[0-9]{1,2}` |
|       Race (BENE_RACE_CD) | XdToken | `u5xln0mppl3qk6vhgxdu0wcn` | 4 enum(s) |
|       Sex (BENE_SEX_IDENT_CD) | XdToken | `u4lkrbqp88mvp1m81ipglaov` | 2 enum(s) |
|       Race/Ethnicity Self-Identification | XdToken | `u5tietya3u56hbz2kos06ai7` | 7 enum(s) |
|       Administrative Gender | XdToken | `gxzbm758mhdz51xd4bawlfhh` | 4 enum(s) |
|       Deceased Date | XdTemporal | `vnlhr9c3ykayyegumhb09snf` | -- |
|       Date of Birth | XdTemporal | `js564tazefb6udqlh12rj04l` | -- |
|     **CMS Medicare Coverage** | Cluster | `shug78mge6b16gz073rt23ih` | 4 components; 1 sub-cluster(s) |
|       HMO Coverage Months | XdCount | `v3kyd703i6kwzmmnasehyiks` | units=Months |
|       Hospital Insurance (Part A) Coverage Months | XdCount | `z7hdfvo8n55ebh3hqs2devzz` | units=Months |
|       Part D Plan Coverage Months | XdCount | `uzjspmfqya7qwbg2vhfdlgzv` | units=Months |
|       Supplementary Medical Insurance (Part B) Coverage Months | XdCount | `xftatfclhnwcyy2k96v7k638` | units=Months |
|       **Insurance Coverage** | Cluster | `hbnmrivnia0qrqidvtdryusj` | 10 components; 2 sub-cluster(s) |
|         Subrogation Indicator | XdBoolean | `zc3g4e4kjtzehn3kkffkeu29` | -- |
|         Dependent Sequence | XdString | `ngyypbb7lmlj2g3kibcjqjmn` | maxLen=16 |
|         Member ID | XdString | `of5kk46yrln1ok8nuajeg2f8` | maxLen=64 |
|         Plan Network | XdString | `ng1e2u43yhfura3vf0ahm609` | maxLen=255 |
|         Coverage Status | XdToken | `hicvzztm4xzxnzp9f6tyu016` | 4 enum(s) |
|         Coverage Type | XdToken | `wpnvu6f56drsy767ucx60scd` | 52 enum(s) |
|         Subscriber Relationship | XdToken | `zxoxt5fc40bzigieoh044gsy` | 7 enum(s) |
|         Coverage Order | XdCount | `rcl099nhkwzl6lu24lz9i01r` | units=Items |
|         Coverage Period End | XdTemporal | `asmfpl0h2pw2xlldhiydibbn` | -- |
|         Coverage Period Start | XdTemporal | `onaqlxn6vzh5r1ub5oxn65iv` | -- |
|         **Cost Sharing** | Cluster | `oc8phvc3wtcfr5x5aauliaih` | 2 components |
|           Copay Type | XdToken | `fdtpvqw0se658x5m3zormi5v` | 10 enum(s) |
|           Copay Amount | XdQuantity | `h4ngotmyyx8yflaxicrxaba8` | units=Currency |
|         **Coverage Class** | Cluster | `jqrxnqz7o48ay00s8y4ft7ju` | 3 components |
|           Coverage Class Name | XdString | `dro3p4hqu4ovk0uj7uu2upvq` | maxLen=255 |
|           Coverage Class Value | XdString | `zwmu2x9s8tx628rvb1trh0ij` | maxLen=64 |
|           Coverage Class Type | XdToken | `m3m7ow1e7b27ejx6usxtgnbg` | 11 enum(s) |
|   **PROV Activity** | Cluster | `vmikfu0irht9fmq7q02t3oqs` | 15 components |
|     Activity Description | XdString | `hhusuzzig19rs46ngz23k5g7` | maxLen=4000 |
|     Activity Identifier | XdString | `wr06h54xqqw2q9id8i9673jy` | maxLen=255 |
|     Activity Label | XdString | `r6hkunjm2q0hlxiknlc9ljix` | maxLen=255 |
|     Activity Location | XdString | `uzai5uey5p1fnn9ezj9u6vor` | maxLen=255 |
|     Activity Type | XdString | `jjzmhdxvbt97pq81iwqubtxk` | maxLen=255 |
|     Error Message | XdString | `xlgjqdpwdbn2re3mdh5yy2rk` | maxLen=4000 |
|     Had Plan Reference | XdString | `vhezo2cckpe92x4c3j2memeh` | maxLen=2000; pattern=`\S+` |
|     Used Entity Reference | XdString | `t0whhrqtnb54te4mk48i1ooj` | maxLen=2000; pattern=`\S+` |
|     Was Associated With Reference | XdString | `r48alj7hc3797qfjnf2uj71n` | maxLen=2000; pattern=`\S+` |
|     Was Ended By Reference | XdString | `ueb5g1ojzlwwt0mnds5zb6wl` | maxLen=2000; pattern=`\S+` |
|     Was Informed By Reference | XdString | `qh84jdzp1kxt85aq4ilo0svk` | maxLen=2000; pattern=`\S+` |
|     Was Started By Reference | XdString | `ginfqbk7q59ld2r4us8sjnv1` | maxLen=2000; pattern=`\S+` |
|     Activity Status | XdToken | `wl6j4ekcmu4hvt2m12zw4zp8` | 6 enum(s) |
|     Ended At | XdTemporal | `a5scyosu6j84vz350mqyrzl2` | -- |
|     Started At | XdTemporal | `sa4nl1kbpdr842fkucvfjkpq` | -- |
|   **PROV Agent** | Cluster | `c179ilk2ns15cd5rzzdfd6f6` | 9 components |
|     Acted On Behalf Of Reference | XdString | `og08xf6bu928uuz6t3y0e23f` | maxLen=2000; pattern=`\S+` |
|     Agent Description | XdString | `gb78cmuyo72hqs5apymdki7l` | maxLen=4000 |
|     Agent Email | XdString | `qb90a0sp9vvb6c5cbcf236ys` | maxLen=255 |
|     Agent Identifier | XdString | `w2ruemcfy35rw60jl1t9dew2` | maxLen=255 |
|     Agent Name | XdString | `xxe21o9ojzmy9wxxky1tnmog` | maxLen=255 |
|     Agent Organization Name | XdString | `eftvwi5byq6cdtd931qyxzw0` | maxLen=255 |
|     Software Name | XdString | `aa663ivutjf2fs4757t0bbzy` | maxLen=255 |
|     Software Version | XdString | `x0lebwtobgaelj5pev3258sd` | maxLen=60 |
|     PROV Agent Type | XdToken | `i16vqj89it3db7d3c5qjko9p` | 3 enum(s) |

## Structural Hierarchy

```
DM: CMS Beneficiary
  [Cluster] CMS Beneficiary Governed Record
    [Cluster] Audit Event
      [XdString] Audit Agent Reference
      [XdString] Audit Entity Reference
      [XdString] Audit Event Identifier
      [XdString] Data Subject Reference
      [XdString] On Behalf Of Reference
      [XdString] System Identifier
      [XdString] System Location Name
      [XdToken] Audit Event Action
      [XdToken] Audit Event Outcome
      [XdToken] Confidentiality
      [XdToken] Provenance Agent Type
      [XdToken] Purpose of Use
      [XdTemporal] Audit Recorded At
    [Cluster] CMS Beneficiary
      [XdString] Beneficiary Code (DESYNPUF_ID)
      [XdToken] End-Stage Renal Disease Indicator (BENE_ESRD_IND)
      [Cluster] Chronic Condition Indicators
        [XdToken] Condition: Alzheimer's Disease or Related Disorder
        [XdToken] Condition: Angina
        [XdToken] Condition: Arthritis
        [XdToken] Condition: Asthma
        [XdToken] Condition: Cancer
        [XdToken] Condition: Chronic Bronchitis
        [XdToken] Condition: Congestive Heart Failure
        [XdToken] Condition: COPD
        [XdToken] Condition: Coronary Heart Disease
        [XdToken] Condition: Depression
        [XdToken] Condition: Diabetes
        [XdToken] Condition: Emphysema
        [XdToken] Condition: Heart Attack
        [XdToken] Condition: High Blood Pressure
        [XdToken] Condition: High Cholesterol
        [XdToken] Condition Indicator Basis
        [XdToken] Condition: Kidney Disease
        [XdToken] Condition: Liver Condition
        [XdToken] Condition: Osteoporosis
        [XdToken] Condition: Skin Cancer
        [XdToken] Condition: Stroke
        [XdToken] Condition: Thyroid Problem
      [Cluster] CMS Annual Amounts
        [XdQuantity] Carrier Annual Beneficiary Responsibility
        [XdQuantity] Carrier Annual Medicare Reimbursement
        [XdQuantity] Carrier Annual Primary Payer Reimbursement
        [XdQuantity] Inpatient Annual Beneficiary Responsibility
        [XdQuantity] Inpatient Annual Medicare Reimbursement
        [XdQuantity] Inpatient Annual Primary Payer Reimbursement
        [XdQuantity] Outpatient Annual Beneficiary Responsibility
        [XdQuantity] Outpatient Annual Medicare Reimbursement
        [XdQuantity] Outpatient Annual Primary Payer Reimbursement
      [Cluster] CMS Beneficiary Demographics
        [XdBoolean] Deceased Indicator
        [XdString] County Code (BENE_COUNTY_CD)
        [XdString] State Code (SP_STATE_CODE)
        [XdToken] Race (BENE_RACE_CD)
        [XdToken] Sex (BENE_SEX_IDENT_CD)
        [XdToken] Race/Ethnicity Self-Identification
        [XdToken] Administrative Gender
        [XdTemporal] Deceased Date
        [XdTemporal] Date of Birth
      [Cluster] CMS Medicare Coverage
        [XdCount] HMO Coverage Months
        [XdCount] Hospital Insurance (Part A) Coverage Months
        [XdCount] Part D Plan Coverage Months
        [XdCount] Supplementary Medical Insurance (Part B) Coverage Months
        [Cluster] Insurance Coverage
          [XdBoolean] Subrogation Indicator
          [XdString] Dependent Sequence
          [XdString] Member ID
          [XdString] Plan Network
          [XdToken] Coverage Status
          [XdToken] Coverage Type
          [XdToken] Subscriber Relationship
          [XdCount] Coverage Order
          [XdTemporal] Coverage Period End
          [XdTemporal] Coverage Period Start
          [Cluster] Cost Sharing
            [XdToken] Copay Type
            [XdQuantity] Copay Amount
          [Cluster] Coverage Class
            [XdString] Coverage Class Name
            [XdString] Coverage Class Value
            [XdToken] Coverage Class Type
    [Cluster] PROV Activity
      [XdString] Activity Description
      [XdString] Activity Identifier
      [XdString] Activity Label
      [XdString] Activity Location
      [XdString] Activity Type
      [XdString] Error Message
      [XdString] Had Plan Reference
      [XdString] Used Entity Reference
      [XdString] Was Associated With Reference
      [XdString] Was Ended By Reference
      [XdString] Was Informed By Reference
      [XdString] Was Started By Reference
      [XdToken] Activity Status
      [XdTemporal] Ended At
      [XdTemporal] Started At
    [Cluster] PROV Agent
      [XdString] Acted On Behalf Of Reference
      [XdString] Agent Description
      [XdString] Agent Email
      [XdString] Agent Identifier
      [XdString] Agent Name
      [XdString] Agent Organization Name
      [XdString] Software Name
      [XdString] Software Version
      [XdToken] PROV Agent Type
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| CMS Beneficiary Governed Record | `dcterms:publisher` | `https://axius-sdc.com` |
| CMS Beneficiary Governed Record | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| CMS Beneficiary Governed Record | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-beneficiary-governed-record` |
| CMS Beneficiary Governed Record | `skos:exactMatch` | `http://www.w3.org/ns/prov#Entity` |
| Audit Event | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event` |
| Audit Event | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/AuditEvent` |
| Audit Agent Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Agent Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Agent Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-agent-reference` |
| Audit Agent Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.who` |
| Audit Agent Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bads7w1q6wmhn18u6dxwt28t` |
| Audit Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Entity Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-entity-reference` |
| Audit Entity Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.entity.what` |
| Audit Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-sjp1x177mlpq3howdltptm3c` |
| Audit Event Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-identifier` |
| Audit Event Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Data Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Data Subject Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Data Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/data-subject-reference` |
| Data Subject Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.patient` |
| Data Subject Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-x2rc9cg84d2famryqzdic0as` |
| On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| On Behalf Of Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/on-behalf-of-reference` |
| On Behalf Of Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/provenance-definitions.html#Provenance.agent.onBehalfOf` |
| On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-j9gvyx6u9pb7v1dd0m6joxd6` |
| System Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| System Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-identifier` |
| System Identifier | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.source.observer` |
| System Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-des67jo3ki9w0zgaz2i2t2cq` |
| System Location Name | `dcterms:publisher` | `https://axius-sdc.com` |
| System Location Name | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Location Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-location-name` |
| System Location Name | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.location` |
| System Location Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l6fwy1a2l5i43t308pknygp7` |
| Audit Event Action | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Action | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Action | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-action` |
| Audit Event Action | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-action` |
| Audit Event Action | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-o8lawuczf9vry55e98cjg12r` |
| Audit Event Outcome | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Outcome | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Outcome | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-outcome` |
| Audit Event Outcome | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-outcome` |
| Audit Event Outcome | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lgmleqp52a6kl268drrtfjk5` |
| Confidentiality | `dcterms:publisher` | `https://axius-sdc.com` |
| Confidentiality | `dcterms:source` | `http://terminology.hl7.org/` |
| Confidentiality | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/confidentiality` |
| Confidentiality | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-Confidentiality` |
| Confidentiality | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hp8q52t8tgmis92c4ljrfy7e` |
| Provenance Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Provenance Agent Type | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Provenance Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/provenance-agent-type` |
| Provenance Agent Type | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/provenance-participant-type` |
| Provenance Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-syt8l7pmb64eym2chcn43ai7` |
| Purpose of Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Purpose of Use | `dcterms:source` | `http://terminology.hl7.org/` |
| Purpose of Use | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/purpose-of-use` |
| Purpose of Use | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActReason` |
| Purpose of Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-y87ikto4p56zlkx4o2d63ain` |
| Audit Recorded At | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Recorded At | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Recorded At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-recorded-at` |
| Audit Recorded At | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.recorded` |
| CMS Beneficiary | `dcterms:publisher` | `https://axius-sdc.com` |
| CMS Beneficiary | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| CMS Beneficiary | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-beneficiary` |
| CMS Beneficiary | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C41189` |
| Beneficiary Code (DESYNPUF_ID) | `dcterms:publisher` | `https://axius-sdc.com` |
| Beneficiary Code (DESYNPUF_ID) | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Beneficiary Code (DESYNPUF_ID) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-beneficiary-code` |
| Beneficiary Code (DESYNPUF_ID) | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| End-Stage Renal Disease Indicator (BENE_ESRD_IND) | `dcterms:publisher` | `https://axius-sdc.com` |
| End-Stage Renal Disease Indicator (BENE_ESRD_IND) | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| End-Stage Renal Disease Indicator (BENE_ESRD_IND) | `dcterms:subject` | `http://snomed.info/id/46177005` |
| End-Stage Renal Disease Indicator (BENE_ESRD_IND) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-end-stage-renal-disease-indicator` |
| End-Stage Renal Disease Indicator (BENE_ESRD_IND) | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Chronic Condition Indicators | `dcterms:publisher` | `https://axius-sdc.com` |
| Chronic Condition Indicators | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Chronic Condition Indicators | `dcterms:identifier` | `https://axius-sdc.com/library/fair/chronic-condition-indicators` |
| Chronic Condition Indicators | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C2991` |
| Condition: Alzheimer's Disease or Related Disorder | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Alzheimer's Disease or Related Disorder | `dcterms:subject` | `http://snomed.info/id/26929004` |
| Condition: Alzheimer's Disease or Related Disorder | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Alzheimer's Disease or Related Disorder | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-alzheimers-disease` |
| Condition: Angina | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Angina | `dcterms:subject` | `http://snomed.info/id/194828000` |
| Condition: Angina | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Angina | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-angina` |
| Condition: Arthritis | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Arthritis | `dcterms:subject` | `http://snomed.info/id/3723001` |
| Condition: Arthritis | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Arthritis | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-arthritis` |
| Condition: Asthma | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Asthma | `dcterms:subject` | `http://snomed.info/id/195967001` |
| Condition: Asthma | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Asthma | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-asthma` |
| Condition: Cancer | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Cancer | `dcterms:subject` | `http://snomed.info/id/363346000` |
| Condition: Cancer | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Cancer | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-cancer` |
| Condition: Chronic Bronchitis | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Chronic Bronchitis | `dcterms:subject` | `http://snomed.info/id/63480004` |
| Condition: Chronic Bronchitis | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Chronic Bronchitis | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-chronic-bronchitis` |
| Condition: Congestive Heart Failure | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Congestive Heart Failure | `dcterms:subject` | `http://snomed.info/id/42343007` |
| Condition: Congestive Heart Failure | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Congestive Heart Failure | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-congestive-heart-failure` |
| Condition: COPD | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: COPD | `dcterms:subject` | `http://snomed.info/id/13645005` |
| Condition: COPD | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: COPD | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-copd` |
| Condition: Coronary Heart Disease | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Coronary Heart Disease | `dcterms:subject` | `http://snomed.info/id/53741008` |
| Condition: Coronary Heart Disease | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Coronary Heart Disease | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-coronary-heart-disease` |
| Condition: Depression | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Depression | `dcterms:subject` | `http://snomed.info/id/35489007` |
| Condition: Depression | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Depression | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-depression` |
| Condition: Diabetes | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Diabetes | `dcterms:subject` | `http://snomed.info/id/73211009` |
| Condition: Diabetes | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Diabetes | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-diabetes` |
| Condition: Emphysema | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Emphysema | `dcterms:subject` | `http://snomed.info/id/87433001` |
| Condition: Emphysema | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Emphysema | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-emphysema` |
| Condition: Heart Attack | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Heart Attack | `dcterms:subject` | `http://snomed.info/id/22298006` |
| Condition: Heart Attack | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Heart Attack | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-heart-attack` |
| Condition: High Blood Pressure | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: High Blood Pressure | `dcterms:subject` | `http://snomed.info/id/38341003` |
| Condition: High Blood Pressure | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: High Blood Pressure | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-high-blood-pressure` |
| Condition: High Cholesterol | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: High Cholesterol | `dcterms:subject` | `http://snomed.info/id/13644009` |
| Condition: High Cholesterol | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: High Cholesterol | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-high-cholesterol` |
| Condition Indicator Basis | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition Indicator Basis | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition Indicator Basis | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-indicator-basis` |
| Condition Indicator Basis | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C25596` |
| Condition: Kidney Disease | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Kidney Disease | `dcterms:subject` | `http://snomed.info/id/709044004` |
| Condition: Kidney Disease | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Kidney Disease | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-kidney-disease` |
| Condition: Liver Condition | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Liver Condition | `dcterms:subject` | `http://snomed.info/id/235856003` |
| Condition: Liver Condition | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Liver Condition | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-liver-condition` |
| Condition: Osteoporosis | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Osteoporosis | `dcterms:subject` | `http://snomed.info/id/64859006` |
| Condition: Osteoporosis | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Osteoporosis | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-osteoporosis` |
| Condition: Skin Cancer | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Skin Cancer | `dcterms:subject` | `http://snomed.info/id/372130007` |
| Condition: Skin Cancer | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Skin Cancer | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-skin-cancer` |
| Condition: Stroke | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Stroke | `dcterms:subject` | `http://snomed.info/id/230690007` |
| Condition: Stroke | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Stroke | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-stroke` |
| Condition: Thyroid Problem | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Thyroid Problem | `dcterms:subject` | `http://snomed.info/id/14304000` |
| Condition: Thyroid Problem | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Thyroid Problem | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-thyroid-problem` |
| CMS Annual Amounts | `dcterms:publisher` | `https://axius-sdc.com` |
| CMS Annual Amounts | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| CMS Annual Amounts | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-annual-amounts` |
| CMS Annual Amounts | `skos:exactMatch` | `https://schema.org/MonetaryAmount` |
| Carrier Annual Beneficiary Responsibility | `dcterms:publisher` | `https://axius-sdc.com` |
| Carrier Annual Beneficiary Responsibility | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Carrier Annual Beneficiary Responsibility | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-annual-carrier-beneficiary-responsibility` |
| Carrier Annual Beneficiary Responsibility | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Carrier Annual Beneficiary Responsibility | `skos:closeMatch` | `https://schema.org/MonetaryAmount` |
| Carrier Annual Medicare Reimbursement | `dcterms:publisher` | `https://axius-sdc.com` |
| Carrier Annual Medicare Reimbursement | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Carrier Annual Medicare Reimbursement | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-annual-carrier-medicare-reimbursement` |
| Carrier Annual Medicare Reimbursement | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Carrier Annual Medicare Reimbursement | `skos:closeMatch` | `https://schema.org/MonetaryAmount` |
| Carrier Annual Primary Payer Reimbursement | `dcterms:publisher` | `https://axius-sdc.com` |
| Carrier Annual Primary Payer Reimbursement | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Carrier Annual Primary Payer Reimbursement | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-annual-carrier-primary-payer-reimbursement` |
| Carrier Annual Primary Payer Reimbursement | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Carrier Annual Primary Payer Reimbursement | `skos:closeMatch` | `https://schema.org/MonetaryAmount` |
| Inpatient Annual Beneficiary Responsibility | `dcterms:publisher` | `https://axius-sdc.com` |
| Inpatient Annual Beneficiary Responsibility | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Inpatient Annual Beneficiary Responsibility | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-annual-inpatient-beneficiary-responsibility` |
| Inpatient Annual Beneficiary Responsibility | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Inpatient Annual Beneficiary Responsibility | `skos:closeMatch` | `https://schema.org/MonetaryAmount` |
| Inpatient Annual Medicare Reimbursement | `dcterms:publisher` | `https://axius-sdc.com` |
| Inpatient Annual Medicare Reimbursement | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Inpatient Annual Medicare Reimbursement | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-annual-inpatient-medicare-reimbursement` |
| Inpatient Annual Medicare Reimbursement | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Inpatient Annual Medicare Reimbursement | `skos:closeMatch` | `https://schema.org/MonetaryAmount` |
| Inpatient Annual Primary Payer Reimbursement | `dcterms:publisher` | `https://axius-sdc.com` |
| Inpatient Annual Primary Payer Reimbursement | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Inpatient Annual Primary Payer Reimbursement | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-annual-inpatient-primary-payer-reimbursement` |
| Inpatient Annual Primary Payer Reimbursement | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Inpatient Annual Primary Payer Reimbursement | `skos:closeMatch` | `https://schema.org/MonetaryAmount` |
| Outpatient Annual Beneficiary Responsibility | `dcterms:publisher` | `https://axius-sdc.com` |
| Outpatient Annual Beneficiary Responsibility | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Outpatient Annual Beneficiary Responsibility | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-annual-outpatient-beneficiary-responsibility` |
| Outpatient Annual Beneficiary Responsibility | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Outpatient Annual Beneficiary Responsibility | `skos:closeMatch` | `https://schema.org/MonetaryAmount` |
| Outpatient Annual Medicare Reimbursement | `dcterms:publisher` | `https://axius-sdc.com` |
| Outpatient Annual Medicare Reimbursement | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Outpatient Annual Medicare Reimbursement | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-annual-outpatient-medicare-reimbursement` |
| Outpatient Annual Medicare Reimbursement | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Outpatient Annual Medicare Reimbursement | `skos:closeMatch` | `https://schema.org/MonetaryAmount` |
| Outpatient Annual Primary Payer Reimbursement | `dcterms:publisher` | `https://axius-sdc.com` |
| Outpatient Annual Primary Payer Reimbursement | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Outpatient Annual Primary Payer Reimbursement | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-annual-outpatient-primary-payer-reimbursement` |
| Outpatient Annual Primary Payer Reimbursement | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Outpatient Annual Primary Payer Reimbursement | `skos:closeMatch` | `https://schema.org/MonetaryAmount` |
| CMS Beneficiary Demographics | `dcterms:publisher` | `https://axius-sdc.com` |
| CMS Beneficiary Demographics | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| CMS Beneficiary Demographics | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-beneficiary-demographics` |
| CMS Beneficiary Demographics | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C16495` |
| Deceased Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Deceased Indicator | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Deceased Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/deceased-indicator` |
| Deceased Indicator | `skos:exactMatch` | `http://hl7.org/fhir/R4/patient-definitions.html#Patient.deceasedBoolean` |
| Deceased Indicator | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dw20tfw9y0qzzwlyhp6d9koz` |
| County Code (BENE_COUNTY_CD) | `dcterms:publisher` | `https://axius-sdc.com` |
| County Code (BENE_COUNTY_CD) | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| County Code (BENE_COUNTY_CD) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-county-code` |
| County Code (BENE_COUNTY_CD) | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| State Code (SP_STATE_CODE) | `dcterms:publisher` | `https://axius-sdc.com` |
| State Code (SP_STATE_CODE) | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| State Code (SP_STATE_CODE) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-state-code` |
| State Code (SP_STATE_CODE) | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Race (BENE_RACE_CD) | `dcterms:publisher` | `https://axius-sdc.com` |
| Race (BENE_RACE_CD) | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Race (BENE_RACE_CD) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-race-code` |
| Race (BENE_RACE_CD) | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Sex (BENE_SEX_IDENT_CD) | `dcterms:publisher` | `https://axius-sdc.com` |
| Sex (BENE_SEX_IDENT_CD) | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Sex (BENE_SEX_IDENT_CD) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-sex-code` |
| Sex (BENE_SEX_IDENT_CD) | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Race/Ethnicity Self-Identification | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C16564` |
| Race/Ethnicity Self-Identification | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C74528` |
| Race/Ethnicity Self-Identification | `dcterms:source` | `https://cde.nlm.nih.gov/deView?tinyId=LakF0YkywC` |
| Race/Ethnicity Self-Identification | `dcterms:publisher` | `http://www.wikidata.org/entity/Q6973755` |
| Race/Ethnicity Self-Identification | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C17049` |
| Race/Ethnicity Self-Identification | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hmc3dce8i1muhh9nr5bkbj92` |
| Administrative Gender | `dcterms:publisher` | `https://axius-sdc.com` |
| Administrative Gender | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Administrative Gender | `dcterms:identifier` | `https://axius-sdc.com/library/default/administrative-gender` |
| Administrative Gender | `skos:exactMatch` | `http://hl7.org/fhir/administrative-gender` |
| Administrative Gender | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tnyh2ude3db9smwfin0vai5h` |
| Deceased Date | `dcterms:publisher` | `https://axius-sdc.com` |
| Deceased Date | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Deceased Date | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/deceased-date` |
| Deceased Date | `skos:exactMatch` | `http://hl7.org/fhir/R4/patient-definitions.html#Patient.deceasedDateTime` |
| Deceased Date | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rqpcsr1pv41osf7sxwlr7lix` |
| Date of Birth | `dcterms:publisher` | `https://axius-sdc.com` |
| Date of Birth | `dcterms:identifier` | `https://axius-sdc.com/library/default/date-of-birth` |
| Date of Birth | `dcterms:source` | `https://schema.org/` |
| Date of Birth | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C68615` |
| Date of Birth | `skos:exactMatch` | `https://schema.org/birthDate` |
| CMS Medicare Coverage | `dcterms:publisher` | `https://axius-sdc.com` |
| CMS Medicare Coverage | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| CMS Medicare Coverage | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-medicare-coverage` |
| CMS Medicare Coverage | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/Coverage` |
| HMO Coverage Months | `dcterms:publisher` | `https://axius-sdc.com` |
| HMO Coverage Months | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HMO Coverage Months | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-hmo-coverage-months` |
| HMO Coverage Months | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Hospital Insurance (Part A) Coverage Months | `dcterms:publisher` | `https://axius-sdc.com` |
| Hospital Insurance (Part A) Coverage Months | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Hospital Insurance (Part A) Coverage Months | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-part-a-coverage-months` |
| Hospital Insurance (Part A) Coverage Months | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Part D Plan Coverage Months | `dcterms:publisher` | `https://axius-sdc.com` |
| Part D Plan Coverage Months | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Part D Plan Coverage Months | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-part-d-coverage-months` |
| Part D Plan Coverage Months | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Supplementary Medical Insurance (Part B) Coverage Months | `dcterms:publisher` | `https://axius-sdc.com` |
| Supplementary Medical Insurance (Part B) Coverage Months | `dcterms:source` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Supplementary Medical Insurance (Part B) Coverage Months | `dcterms:identifier` | `https://axius-sdc.com/library/fair/cms-part-b-coverage-months` |
| Supplementary Medical Insurance (Part B) Coverage Months | `rdfs:seeAlso` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Insurance Coverage | `dcterms:publisher` | `https://axius-sdc.com` |
| Insurance Coverage | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Insurance Coverage | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/insurance-coverage` |
| Insurance Coverage | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/Coverage` |
| Insurance Coverage | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rrieq6eqf7zakso7kw55wfoi` |
| Subrogation Indicator | `dcterms:publisher` | `https://axius-sdc.com` |
| Subrogation Indicator | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Subrogation Indicator | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/subrogation-indicator` |
| Subrogation Indicator | `skos:exactMatch` | `http://hl7.org/fhir/R4/coverage-definitions.html#Coverage.subrogation` |
| Subrogation Indicator | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-y1nox8retusmnhen28x87owb` |
| Dependent Sequence | `dcterms:publisher` | `https://axius-sdc.com` |
| Dependent Sequence | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Dependent Sequence | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/dependent-sequence` |
| Dependent Sequence | `skos:exactMatch` | `http://hl7.org/fhir/R4/coverage-definitions.html#Coverage.dependent` |
| Dependent Sequence | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-q43cuwriiuhzqgul1d8av9ez` |
| Member ID | `dcterms:publisher` | `https://axius-sdc.com` |
| Member ID | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Member ID | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/member-id` |
| Member ID | `skos:exactMatch` | `http://hl7.org/fhir/R4/coverage-definitions.html#Coverage.subscriberId` |
| Member ID | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-anzcptbbjd641d1lbainrp3q` |
| Plan Network | `dcterms:publisher` | `https://axius-sdc.com` |
| Plan Network | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Plan Network | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/plan-network` |
| Plan Network | `skos:exactMatch` | `http://hl7.org/fhir/R4/coverage-definitions.html#Coverage.network` |
| Plan Network | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kc5dn4tz1em2pu4vmktfk37l` |
| Coverage Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Coverage Status | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Coverage Status | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/coverage-status` |
| Coverage Status | `skos:closeMatch` | `http://hl7.org/fhir/R4/coverage-definitions.html#Coverage.status` |
| Coverage Status | `skos:exactMatch` | `http://hl7.org/fhir/fm-status` |
| Coverage Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-clz7nbfsxok0sd7bsb5sbqmm` |
| Coverage Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Coverage Type | `dcterms:source` | `http://terminology.hl7.org/` |
| Coverage Type | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/coverage-type` |
| Coverage Type | `skos:closeMatch` | `http://hl7.org/fhir/R4/coverage-definitions.html#Coverage.type` |
| Coverage Type | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActCode` |
| Coverage Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-j4otsvy3knfqm8bchyftbpvc` |
| Subscriber Relationship | `dcterms:publisher` | `https://axius-sdc.com` |
| Subscriber Relationship | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Subscriber Relationship | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/subscriber-relationship` |
| Subscriber Relationship | `skos:closeMatch` | `http://hl7.org/fhir/R4/coverage-definitions.html#Coverage.relationship` |
| Subscriber Relationship | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/subscriber-relationship` |
| Subscriber Relationship | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-mq99s6z0n14sc9gt8ouf6ar0` |
| Coverage Order | `dcterms:publisher` | `https://axius-sdc.com` |
| Coverage Order | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Coverage Order | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/coverage-order` |
| Coverage Order | `skos:exactMatch` | `http://hl7.org/fhir/R4/coverage-definitions.html#Coverage.order` |
| Coverage Order | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lhhm09e0u1asjl6yuarn0i6b` |
| Coverage Period End | `dcterms:publisher` | `https://axius-sdc.com` |
| Coverage Period End | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Coverage Period End | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/coverage-period-end` |
| Coverage Period End | `skos:exactMatch` | `http://hl7.org/fhir/R4/coverage-definitions.html#Coverage.period.end` |
| Coverage Period End | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-mkc3jd1tl6863y2lvde7x8s6` |
| Coverage Period Start | `dcterms:publisher` | `https://axius-sdc.com` |
| Coverage Period Start | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Coverage Period Start | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/coverage-period-start` |
| Coverage Period Start | `skos:exactMatch` | `http://hl7.org/fhir/R4/coverage-definitions.html#Coverage.period.start` |
| Coverage Period Start | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-nwi9cgajaafeu2ucxo2oxm3g` |
| Cost Sharing | `dcterms:publisher` | `https://axius-sdc.com` |
| Cost Sharing | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Cost Sharing | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/cost-sharing` |
| Cost Sharing | `skos:exactMatch` | `http://hl7.org/fhir/R4/coverage-definitions.html#Coverage.costToBeneficiary` |
| Cost Sharing | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-p0forxwcjbev3pug7emnye9i` |
| Copay Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Copay Type | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Copay Type | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/copay-type` |
| Copay Type | `skos:closeMatch` | `http://hl7.org/fhir/R4/coverage-definitions.html#Coverage.costToBeneficiary.type` |
| Copay Type | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/coverage-copay-type` |
| Copay Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-wmm71yrcg8yxepq3d57h75oo` |
| Copay Amount | `dcterms:publisher` | `https://axius-sdc.com` |
| Copay Amount | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Copay Amount | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/copay-amount` |
| Copay Amount | `skos:exactMatch` | `http://hl7.org/fhir/R4/coverage-definitions.html#Coverage.costToBeneficiary.value_x_` |
| Copay Amount | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tx7y1x6g5riscegp98y4jg1r` |
| Coverage Class | `dcterms:publisher` | `https://axius-sdc.com` |
| Coverage Class | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Coverage Class | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/coverage-class` |
| Coverage Class | `skos:exactMatch` | `http://hl7.org/fhir/R4/coverage-definitions.html#Coverage.class` |
| Coverage Class | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-sfxqqi30iz71da17vxfzyh3g` |
| Coverage Class Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Coverage Class Name | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Coverage Class Name | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/coverage-class-name` |
| Coverage Class Name | `skos:exactMatch` | `http://hl7.org/fhir/R4/coverage-definitions.html#Coverage.class.name` |
| Coverage Class Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ox1v16fjy8sn3n600ajp93gk` |
| Coverage Class Value | `dcterms:publisher` | `https://axius-sdc.com` |
| Coverage Class Value | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Coverage Class Value | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/coverage-class-value` |
| Coverage Class Value | `skos:exactMatch` | `http://hl7.org/fhir/R4/coverage-definitions.html#Coverage.class.value` |
| Coverage Class Value | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-vp10ylrirmj2x89mweq2o0c7` |
| Coverage Class Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Coverage Class Type | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Coverage Class Type | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/coverage-class-type` |
| Coverage Class Type | `skos:closeMatch` | `http://hl7.org/fhir/R4/coverage-definitions.html#Coverage.class.type` |
| Coverage Class Type | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/coverage-class` |
| Coverage Class Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-pdap69ljyikykrugqdyckf6o` |
| PROV Activity | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Activity | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-activity` |
| PROV Activity | `skos:exactMatch` | `http://www.w3.org/ns/prov#Activity` |
| PROV Activity | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-description` |
| Activity Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Activity Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-m9xg6e182m1oq77ssrf9iujv` |
| Activity Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-identifier` |
| Activity Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Activity Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fpnn1dew0kcevc8ptohndc5t` |
| Activity Label | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Label | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-label` |
| Activity Label | `skos:exactMatch` | `http://www.w3.org/2000/01/rdf-schema#label` |
| Activity Label | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Label | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-n4kaez29vbknku2jy8n56gfm` |
| Activity Location | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Location | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-location` |
| Activity Location | `skos:exactMatch` | `http://www.w3.org/ns/prov#atLocation` |
| Activity Location | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Location | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ciuklf1kl8bphpudye4i47am` |
| Activity Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-type` |
| Activity Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#type` |
| Activity Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ceusvbe55b266gcdzf5qnurc` |
| Error Message | `dcterms:publisher` | `https://axius-sdc.com` |
| Error Message | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/error-message` |
| Error Message | `dcterms:source` | `https://schema.org/` |
| Error Message | `skos:exactMatch` | `https://schema.org/error` |
| Error Message | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-eakhqr9l9nbblppgxc5fq25n` |
| Had Plan Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Had Plan Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/had-plan-reference` |
| Had Plan Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#hadPlan` |
| Had Plan Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Had Plan Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-xvdfh1nzfar33yxmgl3jgvqo` |
| Used Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Used Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/used-entity-reference` |
| Used Entity Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#used` |
| Used Entity Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Used Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ixv0fa8xlde52mdeymr4zaka` |
| Was Associated With Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Associated With Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-associated-with-reference` |
| Was Associated With Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasAssociatedWith` |
| Was Associated With Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Associated With Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gs0e1hp2rpjl6qfg9v8d047f` |
| Was Ended By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Ended By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-ended-by-reference` |
| Was Ended By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasEndedBy` |
| Was Ended By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Ended By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-jr1e3n5kg31nqz1ynh28kitp` |
| Was Informed By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Informed By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-informed-by-reference` |
| Was Informed By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasInformedBy` |
| Was Informed By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Informed By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rz60y6aujd274j4i7jpyxvpr` |
| Was Started By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Started By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-started-by-reference` |
| Was Started By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasStartedBy` |
| Was Started By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Started By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kmodjk1e5xu9z94zgiaxx1hu` |
| Activity Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Status | `dcterms:source` | `https://w3id.org/dpv` |
| Activity Status | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-status` |
| Activity Status | `skos:closeMatch` | `https://w3id.org/dpv#ActivityStatus` |
| Activity Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yehcpzf43j0b5zp9ck59t9eg` |
| Ended At | `dcterms:publisher` | `https://axius-sdc.com` |
| Ended At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/ended-at-time` |
| Ended At | `skos:exactMatch` | `http://www.w3.org/ns/prov#endedAtTime` |
| Ended At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Started At | `dcterms:publisher` | `https://axius-sdc.com` |
| Started At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/started-at-time` |
| Started At | `skos:exactMatch` | `http://www.w3.org/ns/prov#startedAtTime` |
| Started At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent` |
| PROV Agent | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Acted On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/acted-on-behalf-of-reference` |
| Acted On Behalf Of Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#actedOnBehalfOf` |
| Acted On Behalf Of Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dce4w62jxjngjnmc5y26fq66` |
| Agent Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-description` |
| Agent Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Agent Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w79xppnskig5vq31er8gh7nk` |
| Agent Email | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Email | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-email` |
| Agent Email | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/mbox` |
| Agent Email | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Email | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yp6pm5xyovxhkjimrrb8h9xy` |
| Agent Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-identifier` |
| Agent Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Agent Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hhfnj5hd1yzt252jfq5pdjj1` |
| Agent Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-name` |
| Agent Name | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/name` |
| Agent Name | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yya0pdgjd2w0wlz5r3h516om` |
| Agent Organization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Organization Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-organization-name` |
| Agent Organization Name | `dcterms:source` | `https://schema.org/` |
| Agent Organization Name | `skos:exactMatch` | `https://schema.org/legalName` |
| Agent Organization Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ifw5zfe4oiijbxjn1ylc2wm3` |
| Software Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-name` |
| Software Name | `dcterms:source` | `https://schema.org/` |
| Software Name | `skos:exactMatch` | `https://schema.org/SoftwareApplication` |
| Software Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rsjfjz8m5z7a58h5793duqbs` |
| Software Version | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Version | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-version` |
| Software Version | `dcterms:source` | `https://schema.org/` |
| Software Version | `skos:exactMatch` | `https://schema.org/softwareVersion` |
| Software Version | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tep9wanrrtqfw0k76huv6tvd` |
| PROV Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent-type` |
| PROV Agent Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-nesxtz8c5o665swc9lhvqkjj` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "CMS Beneficiary" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-fnv3zi2btk3s0sfodjsc25eb.xsd)
- Example instance (dm-fnv3zi2btk3s0sfodjsc25eb.xml)
- HTML documentation (dm-fnv3zi2btk3s0sfodjsc25eb.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"CMS Beneficiary" SDC4 schema (dm-fnv3zi2btk3s0sfodjsc25eb.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"CMS Beneficiary" schema (dm-fnv3zi2btk3s0sfodjsc25eb.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "CMS Beneficiary" SDC4 schema (dm-fnv3zi2btk3s0sfodjsc25eb.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "CMS Beneficiary" data model (dm-fnv3zi2btk3s0sfodjsc25eb.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-fnv3zi2btk3s0sfodjsc25eb.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-fnv3zi2btk3s0sfodjsc25eb.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-fnv3zi2btk3s0sfodjsc25eb.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-fnv3zi2btk3s0sfodjsc25eb.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-fnv3zi2btk3s0sfodjsc25eb.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
