# CMS — Prescriptions

**Model ID**: `dm-dg6lyhgvz9wd9cuqxqdc5g4p`
**Project**: FAIR Data Demo
**Description**: SDC4 data model for CMS DE-SynPUF (Medicare Claims Synthetic Data) (cms_prescriptions) — FAIR Data Demo

### Dublin Core Metadata
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal

## Package Contents

- `dm-dg6lyhgvz9wd9cuqxqdc5g4p.xsd` -- XML Schema Definition (data model structure)
- `dm-dg6lyhgvz9wd9cuqxqdc5g4p.xml` -- XML instance example with sample data
- `dm-dg6lyhgvz9wd9cuqxqdc5g4p-instance.json` -- JSON instance example (same structure as XML)
- `dm-dg6lyhgvz9wd9cuqxqdc5g4p.jsonld` -- JSON-LD semantic schema description
- `dm-dg6lyhgvz9wd9cuqxqdc5g4p.html` -- Human-readable model documentation
- `dm-dg6lyhgvz9wd9cuqxqdc5g4p_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-dg6lyhgvz9wd9cuqxqdc5g4p.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-dg6lyhgvz9wd9cuqxqdc5g4p.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-dg6lyhgvz9wd9cuqxqdc5g4p.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-dg6lyhgvz9wd9cuqxqdc5g4p.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **cms-prescriptions** | Cluster | `u7g1sa81glmh8ce7tqw6c54m` | 8 components |
|   Beneficiary Code | XdString | `qeqb0siehg15s5megtj1rbk8` | minLen=1; maxLen=50 |
|   Days Supply | XdCount | `hb8t4dz0i2rtey2xdl6i1yaz` | units=DAYS_SUPLY_NUM_units |
|   Prescription Drug Event ID | XdCount | `fgnbk11h2vzwomg4txfocqhk` | units=PDE_ID_units |
|   Product/Service ID (NDC) | XdCount | `wt04kmf82aqpi3hkxigzpilh` | units=PROD_SRVC_ID_units |
|   Service Date | XdCount | `lbczhz56pdloeylt99l3h5nv` | units=SRVC_DT_units |
|   Patient Payment Amount | XdQuantity | `c4sic57q44hgzdqcdlpqn8im` | units=PTNT_PAY_AMT_units |
|   Quantity Dispensed | XdQuantity | `h4hkyyiheeykkxzw5ky8ztfi` | units=QTY_DSPNSD_NUM_units |
|   Total Prescription Cost | XdQuantity | `epdophh67jdmmj9nfstmts73` | units=TOT_RX_CST_AMT_units |

## Structural Hierarchy

```
DM: CMS — Prescriptions
  [Cluster] cms-prescriptions
    [XdString] Beneficiary Code
    [XdCount] Days Supply
    [XdCount] Prescription Drug Event ID
    [XdCount] Product/Service ID (NDC)
    [XdCount] Service Date
    [XdQuantity] Patient Payment Amount
    [XdQuantity] Quantity Dispensed
    [XdQuantity] Total Prescription Cost
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| cms-prescriptions | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q5060058` |
| Beneficiary Code | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Beneficiary Code | `rdfs:isDefinedBy` | `https://w3id.org/semanticarts/ns/ontology/gist/ID` |
| Beneficiary Code | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Days Supply | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Days Supply | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q50114587` |
| Days Supply | `dcterms:subject` | `http://snomed.info/id/182832007` |
| Prescription Drug Event ID | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Prescription Drug Event ID | `rdfs:isDefinedBy` | `https://w3id.org/semanticarts/ns/ontology/gist/ID` |
| Prescription Drug Event ID | `dcterms:subject` | `http://snomed.info/id/182832007` |
| Product/Service ID (NDC) | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Product/Service ID (NDC) | `rdfs:isDefinedBy` | `https://w3id.org/semanticarts/ns/ontology/gist/ID` |
| Product/Service ID (NDC) | `dcterms:subject` | `http://snomed.info/id/182832007` |
| Service Date | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Service Date | `dcterms:subject` | `http://snomed.info/id/182832007` |
| Service Date | `rdfs:isDefinedBy` | `sdc4:XdCountType/xdcount-value` |
| Patient Payment Amount | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Patient Payment Amount | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q40490263` |
| Patient Payment Amount | `dcterms:subject` | `http://snomed.info/id/182832007` |
| Quantity Dispensed | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Quantity Dispensed | `dcterms:subject` | `http://snomed.info/id/182832007` |
| Quantity Dispensed | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Total Prescription Cost | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Total Prescription Cost | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q73481056` |
| Total Prescription Cost | `dcterms:subject` | `http://snomed.info/id/182832007` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "CMS — Prescriptions" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-dg6lyhgvz9wd9cuqxqdc5g4p.xsd)
- Example instance (dm-dg6lyhgvz9wd9cuqxqdc5g4p.xml)
- HTML documentation (dm-dg6lyhgvz9wd9cuqxqdc5g4p.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"CMS — Prescriptions" SDC4 schema (dm-dg6lyhgvz9wd9cuqxqdc5g4p.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"CMS — Prescriptions" schema (dm-dg6lyhgvz9wd9cuqxqdc5g4p.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "CMS — Prescriptions" SDC4 schema (dm-dg6lyhgvz9wd9cuqxqdc5g4p.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "CMS — Prescriptions" data model (dm-dg6lyhgvz9wd9cuqxqdc5g4p.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-dg6lyhgvz9wd9cuqxqdc5g4p.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-dg6lyhgvz9wd9cuqxqdc5g4p.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-dg6lyhgvz9wd9cuqxqdc5g4p.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-dg6lyhgvz9wd9cuqxqdc5g4p.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-dg6lyhgvz9wd9cuqxqdc5g4p.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
