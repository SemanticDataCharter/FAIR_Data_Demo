"""
Django app configuration for cms_—_inpatient.
"""
from django.apps import AppConfig


class Cms_—_inpatientConfig(AppConfig):
    """App configuration for cms_—_inpatient."""

    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cms_—_inpatient'

    def ready(self):
        """
        Import signals when app is ready.

        This ensures that signal handlers are registered when Django starts.
        """
        import cms_—_inpatient.signals  # noqa: F401
