"""
Django app configuration for cms_—_outpatient.
"""
from django.apps import AppConfig


class Cms_—_outpatientConfig(AppConfig):
    """App configuration for cms_—_outpatient."""

    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cms_—_outpatient'

    def ready(self):
        """
        Import signals when app is ready.

        This ensures that signal handlers are registered when Django starts.
        """
        import cms_—_outpatient.signals  # noqa: F401
