"""
Django app configuration for cms_—_beneficiary.
"""
from django.apps import AppConfig


class Cms_—_beneficiaryConfig(AppConfig):
    """App configuration for cms_—_beneficiary."""

    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cms_—_beneficiary'

    def ready(self):
        """
        Import signals when app is ready.

        This ensures that signal handlers are registered when Django starts.
        """
        import cms_—_beneficiary.signals  # noqa: F401
