# NHANES — Cholesterol

**Model ID**: `dm-s70cbgpe2gqfmpund4vvwyi5`
**Project**: FAIR Data Demo
**Description**: SDC4 data model for National Health and Nutrition Examination Survey (nhanes_cholesterol) — FAIR Data Demo

### Dublin Core Metadata
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal

## Package Contents

- `dm-s70cbgpe2gqfmpund4vvwyi5.xsd` -- XML Schema Definition (data model structure)
- `dm-s70cbgpe2gqfmpund4vvwyi5.xml` -- XML instance example with sample data
- `dm-s70cbgpe2gqfmpund4vvwyi5-instance.json` -- JSON instance example (same structure as XML)
- `dm-s70cbgpe2gqfmpund4vvwyi5.jsonld` -- JSON-LD semantic schema description
- `dm-s70cbgpe2gqfmpund4vvwyi5.html` -- Human-readable model documentation
- `dm-s70cbgpe2gqfmpund4vvwyi5_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-s70cbgpe2gqfmpund4vvwyi5.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-s70cbgpe2gqfmpund4vvwyi5.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-s70cbgpe2gqfmpund4vvwyi5.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-s70cbgpe2gqfmpund4vvwyi5.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **nhanes-cholesterol** | Cluster | `h32euhudcpt0wr4qdvugoke0` | 3 components |
|   Dependent Sequence Number | XdString | `bxpnk5cd59ghc0xw2aswgjze` | maxLen=9 |
|   Total Cholesterol (mg/dL) | XdQuantity | `a8y763jfyz6aornu8rho66m8` | units=LBXTC_units |
|   Total Cholesterol (mmol/L) | XdQuantity | `xzvtlbk1plfbhcyfo5oi5oon` | units=LBDTCSI_units |

## Structural Hierarchy

```
DM: NHANES — Cholesterol
  [Cluster] nhanes-cholesterol
    [XdString] Dependent Sequence Number
    [XdQuantity] Total Cholesterol (mg/dL)
    [XdQuantity] Total Cholesterol (mmol/L)
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| nhanes-cholesterol | `rdfs:isDefinedBy` | `http://semanticscience.org/resource/SIO_001382` |
| Dependent Sequence Number | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q29635268` |
| Dependent Sequence Number | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q1061489` |
| Total Cholesterol (mg/dL) | `skos:exactMatch` | `https://loinc.org/2093-3` |
| Total Cholesterol (mg/dL) | `rdfs:isDefinedBy` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Total Cholesterol (mg/dL) | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q2964389` |
| Total Cholesterol (mg/dL) | `skos:closeMatch` | `http://snomed.info/id/77068002` |
| Total Cholesterol (mg/dL) | `dcterms:subject` | `http://snomed.info/id/77068002` |
| Total Cholesterol (mmol/L) | `skos:exactMatch` | `https://loinc.org/2093-3` |
| Total Cholesterol (mmol/L) | `rdfs:isDefinedBy` | `https://wwwn.cdc.gov/nchs/nhanes/continuousnhanes/default.aspx?BeginYear=2017` |
| Total Cholesterol (mmol/L) | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q2964389` |
| Total Cholesterol (mmol/L) | `dcterms:subject` | `http://snomed.info/id/77068002` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "NHANES — Cholesterol" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-s70cbgpe2gqfmpund4vvwyi5.xsd)
- Example instance (dm-s70cbgpe2gqfmpund4vvwyi5.xml)
- HTML documentation (dm-s70cbgpe2gqfmpund4vvwyi5.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"NHANES — Cholesterol" SDC4 schema (dm-s70cbgpe2gqfmpund4vvwyi5.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"NHANES — Cholesterol" schema (dm-s70cbgpe2gqfmpund4vvwyi5.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "NHANES — Cholesterol" SDC4 schema (dm-s70cbgpe2gqfmpund4vvwyi5.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "NHANES — Cholesterol" data model (dm-s70cbgpe2gqfmpund4vvwyi5.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-s70cbgpe2gqfmpund4vvwyi5.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-s70cbgpe2gqfmpund4vvwyi5.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-s70cbgpe2gqfmpund4vvwyi5.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-s70cbgpe2gqfmpund4vvwyi5.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-s70cbgpe2gqfmpund4vvwyi5.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
