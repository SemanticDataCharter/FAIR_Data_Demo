# CMS — Beneficiary

**Model ID**: `dm-q9xk7y13y2115tr4sn2c7m39`
**Project**: FAIR Data Demo
**Description**: SDC4 data model for CMS DE-SynPUF (Medicare Claims Synthetic Data) (cms_beneficiary) — FAIR Data Demo

### Dublin Core Metadata
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal

## Package Contents

- `dm-q9xk7y13y2115tr4sn2c7m39.xsd` -- XML Schema Definition (data model structure)
- `dm-q9xk7y13y2115tr4sn2c7m39.xml` -- XML instance example with sample data
- `dm-q9xk7y13y2115tr4sn2c7m39-instance.json` -- JSON instance example (same structure as XML)
- `dm-q9xk7y13y2115tr4sn2c7m39.jsonld` -- JSON-LD semantic schema description
- `dm-q9xk7y13y2115tr4sn2c7m39.html` -- Human-readable model documentation
- `dm-q9xk7y13y2115tr4sn2c7m39_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-q9xk7y13y2115tr4sn2c7m39.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-q9xk7y13y2115tr4sn2c7m39.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-q9xk7y13y2115tr4sn2c7m39.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-q9xk7y13y2115tr4sn2c7m39.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **cms-beneficiary** | Cluster | `usgwubwsmi76ieeqapkp2ss1` | 30 components |
|   End-Stage Renal Disease Indicator | XdBoolean | `ujt1bpn5kgcrp58y6504jwq9` | -- |
|   Beneficiary Code | XdString | `qeqb0siehg15s5megtj1rbk8` | minLen=1; maxLen=50 |
|   Alzheimer's Disease or Related Disorders | XdCount | `n2y95s2rl2qjtkku0zqujz7j` | units=SP_ALZHDMTA_units |
|   Calculated sex variable | XdCount | `vpib1sfkuwg0505mvqh203wh` | units=BENE_SEX_IDENT_CD_units |
|   Cancer | XdCount | `p8x4hzlolz09c9dcplx2ibdj` | units=SP_CNCR_units |
|   Chronic Kidney Disease | XdCount | `udy2zvfqk7npu3k8kcta3y8h` | units=SP_CHRNKIDN_units |
|   Chronic Obstructive Pulmonary Disease | XdCount | `zdk007gxpq8vkefmcbiqnbud` | units=SP_COPD_units |
|   Congestive Heart Failure | XdCount | `ja0do2y6ffla0zw3gwzwax73` | units=SP_CHF_units |
|   County Code | XdCount | `yobh8qjv9c8a9jkjumvy137j` | units=BENE_COUNTY_CD_units |
|   Depression | XdCount | `ir43mp3ngcs4h3ekbeo4e4ka` | units=SP_DEPRESSN_units |
|   HMO Coverage Months | XdCount | `caxtzljmvwbomsoouwocszl6` | units=BENE_HMO_CVRAGE_TOT_MONS_units |
|   Hospital Insurance Coverage Months | XdCount | `g25z8erbr3oxyhbp1pfx9qsa` | units=BENE_HI_CVRAGE_TOT_MONS_units |
|   Ischemic Heart Disease | XdCount | `c00tkbqt91njoavo6gfkxfzy` | units=SP_ISCHMCHT_units |
|   Osteoporosis | XdCount | `alx9i6qtut67hq3o7o6funhu` | units=SP_OSTEOPRS_units |
|   Part D Plan Coverage Months | XdCount | `xg5kj7hykhhh0aebjaudrjfh` | units=PLAN_CVRG_MOS_NUM_units |
|   Race | XdCount | `je8telqg11pzntpcbm2tmt8p` | units=BENE_RACE_CD_units |
|   Rheumatoid Arthritis / Osteoarthritis | XdCount | `at0gbvqwfye87h90hwvzduug` | units=SP_RA_OA_units |
|   Stroke / Transient Ischemic Attack | XdCount | `vopo0hpkl6fna3reydvyycje` | units=SP_STRKETIA_units |
|   Supplementary Medical Insurance Coverage Months | XdCount | `d01zlcgispeiab338fqummdg` | units=BENE_SMI_CVRAGE_TOT_MONS_units |
|   Carrier Annual Beneficiary Responsibility | XdQuantity | `mpwce28dzkh2i3fz8j52ywq9` | units=BENRES_CAR_units |
|   Carrier Annual Medicare Reimbursement | XdQuantity | `h8ruw27uj9gkuufqgbnkopfy` | units=MEDREIMB_CAR_units |
|   Carrier Annual Primary Payer Reimbursement | XdQuantity | `e68r03lol0jqmstbc34oip0s` | units=PPPYMT_CAR_units |
|   Inpatient Annual Beneficiary Responsibility | XdQuantity | `s40zfe8vuotonl030ei82ydn` | units=BENRES_IP_units |
|   Inpatient Annual Medicare Reimbursement | XdQuantity | `g72advg02to55d601h0befuz` | units=MEDREIMB_IP_units |
|   Inpatient Annual Primary Payer Reimbursement | XdQuantity | `fp1zcln4hx9qg0oiktsphmbh` | units=PPPYMT_IP_units |
|   Outpatient Annual Beneficiary Responsibility | XdQuantity | `vb9tdi30dopcbfdiwekwwmkv` | units=BENRES_OP_units |
|   Outpatient Annual Medicare Reimbursement | XdQuantity | `j83j13loyym0u0u1qpu817tj` | units=MEDREIMB_OP_units |
|   Outpatient Annual Primary Payer Reimbursement | XdQuantity | `so5u2az6xi65w1r8l1wm7yla` | units=PPPYMT_OP_units |
|   Date of Death | XdTemporal | `a1wagigj8zy1oy349vwm5clx` | -- |
|   Date of Birth | XdTemporal | `vc9ffb4464mbx3jij0fz2x96` | -- |

## Structural Hierarchy

```
DM: CMS — Beneficiary
  [Cluster] cms-beneficiary
    [XdBoolean] End-Stage Renal Disease Indicator
    [XdString] Beneficiary Code
    [XdCount] Alzheimer's Disease or Related Disorders
    [XdCount] Calculated sex variable
    [XdCount] Cancer
    [XdCount] Chronic Kidney Disease
    [XdCount] Chronic Obstructive Pulmonary Disease
    [XdCount] Congestive Heart Failure
    [XdCount] County Code
    [XdCount] Depression
    [XdCount] HMO Coverage Months
    [XdCount] Hospital Insurance Coverage Months
    [XdCount] Ischemic Heart Disease
    [XdCount] Osteoporosis
    [XdCount] Part D Plan Coverage Months
    [XdCount] Race
    [XdCount] Rheumatoid Arthritis / Osteoarthritis
    [XdCount] Stroke / Transient Ischemic Attack
    [XdCount] Supplementary Medical Insurance Coverage Months
    [XdQuantity] Carrier Annual Beneficiary Responsibility
    [XdQuantity] Carrier Annual Medicare Reimbursement
    [XdQuantity] Carrier Annual Primary Payer Reimbursement
    [XdQuantity] Inpatient Annual Beneficiary Responsibility
    [XdQuantity] Inpatient Annual Medicare Reimbursement
    [XdQuantity] Inpatient Annual Primary Payer Reimbursement
    [XdQuantity] Outpatient Annual Beneficiary Responsibility
    [XdQuantity] Outpatient Annual Medicare Reimbursement
    [XdQuantity] Outpatient Annual Primary Payer Reimbursement
    [XdTemporal] Date of Death
    [XdTemporal] Date of Birth
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| cms-beneficiary | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q46109180` |
| End-Stage Renal Disease Indicator | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| End-Stage Renal Disease Indicator | `rdfs:isDefinedBy` | `https://schema.org/GovernmentBenefitsType` |
| End-Stage Renal Disease Indicator | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Beneficiary Code | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Beneficiary Code | `rdfs:isDefinedBy` | `https://w3id.org/semanticarts/ns/ontology/gist/ID` |
| Beneficiary Code | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Alzheimer's Disease or Related Disorders | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Alzheimer's Disease or Related Disorders | `skos:closeMatch` | `http://snomed.info/id/26929004` |
| Alzheimer's Disease or Related Disorders | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Alzheimer's Disease or Related Disorders | `rdfs:isDefinedBy` | `sdc4:XdCountType/xdcount-value` |
| Calculated sex variable | `rdfs:isDefinedBy` | `http://semanticscience.org/resource/SIO_010029` |
| Calculated sex variable | `rdfs:isDefinedBy` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Calculated sex variable | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Calculated sex variable | `dcterms:subject` | `http://snomed.info/id/410188000` |
| Calculated sex variable | `skos:closeMatch` | `http://snomed.info/id/263495000` |
| Calculated sex variable | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Cancer | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Cancer | `skos:closeMatch` | `http://snomed.info/id/363346000` |
| Cancer | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Cancer | `rdfs:isDefinedBy` | `sdc4:XdCountType/xdcount-value` |
| Chronic Kidney Disease | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Chronic Kidney Disease | `skos:closeMatch` | `http://snomed.info/id/709044004` |
| Chronic Kidney Disease | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Chronic Kidney Disease | `rdfs:isDefinedBy` | `sdc4:XdCountType/xdcount-value` |
| Chronic Obstructive Pulmonary Disease | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q199804` |
| Chronic Obstructive Pulmonary Disease | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Chronic Obstructive Pulmonary Disease | `skos:closeMatch` | `http://snomed.info/id/13645005` |
| Chronic Obstructive Pulmonary Disease | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Congestive Heart Failure | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Congestive Heart Failure | `skos:closeMatch` | `http://snomed.info/id/42343007` |
| Congestive Heart Failure | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Congestive Heart Failure | `rdfs:isDefinedBy` | `sdc4:XdCountType/xdcount-value` |
| County Code | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| County Code | `dcterms:subject` | `http://snomed.info/id/184102003` |
| County Code | `rdfs:isDefinedBy` | `sdc4:XdCountType/xdcount-value` |
| Depression | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Depression | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q11076418` |
| Depression | `skos:closeMatch` | `http://snomed.info/id/35489007` |
| Depression | `dcterms:subject` | `http://snomed.info/id/184102003` |
| HMO Coverage Months | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| HMO Coverage Months | `dcterms:subject` | `http://snomed.info/id/184102003` |
| HMO Coverage Months | `rdfs:isDefinedBy` | `sdc4:XdCountType/xdcount-value` |
| Hospital Insurance Coverage Months | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Hospital Insurance Coverage Months | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Hospital Insurance Coverage Months | `rdfs:isDefinedBy` | `https://schema.org/totalHistoricalEnrollment` |
| Ischemic Heart Disease | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Ischemic Heart Disease | `skos:closeMatch` | `http://snomed.info/id/414545008` |
| Ischemic Heart Disease | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Ischemic Heart Disease | `rdfs:isDefinedBy` | `sdc4:XdCountType/xdcount-value` |
| Osteoporosis | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Osteoporosis | `skos:closeMatch` | `http://snomed.info/id/64859006` |
| Osteoporosis | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Osteoporosis | `rdfs:isDefinedBy` | `sdc4:XdCountType/xdcount-value` |
| Part D Plan Coverage Months | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Part D Plan Coverage Months | `rdfs:isDefinedBy` | `http://semanticscience.org/resource/SIO_000076` |
| Part D Plan Coverage Months | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Race | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Race | `skos:closeMatch` | `https://loinc.org/32624-9` |
| Race | `rdfs:isDefinedBy` | `http://semanticscience.org/resource/SIO_001015` |
| Race | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Rheumatoid Arthritis / Osteoarthritis | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Rheumatoid Arthritis / Osteoarthritis | `rdfs:isDefinedBy` | `https://schema.org/RadioBroadcastService` |
| Rheumatoid Arthritis / Osteoarthritis | `skos:closeMatch` | `http://snomed.info/id/3723001` |
| Rheumatoid Arthritis / Osteoarthritis | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Stroke / Transient Ischemic Attack | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Stroke / Transient Ischemic Attack | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Stroke / Transient Ischemic Attack | `skos:closeMatch` | `http://snomed.info/id/230690007` |
| Stroke / Transient Ischemic Attack | `rdfs:isDefinedBy` | `sdc4:XdCountType/xdcount-value` |
| Supplementary Medical Insurance Coverage Months | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Supplementary Medical Insurance Coverage Months | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Supplementary Medical Insurance Coverage Months | `rdfs:isDefinedBy` | `sdc4:XdCountType/xdcount-value` |
| Carrier Annual Beneficiary Responsibility | `rdfs:isDefinedBy` | `https://schema.org/Car` |
| Carrier Annual Beneficiary Responsibility | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Carrier Annual Beneficiary Responsibility | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Carrier Annual Medicare Reimbursement | `rdfs:isDefinedBy` | `https://schema.org/Car` |
| Carrier Annual Medicare Reimbursement | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Carrier Annual Medicare Reimbursement | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Carrier Annual Primary Payer Reimbursement | `rdfs:isDefinedBy` | `https://schema.org/Car` |
| Carrier Annual Primary Payer Reimbursement | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Carrier Annual Primary Payer Reimbursement | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Inpatient Annual Beneficiary Responsibility | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Inpatient Annual Beneficiary Responsibility | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q72903859` |
| Inpatient Annual Beneficiary Responsibility | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Inpatient Annual Medicare Reimbursement | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Inpatient Annual Medicare Reimbursement | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Inpatient Annual Primary Payer Reimbursement | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Inpatient Annual Primary Payer Reimbursement | `rdfs:isDefinedBy` | `http://semanticscience.org/resource/SIO_001322` |
| Inpatient Annual Primary Payer Reimbursement | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Outpatient Annual Beneficiary Responsibility | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Outpatient Annual Beneficiary Responsibility | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Outpatient Annual Beneficiary Responsibility | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Outpatient Annual Medicare Reimbursement | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Outpatient Annual Medicare Reimbursement | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Outpatient Annual Primary Payer Reimbursement | `rdfs:isDefinedBy` | `https://www.cms.gov/data-research/statistics-trends-and-reports/medicare-claims-synthetic-public-use-files/cms-2008-2010-data-entrepreneurs-synthetic-public-use-file-de-synpuf` |
| Outpatient Annual Primary Payer Reimbursement | `dcterms:subject` | `http://snomed.info/id/184102003` |
| Outpatient Annual Primary Payer Reimbursement | `rdfs:isDefinedBy` | `sdc4:XdQuantityType/xdquantity-value` |
| Date of Death | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q205892` |
| Date of Death | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q29635268` |
| Date of Birth | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q84263196` |
| Date of Birth | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q11213` |
| Date of Birth | `rdfs:isDefinedBy` | `https://www.wikidata.org/wiki/Q390551` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "CMS — Beneficiary" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-q9xk7y13y2115tr4sn2c7m39.xsd)
- Example instance (dm-q9xk7y13y2115tr4sn2c7m39.xml)
- HTML documentation (dm-q9xk7y13y2115tr4sn2c7m39.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"CMS — Beneficiary" SDC4 schema (dm-q9xk7y13y2115tr4sn2c7m39.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"CMS — Beneficiary" schema (dm-q9xk7y13y2115tr4sn2c7m39.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "CMS — Beneficiary" SDC4 schema (dm-q9xk7y13y2115tr4sn2c7m39.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "CMS — Beneficiary" data model (dm-q9xk7y13y2115tr4sn2c7m39.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-q9xk7y13y2115tr4sn2c7m39.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-q9xk7y13y2115tr4sn2c7m39.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-q9xk7y13y2115tr4sn2c7m39.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-q9xk7y13y2115tr4sn2c7m39.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-q9xk7y13y2115tr4sn2c7m39.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
