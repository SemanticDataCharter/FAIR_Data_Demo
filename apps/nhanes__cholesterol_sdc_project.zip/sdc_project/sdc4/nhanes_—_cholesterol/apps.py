"""
Django app configuration for nhanes_—_cholesterol.
"""
from django.apps import AppConfig


class Nhanes_—_cholesterolConfig(AppConfig):
    """App configuration for nhanes_—_cholesterol."""

    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nhanes_—_cholesterol'

    def ready(self):
        """
        Import signals when app is ready.

        This ensures that signal handlers are registered when Django starts.
        """
        import nhanes_—_cholesterol.signals  # noqa: F401
