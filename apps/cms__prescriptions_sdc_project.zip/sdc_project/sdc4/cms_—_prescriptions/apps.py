"""
Django app configuration for cms_—_prescriptions.
"""
from django.apps import AppConfig


class Cms_—_prescriptionsConfig(AppConfig):
    """App configuration for cms_—_prescriptions."""

    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cms_—_prescriptions'

    def ready(self):
        """
        Import signals when app is ready.

        This ensures that signal handlers are registered when Django starts.
        """
        import cms_—_prescriptions.signals  # noqa: F401
