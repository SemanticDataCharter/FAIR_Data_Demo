# BRFSS Respondent

**Model ID**: `dm-iymux9kjv8ndbkoi36xzx17i`
**Project**: FAIR Data Demo
**Description**: SDC4 data model for Behavioral Risk Factor Surveillance System (brfss) — FAIR Data Demo

### Dublin Core Metadata
- **Language**: en-US
- **Rights**: CC-BY http://creativecommons.org/licenses/by/3.0/
- **Coverage**: Universal

## Package Contents

- `dm-iymux9kjv8ndbkoi36xzx17i.xsd` -- XML Schema Definition (data model structure)
- `dm-iymux9kjv8ndbkoi36xzx17i.xml` -- XML instance example with sample data
- `dm-iymux9kjv8ndbkoi36xzx17i-instance.json` -- JSON instance example (same structure as XML)
- `dm-iymux9kjv8ndbkoi36xzx17i.jsonld` -- JSON-LD semantic schema description
- `dm-iymux9kjv8ndbkoi36xzx17i.html` -- Human-readable model documentation
- `dm-iymux9kjv8ndbkoi36xzx17i_shacl.ttl` -- SHACL shapes for RDF validation
- `dm-iymux9kjv8ndbkoi36xzx17i.ttl` -- RDF triples extracted from XSD (Turtle format)
- `dm-iymux9kjv8ndbkoi36xzx17i.rdf` -- RDF triples extracted from XSD (RDF/XML format)
- `dm-iymux9kjv8ndbkoi36xzx17i.gql` -- GQL CREATE statements for property graph databases
- `SHACL_README.md` -- SHACL usage guide
- `README-AI-PROMPT.md` -- This file

## XML Template Placeholders

The XML instance file (`dm-iymux9kjv8ndbkoi36xzx17i.xml`) is a **maximal template** containing every
element defined in the schema. Placeholder markers indicate where data should go:

- **`_PH_`** -- Required placeholder. This element MUST be replaced with valid data
  matching the schema constraints.
- **`_OPT_PH_`** -- Optional placeholder. This element CAN be replaced with data,
  or the entire enclosing element can be removed from the instance.
- **Fixed values** (labels, language, encoding) are pre-filled from the schema and
  should be kept as-is.

When using this template with an AI assistant, instruct it to:
1. Replace all `_PH_` markers with appropriate data
2. Replace `_OPT_PH_` markers with data or remove the element
3. Keep all fixed values unchanged

## Component Inventory

| Label | Type | CT ID | Constraints |
|-------|------|-------|-------------|
| **BRFSS Respondent Governed Record** | Cluster | `hnf5st6e6ulzvbiafx4310g7` | 0 components; 4 sub-cluster(s) |
|   **Audit Event** | Cluster | `t2tvd3wylxrstdeu5aw6gkw1` | 13 components |
|     Audit Agent Reference | XdString | `dkc2ccj5te35z9gd4bu1blcq` | maxLen=2000; pattern=`\S+` |
|     Audit Entity Reference | XdString | `gcjyjrnp0wsfoelcp4m05c67` | maxLen=2000; pattern=`\S+` |
|     Audit Event Identifier | XdString | `fjhgr5fyqxt2crmg2cb5c513` | maxLen=255 |
|     Data Subject Reference | XdString | `sndpbhm3xbd6qtbyxmvh3i0e` | maxLen=2000; pattern=`\S+` |
|     On Behalf Of Reference | XdString | `nf1air1zbj8v9w66jozdxmyl` | maxLen=2000; pattern=`\S+` |
|     System Identifier | XdString | `h3kdbvdtyalpvik97saaf0an` | maxLen=255 |
|     System Location Name | XdString | `ujir739mf1g8ajeczs9nzh9m` | maxLen=255 |
|     Audit Event Action | XdToken | `ce1c8sydkov8bkv4dgdmwe5x` | 5 enum(s) |
|     Audit Event Outcome | XdToken | `rpz1czz06jhpahmfz30rblvp` | 4 enum(s) |
|     Confidentiality | XdToken | `vbctgmdcwps5b3r3l6sboa6y` | 6 enum(s) |
|     Provenance Agent Type | XdToken | `jujsdur1igws8orw6tvvlqco` | 13 enum(s) |
|     Purpose of Use | XdToken | `d1evlz8yvdlwt6ia9fjq4pgj` | 11 enum(s) |
|     Audit Recorded At | XdTemporal | `uwiosm2q9ym3ewr4de910s70` | -- |
|   **BRFSS Respondent** | Cluster | `rdoj4o216s33ymezyefwb8ia` | 1 components; 7 sub-cluster(s) |
|     Annual Sequence Number (SEQNO) | XdString | `pflduyrah1tnmmsjrwfvi121` | maxLen=12; pattern=`[0-9]{10}` |
|     **BRFSS Body Measures** | Cluster | `gc3nb6hzobkzifswmzgt7w6t` | 3 components; 1 sub-cluster(s) |
|       Reported Height in Feet and Inches (HEIGHT3) | XdString | `urjk1vvcot1s319mxygpdsf5` | maxLen=4; pattern=`[0-9]{3,4}` |
|       Computed Body Mass Index Category (_BMI5CAT) | XdToken | `ezewpvppvx8zjikutr53ppgz` | 4 enum(s) |
|       Reported Weight in Pounds (WEIGHT2) | XdQuantity | `gket571isxo2uckturhvxadk` | units=Mass/Weight (US Customary) |
|       **Vital Signs Panel** | Cluster | `atvd5lzut4pjzc7dpv1ykb92` | 9 components; 1 sub-cluster(s) |
|         Observation Status | XdToken | `q9vmn1cvdclgr757aer5v1rg` | 8 enum(s) |
|         Body Height | XdQuantity | `z1ezf3vzksp7qpgd9l3uxvqo` | units=Length/Distance (SI - Metric) |
|         Body Mass Index | XdQuantity | `dchiej5tv7tyhfwr6h3ync1i` | units=Body Mass Index Units |
|         Body Temperature | XdQuantity | `ppqdmkbjmd3gn0p2i74ue3ox` | units=Temperature (SI - Metric) |
|         Body Weight | XdQuantity | `doxdajuj6j1mk480zd1k7ssz` | units=Mass/Weight (SI - Metric) |
|         Heart Rate | XdQuantity | `oy0jwif5pi86xtimzxzhapvu` | units=Rate |
|         Oxygen Saturation | XdQuantity | `htr0gulg01caowd76j6v4ukh` | units=Percentage |
|         Respiratory Rate | XdQuantity | `nzq70mbegncgc6hdfp7vtu46` | units=Rate |
|         Observation Date Time | XdTemporal | `dkyyj01tksb7h7akq2w7moum` | -- |
|         **Blood Pressure** | Cluster | `wyk9e1d74y5xrgv97o9y75ib` | 4 components; 1 sub-cluster(s) |
|           Observation Status | XdToken | `q9vmn1cvdclgr757aer5v1rg` | 8 enum(s) |
|           Diastolic Blood Pressure | XdQuantity | `s3qzwxxz9b42lcd2wryok8jd` | units=Pressure |
|           Systolic Blood Pressure | XdQuantity | `r1ve12xphsb5hu2yjmhksw5h` | units=Pressure |
|           Observation Date Time | XdTemporal | `dkyyj01tksb7h7akq2w7moum` | -- |
|           **Body Site (SNOMED CT)** | Cluster | `r5koa840csi3zcewts0uo0r5` | 3 components |
|             Code System: SNOMED CT | XdLink | `q75pzzv36or6dxgjrrbvmun5` | -- |
|             Body Site Code (SNOMED CT) | XdString | `vi7yvq0b8nler3g6alaamrzm` | maxLen=40; pattern=`[0-9]{6,18}` |
|             Code Display Text | XdString | `eo5tlfr0576ypknys5alvcn0` | maxLen=500 |
|     **BRFSS Chronic Conditions** | Cluster | `lahhb7fhnu75l1fxrv9f8fdv` | 1 components; 1 sub-cluster(s) |
|       Still Have Asthma (ASTHNOW) | XdToken | `dkmozm7gxxss45gf5yhthpjg` | 2 enum(s) |
|       **Chronic Condition Indicators** | Cluster | `wa0mknvfo83hej635n48s0ig` | 22 components |
|         Condition: Alzheimer's Disease or Related Disorder | XdToken | `d9z9mcx6gs9zbz4k6f0v738s` | 2 enum(s) |
|         Condition: Angina | XdToken | `o4d67oubyyunugx3la44f53u` | 2 enum(s) |
|         Condition: Arthritis | XdToken | `nd1v8jk7wtm1tthzw1f4987t` | 2 enum(s) |
|         Condition: Asthma | XdToken | `acr1xvqppf1b3rjsrst6tt4p` | 2 enum(s) |
|         Condition: Cancer | XdToken | `ix0my2v2z79s002g0r8orosf` | 2 enum(s) |
|         Condition: Chronic Bronchitis | XdToken | `jyx7rxfktazhgxgq84fxf6wr` | 2 enum(s) |
|         Condition: Congestive Heart Failure | XdToken | `hyqlz591lhj54sdt1a1mup70` | 2 enum(s) |
|         Condition: COPD | XdToken | `mijr18ynaqde2l8jps70l2g6` | 2 enum(s) |
|         Condition: Coronary Heart Disease | XdToken | `udbydjqj76l8kl6mi2s3v7vd` | 2 enum(s) |
|         Condition: Depression | XdToken | `of4crvmnrr3s5q5396kmt0jv` | 2 enum(s) |
|         Condition: Diabetes | XdToken | `fzpb9xr5jg2m3e3dzmvi1v3h` | 2 enum(s) |
|         Condition: Emphysema | XdToken | `sbulkq80j4fkbiql4zgje4qr` | 2 enum(s) |
|         Condition: Heart Attack | XdToken | `yshoeps2dm0j1ueusqs825v6` | 2 enum(s) |
|         Condition: High Blood Pressure | XdToken | `lvockfc8lce5p15wuwxc1kwa` | 2 enum(s) |
|         Condition: High Cholesterol | XdToken | `gp3jxw3xzs761ll6u5rvc6jr` | 2 enum(s) |
|         Condition Indicator Basis | XdToken | `hc79skkfionpgw87dsg5yrgw` | 2 enum(s) |
|         Condition: Kidney Disease | XdToken | `sw5rt0k2uap0e3xgl4rznfgu` | 2 enum(s) |
|         Condition: Liver Condition | XdToken | `atqkooccakulfhkt18c008fx` | 2 enum(s) |
|         Condition: Osteoporosis | XdToken | `l784ggegqcvrpnmw2yvo4il7` | 2 enum(s) |
|         Condition: Skin Cancer | XdToken | `xsohkckyof7y1xj8h1ab4pxu` | 2 enum(s) |
|         Condition: Stroke | XdToken | `zc6p008h5naqev8zngtzvyx9` | 2 enum(s) |
|         Condition: Thyroid Problem | XdToken | `p8u71b4lhct4ra0szgkex7xo` | 2 enum(s) |
|     **BRFSS Demographics** | Cluster | `oqw3pnwhf8knpgsfo8k3xojn` | 19 components |
|       Education Level (EDUCA) | XdToken | `fci5gajaodxc2ihq6nuz9l6y` | 6 enum(s) |
|       Employment Status (EMPLOY1) | XdToken | `j67yf27qljb83m2fwvown1lk` | 8 enum(s) |
|       Imputed Race/Ethnicity Value (_IMPRACE) | XdToken | `qamg60snb8cl9auv4y03kdc4` | 6 enum(s) |
|       Income Level (INCOME3) | XdToken | `crdh278iwq7azbtcgsuxteve` | 11 enum(s) |
|       Marital Status (MARITAL) | XdToken | `czh5vzmdeijkwrtyla1w7su8` | 6 enum(s) |
|       Pregnancy Status (PREGNANT) | XdToken | `gighl3atjkq88ttivdezt4p7` | 2 enum(s) |
|       Primary Source of Health Insurance (PRIMINSR) | XdToken | `evbpc370eyfc3q3lldwifu78` | 11 enum(s) |
|       Sex of Respondent (SEXVAR) | XdToken | `et536sfok7glz7fartfs4m65` | 2 enum(s) |
|       Veteran Status | XdToken | `eimlsgbawhm8aa4i6gbdrja0` | 2 enum(s) |
|       Are you pregnant now? | XdToken | `owjt9bcgisxfbco8qnddo2fq` | 3 enum(s) |
|       Category of Health Insurance | XdToken | `luq973ggnjoo9ixkt0dym8v6` | 5 enum(s) |
|       Current Educational Attainment | XdToken | `xtbtk7ro6s9247bcwt4ak4h1` | 24 enum(s) |
|       Employment Status | XdToken | `oy35qocyvn0zxq8ni4azvz39` | 9 enum(s) |
|       Marital Status | XdToken | `qsetd453kk9own8co1wmc5cz` | 8 enum(s) |
|       Race/Ethnicity Self-Identification | XdToken | `u5tietya3u56hbz2kos06ai7` | 7 enum(s) |
|       Administrative Gender | XdToken | `gxzbm758mhdz51xd4bawlfhh` | 4 enum(s) |
|       Imputed Age Value Collapsed Above 80 (_AGE80) | XdCount | `evijzyx8i3a268zqdsgmhzo0` | units=Years |
|       Number of Children in Household (CHILDREN) | XdCount | `abjbfcel6qppumg0rlf78wcp` | units=Items |
|       Age | XdCount | `wuvdeiwoe5bna7nlhcl1c4h9` | units=years or months |
|     **BRFSS Disability** | Cluster | `u19jrjjc6aznug6hs2twjiy5` | 6 components |
|       Blind or Serious Difficulty Seeing (BLIND) | XdToken | `rw8s64t4v80421biq8eo9p2x` | 2 enum(s) |
|       Deaf or Serious Difficulty Hearing (DEAF) | XdToken | `hs066djavlc5r494vqu61thl` | 2 enum(s) |
|       Difficulty Doing Errands Alone (DIFFALON) | XdToken | `l9s5avvkix0og66m0lewwqgg` | 2 enum(s) |
|       Difficulty Dressing or Bathing (DIFFDRES) | XdToken | `zbwodv9m60b33blptlellmu0` | 2 enum(s) |
|       Serious Difficulty Concentrating, Remembering or Deciding (DECIDE) | XdToken | `e104gkr3e96ekydrpe8qogjw` | 2 enum(s) |
|       Serious Difficulty Walking or Climbing Stairs (DIFFWALK) | XdToken | `m3970or5qg49k78l0lq1ptjc` | 2 enum(s) |
|     **BRFSS Health Status and Access** | Cluster | `kmgw3rv02bipvaoxpvnh7fzk` | 5 components |
|       Exercise in Past 30 Days (EXERANY2) | XdToken | `a08lkh4xjvqqjtz7sxy129pa` | 2 enum(s) |
|       General Health Status | XdToken | `lth27h6towue4i9iq1cudogc` | 5 enum(s) |
|       Length of Time Since Last Routine Checkup (CHECKUP1) | XdToken | `fa0aian3co6if5igu488whhr` | 5 enum(s) |
|       Days Mental Health Not Good, Past 30 (MENTHLTH) | XdCount | `k32effn0kp5a42ikkpvcva9j` | units=Days |
|       Days Physical Health Not Good, Past 30 (PHYSHLTH) | XdCount | `fljkn7b19qtnj6rr3t8qcfg1` | units=Days |
|     **BRFSS Survey Design** | Cluster | `zauadmfc05ep5nf2kd9j8cwh` | 5 components |
|       Primary Sampling Unit (_PSU) | XdString | `c23wij2i4jkwu016ekro40bv` | maxLen=12 |
|       Sample Design Stratification Variable (_STSTR) | XdString | `frb0byilu8prpn7veyj6luwl` | maxLen=8 |
|       State FIPS Code (_STATE) | XdString | `wesa1iwagjckq500ixmosu2l` | maxLen=2; pattern=`[0-9]{1,2}` |
|       Final Weight: Land-line and Cell-phone Data (_LLCPWT) | XdQuantity | `ba0vveg1d3bmjb9nx8e2x4d3` | units=Sample Weight |
|       Interview Date (IDATE) | XdTemporal | `l4jr7yi9926sctme3vjuti72` | -- |
|     **BRFSS Tobacco and Alcohol Use** | Cluster | `dh2ghpj9z1brefxf0pb4yi14` | 8 components |
|       Computed Smoking Status (_SMOKER3) | XdToken | `iwlb0rcomw3q8rlff3ajukme` | 4 enum(s) |
|       Current E-cigarette Use (ECIGNOW2) | XdToken | `ecwiva31y2fky3eu1mdnvurt` | 4 enum(s) |
|       Frequency of Days Now Smoking (SMOKDAY2) | XdToken | `kzni1q04rghj23ca0zbhauu5` | 3 enum(s) |
|       Smoked at Least 100 Cigarettes (SMOKE100) | XdToken | `hukufq8g2u2k0cpcal7uxsa8` | 2 enum(s) |
|       Smoking Status | XdToken | `n7pn5ctqo81v0v418hez5zv5` | 5 enum(s) |
|       Average Alcoholic Drinks per Day in Past 30 (AVEDRNK3) | XdCount | `gr95a9bk6mfr0220fmxc3o4e` | units=Drinks |
|       Binge Drinking Occasions in Past 30 (DRNK3GE5) | XdCount | `g0dq4n7oml1mmi21t50biiwt` | units=Items |
|       Days in Past 30 Had Alcoholic Beverage (ALCDAY4) | XdCount | `nh9s5b7gb713asjatbg5guyc` | units=Days |
|   **PROV Activity** | Cluster | `vmikfu0irht9fmq7q02t3oqs` | 15 components |
|     Activity Description | XdString | `hhusuzzig19rs46ngz23k5g7` | maxLen=4000 |
|     Activity Identifier | XdString | `wr06h54xqqw2q9id8i9673jy` | maxLen=255 |
|     Activity Label | XdString | `r6hkunjm2q0hlxiknlc9ljix` | maxLen=255 |
|     Activity Location | XdString | `uzai5uey5p1fnn9ezj9u6vor` | maxLen=255 |
|     Activity Type | XdString | `jjzmhdxvbt97pq81iwqubtxk` | maxLen=255 |
|     Error Message | XdString | `xlgjqdpwdbn2re3mdh5yy2rk` | maxLen=4000 |
|     Had Plan Reference | XdString | `vhezo2cckpe92x4c3j2memeh` | maxLen=2000; pattern=`\S+` |
|     Used Entity Reference | XdString | `t0whhrqtnb54te4mk48i1ooj` | maxLen=2000; pattern=`\S+` |
|     Was Associated With Reference | XdString | `r48alj7hc3797qfjnf2uj71n` | maxLen=2000; pattern=`\S+` |
|     Was Ended By Reference | XdString | `ueb5g1ojzlwwt0mnds5zb6wl` | maxLen=2000; pattern=`\S+` |
|     Was Informed By Reference | XdString | `qh84jdzp1kxt85aq4ilo0svk` | maxLen=2000; pattern=`\S+` |
|     Was Started By Reference | XdString | `ginfqbk7q59ld2r4us8sjnv1` | maxLen=2000; pattern=`\S+` |
|     Activity Status | XdToken | `wl6j4ekcmu4hvt2m12zw4zp8` | 6 enum(s) |
|     Ended At | XdTemporal | `a5scyosu6j84vz350mqyrzl2` | -- |
|     Started At | XdTemporal | `sa4nl1kbpdr842fkucvfjkpq` | -- |
|   **PROV Agent** | Cluster | `c179ilk2ns15cd5rzzdfd6f6` | 9 components |
|     Acted On Behalf Of Reference | XdString | `og08xf6bu928uuz6t3y0e23f` | maxLen=2000; pattern=`\S+` |
|     Agent Description | XdString | `gb78cmuyo72hqs5apymdki7l` | maxLen=4000 |
|     Agent Email | XdString | `qb90a0sp9vvb6c5cbcf236ys` | maxLen=255 |
|     Agent Identifier | XdString | `w2ruemcfy35rw60jl1t9dew2` | maxLen=255 |
|     Agent Name | XdString | `xxe21o9ojzmy9wxxky1tnmog` | maxLen=255 |
|     Agent Organization Name | XdString | `eftvwi5byq6cdtd931qyxzw0` | maxLen=255 |
|     Software Name | XdString | `aa663ivutjf2fs4757t0bbzy` | maxLen=255 |
|     Software Version | XdString | `x0lebwtobgaelj5pev3258sd` | maxLen=60 |
|     PROV Agent Type | XdToken | `i16vqj89it3db7d3c5qjko9p` | 3 enum(s) |

## Structural Hierarchy

```
DM: BRFSS Respondent
  [Cluster] BRFSS Respondent Governed Record
    [Cluster] Audit Event
      [XdString] Audit Agent Reference
      [XdString] Audit Entity Reference
      [XdString] Audit Event Identifier
      [XdString] Data Subject Reference
      [XdString] On Behalf Of Reference
      [XdString] System Identifier
      [XdString] System Location Name
      [XdToken] Audit Event Action
      [XdToken] Audit Event Outcome
      [XdToken] Confidentiality
      [XdToken] Provenance Agent Type
      [XdToken] Purpose of Use
      [XdTemporal] Audit Recorded At
    [Cluster] BRFSS Respondent
      [XdString] Annual Sequence Number (SEQNO)
      [Cluster] BRFSS Body Measures
        [XdString] Reported Height in Feet and Inches (HEIGHT3)
        [XdToken] Computed Body Mass Index Category (_BMI5CAT)
        [XdQuantity] Reported Weight in Pounds (WEIGHT2)
        [Cluster] Vital Signs Panel
          [XdToken] Observation Status
          [XdQuantity] Body Height
          [XdQuantity] Body Mass Index
          [XdQuantity] Body Temperature
          [XdQuantity] Body Weight
          [XdQuantity] Heart Rate
          [XdQuantity] Oxygen Saturation
          [XdQuantity] Respiratory Rate
          [XdTemporal] Observation Date Time
          [Cluster] Blood Pressure
            [XdToken] Observation Status
            [XdQuantity] Diastolic Blood Pressure
            [XdQuantity] Systolic Blood Pressure
            [XdTemporal] Observation Date Time
            [Cluster] Body Site (SNOMED CT)
              [XdLink] Code System: SNOMED CT
              [XdString] Body Site Code (SNOMED CT)
              [XdString] Code Display Text
      [Cluster] BRFSS Chronic Conditions
        [XdToken] Still Have Asthma (ASTHNOW)
        [Cluster] Chronic Condition Indicators
          [XdToken] Condition: Alzheimer's Disease or Related Disorder
          [XdToken] Condition: Angina
          [XdToken] Condition: Arthritis
          [XdToken] Condition: Asthma
          [XdToken] Condition: Cancer
          [XdToken] Condition: Chronic Bronchitis
          [XdToken] Condition: Congestive Heart Failure
          [XdToken] Condition: COPD
          [XdToken] Condition: Coronary Heart Disease
          [XdToken] Condition: Depression
          [XdToken] Condition: Diabetes
          [XdToken] Condition: Emphysema
          [XdToken] Condition: Heart Attack
          [XdToken] Condition: High Blood Pressure
          [XdToken] Condition: High Cholesterol
          [XdToken] Condition Indicator Basis
          [XdToken] Condition: Kidney Disease
          [XdToken] Condition: Liver Condition
          [XdToken] Condition: Osteoporosis
          [XdToken] Condition: Skin Cancer
          [XdToken] Condition: Stroke
          [XdToken] Condition: Thyroid Problem
      [Cluster] BRFSS Demographics
        [XdToken] Education Level (EDUCA)
        [XdToken] Employment Status (EMPLOY1)
        [XdToken] Imputed Race/Ethnicity Value (_IMPRACE)
        [XdToken] Income Level (INCOME3)
        [XdToken] Marital Status (MARITAL)
        [XdToken] Pregnancy Status (PREGNANT)
        [XdToken] Primary Source of Health Insurance (PRIMINSR)
        [XdToken] Sex of Respondent (SEXVAR)
        [XdToken] Veteran Status
        [XdToken] Are you pregnant now?
        [XdToken] Category of Health Insurance
        [XdToken] Current Educational Attainment
        [XdToken] Employment Status
        [XdToken] Marital Status
        [XdToken] Race/Ethnicity Self-Identification
        [XdToken] Administrative Gender
        [XdCount] Imputed Age Value Collapsed Above 80 (_AGE80)
        [XdCount] Number of Children in Household (CHILDREN)
        [XdCount] Age
      [Cluster] BRFSS Disability
        [XdToken] Blind or Serious Difficulty Seeing (BLIND)
        [XdToken] Deaf or Serious Difficulty Hearing (DEAF)
        [XdToken] Difficulty Doing Errands Alone (DIFFALON)
        [XdToken] Difficulty Dressing or Bathing (DIFFDRES)
        [XdToken] Serious Difficulty Concentrating, Remembering or Deciding (DECIDE)
        [XdToken] Serious Difficulty Walking or Climbing Stairs (DIFFWALK)
      [Cluster] BRFSS Health Status and Access
        [XdToken] Exercise in Past 30 Days (EXERANY2)
        [XdToken] General Health Status
        [XdToken] Length of Time Since Last Routine Checkup (CHECKUP1)
        [XdCount] Days Mental Health Not Good, Past 30 (MENTHLTH)
        [XdCount] Days Physical Health Not Good, Past 30 (PHYSHLTH)
      [Cluster] BRFSS Survey Design
        [XdString] Primary Sampling Unit (_PSU)
        [XdString] Sample Design Stratification Variable (_STSTR)
        [XdString] State FIPS Code (_STATE)
        [XdQuantity] Final Weight: Land-line and Cell-phone Data (_LLCPWT)
        [XdTemporal] Interview Date (IDATE)
      [Cluster] BRFSS Tobacco and Alcohol Use
        [XdToken] Computed Smoking Status (_SMOKER3)
        [XdToken] Current E-cigarette Use (ECIGNOW2)
        [XdToken] Frequency of Days Now Smoking (SMOKDAY2)
        [XdToken] Smoked at Least 100 Cigarettes (SMOKE100)
        [XdToken] Smoking Status
        [XdCount] Average Alcoholic Drinks per Day in Past 30 (AVEDRNK3)
        [XdCount] Binge Drinking Occasions in Past 30 (DRNK3GE5)
        [XdCount] Days in Past 30 Had Alcoholic Beverage (ALCDAY4)
    [Cluster] PROV Activity
      [XdString] Activity Description
      [XdString] Activity Identifier
      [XdString] Activity Label
      [XdString] Activity Location
      [XdString] Activity Type
      [XdString] Error Message
      [XdString] Had Plan Reference
      [XdString] Used Entity Reference
      [XdString] Was Associated With Reference
      [XdString] Was Ended By Reference
      [XdString] Was Informed By Reference
      [XdString] Was Started By Reference
      [XdToken] Activity Status
      [XdTemporal] Ended At
      [XdTemporal] Started At
    [Cluster] PROV Agent
      [XdString] Acted On Behalf Of Reference
      [XdString] Agent Description
      [XdString] Agent Email
      [XdString] Agent Identifier
      [XdString] Agent Name
      [XdString] Agent Organization Name
      [XdString] Software Name
      [XdString] Software Version
      [XdToken] PROV Agent Type
```

## Semantic Links

| Component | Predicate | Object URI |
|-----------|-----------|------------|
| BRFSS Respondent Governed Record | `dcterms:publisher` | `https://axius-sdc.com` |
| BRFSS Respondent Governed Record | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| BRFSS Respondent Governed Record | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-respondent-governed-record` |
| BRFSS Respondent Governed Record | `skos:exactMatch` | `http://www.w3.org/ns/prov#Entity` |
| Audit Event | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event` |
| Audit Event | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/AuditEvent` |
| Audit Agent Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Agent Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Agent Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-agent-reference` |
| Audit Agent Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.who` |
| Audit Agent Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-bads7w1q6wmhn18u6dxwt28t` |
| Audit Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Entity Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-entity-reference` |
| Audit Entity Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.entity.what` |
| Audit Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-sjp1x177mlpq3howdltptm3c` |
| Audit Event Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-identifier` |
| Audit Event Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Data Subject Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Data Subject Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Data Subject Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/data-subject-reference` |
| Data Subject Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.patient` |
| Data Subject Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-x2rc9cg84d2famryqzdic0as` |
| On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| On Behalf Of Reference | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/on-behalf-of-reference` |
| On Behalf Of Reference | `skos:exactMatch` | `http://hl7.org/fhir/R4/provenance-definitions.html#Provenance.agent.onBehalfOf` |
| On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-j9gvyx6u9pb7v1dd0m6joxd6` |
| System Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| System Identifier | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-identifier` |
| System Identifier | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.source.observer` |
| System Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-des67jo3ki9w0zgaz2i2t2cq` |
| System Location Name | `dcterms:publisher` | `https://axius-sdc.com` |
| System Location Name | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| System Location Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/system-location-name` |
| System Location Name | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.agent.location` |
| System Location Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-l6fwy1a2l5i43t308pknygp7` |
| Audit Event Action | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Action | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Action | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-action` |
| Audit Event Action | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-action` |
| Audit Event Action | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-o8lawuczf9vry55e98cjg12r` |
| Audit Event Outcome | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Event Outcome | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Event Outcome | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-event-outcome` |
| Audit Event Outcome | `skos:exactMatch` | `http://hl7.org/fhir/audit-event-outcome` |
| Audit Event Outcome | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-lgmleqp52a6kl268drrtfjk5` |
| Confidentiality | `dcterms:publisher` | `https://axius-sdc.com` |
| Confidentiality | `dcterms:source` | `http://terminology.hl7.org/` |
| Confidentiality | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/confidentiality` |
| Confidentiality | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-Confidentiality` |
| Confidentiality | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hp8q52t8tgmis92c4ljrfy7e` |
| Provenance Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Provenance Agent Type | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Provenance Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/provenance-agent-type` |
| Provenance Agent Type | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/provenance-participant-type` |
| Provenance Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-syt8l7pmb64eym2chcn43ai7` |
| Purpose of Use | `dcterms:publisher` | `https://axius-sdc.com` |
| Purpose of Use | `dcterms:source` | `http://terminology.hl7.org/` |
| Purpose of Use | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/purpose-of-use` |
| Purpose of Use | `skos:exactMatch` | `http://terminology.hl7.org/CodeSystem/v3-ActReason` |
| Purpose of Use | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-y87ikto4p56zlkx4o2d63ain` |
| Audit Recorded At | `dcterms:publisher` | `https://axius-sdc.com` |
| Audit Recorded At | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Audit Recorded At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/audit-recorded-at` |
| Audit Recorded At | `skos:exactMatch` | `http://hl7.org/fhir/R4/auditevent-definitions.html#AuditEvent.recorded` |
| BRFSS Respondent | `dcterms:publisher` | `https://axius-sdc.com` |
| BRFSS Respondent | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| BRFSS Respondent | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-respondent` |
| BRFSS Respondent | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C41189` |
| Annual Sequence Number (SEQNO) | `dcterms:publisher` | `https://axius-sdc.com` |
| Annual Sequence Number (SEQNO) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Annual Sequence Number (SEQNO) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-annual-sequence-number` |
| Annual Sequence Number (SEQNO) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| BRFSS Body Measures | `dcterms:publisher` | `https://axius-sdc.com` |
| BRFSS Body Measures | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| BRFSS Body Measures | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-body-measures` |
| BRFSS Body Measures | `skos:exactMatch` | `https://loinc.org/39156-5/` |
| Reported Height in Feet and Inches (HEIGHT3) | `dcterms:publisher` | `https://axius-sdc.com` |
| Reported Height in Feet and Inches (HEIGHT3) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Reported Height in Feet and Inches (HEIGHT3) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-reported-height` |
| Reported Height in Feet and Inches (HEIGHT3) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Computed Body Mass Index Category (_BMI5CAT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Computed Body Mass Index Category (_BMI5CAT) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Computed Body Mass Index Category (_BMI5CAT) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-bmi-category` |
| Computed Body Mass Index Category (_BMI5CAT) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Reported Weight in Pounds (WEIGHT2) | `dcterms:publisher` | `https://axius-sdc.com` |
| Reported Weight in Pounds (WEIGHT2) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Reported Weight in Pounds (WEIGHT2) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-reported-weight-in-pounds` |
| Reported Weight in Pounds (WEIGHT2) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Vital Signs Panel | `dcterms:publisher` | `https://axius-sdc.com` |
| Vital Signs Panel | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Vital Signs Panel | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/vital-signs-panel` |
| Vital Signs Panel | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/Observation` |
| Vital Signs Panel | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ns80igp59zsj4arcyys2dkhj` |
| Observation Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Observation Status | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Observation Status | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/observation-status` |
| Observation Status | `skos:closeMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.status` |
| Observation Status | `skos:exactMatch` | `http://hl7.org/fhir/observation-status` |
| Observation Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uulveklfu0gsttxdsb5w0daw` |
| Body Height | `dcterms:publisher` | `https://axius-sdc.com` |
| Body Height | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Body Height | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/body-height` |
| Body Height | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Body Height | `skos:exactMatch` | `https://loinc.org/8302-2/` |
| Body Height | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-pzy0atizoa3c2uf5qk4q7wbp` |
| Body Mass Index | `dcterms:publisher` | `https://axius-sdc.com` |
| Body Mass Index | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Body Mass Index | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/bmi` |
| Body Mass Index | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Body Mass Index | `skos:exactMatch` | `https://loinc.org/39156-5/` |
| Body Mass Index | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-st9s8xlbfyokx2iprntbb74f` |
| Body Temperature | `dcterms:publisher` | `https://axius-sdc.com` |
| Body Temperature | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Body Temperature | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/body-temperature` |
| Body Temperature | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Body Temperature | `skos:exactMatch` | `https://loinc.org/8310-5/` |
| Body Temperature | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tulo1e75g24qf8xon4am5f46` |
| Body Weight | `dcterms:publisher` | `https://axius-sdc.com` |
| Body Weight | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Body Weight | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/body-weight` |
| Body Weight | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Body Weight | `skos:exactMatch` | `https://loinc.org/29463-7/` |
| Body Weight | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-csn8ymg324e0upnzku4aqrcq` |
| Heart Rate | `dcterms:publisher` | `https://axius-sdc.com` |
| Heart Rate | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Heart Rate | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/heart-rate` |
| Heart Rate | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Heart Rate | `skos:exactMatch` | `https://loinc.org/8867-4/` |
| Heart Rate | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uzyj5sccijtoppr2j7szwaj0` |
| Oxygen Saturation | `dcterms:publisher` | `https://axius-sdc.com` |
| Oxygen Saturation | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Oxygen Saturation | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/oxygen-saturation` |
| Oxygen Saturation | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Oxygen Saturation | `skos:exactMatch` | `https://loinc.org/2708-6/` |
| Oxygen Saturation | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-j2xic9nkngxcfhc137pvjbn5` |
| Respiratory Rate | `dcterms:publisher` | `https://axius-sdc.com` |
| Respiratory Rate | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Respiratory Rate | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/respiratory-rate` |
| Respiratory Rate | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Respiratory Rate | `skos:exactMatch` | `https://loinc.org/9279-1/` |
| Respiratory Rate | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uh4kgd9s7bk1403mkz1uuasn` |
| Observation Date Time | `dcterms:publisher` | `https://axius-sdc.com` |
| Observation Date Time | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Observation Date Time | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/observation-datetime` |
| Observation Date Time | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.effectiveDateTime` |
| Observation Date Time | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uwjplwpntsl4q5mckbmb7lhi` |
| Blood Pressure | `dcterms:publisher` | `https://axius-sdc.com` |
| Blood Pressure | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Blood Pressure | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/blood-pressure` |
| Blood Pressure | `skos:exactMatch` | `http://hl7.org/fhir/StructureDefinition/Observation` |
| Blood Pressure | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-aswsw3sct9bnujj53q8g2r5s` |
| Observation Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Observation Status | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Observation Status | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/observation-status` |
| Observation Status | `skos:closeMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.status` |
| Observation Status | `skos:exactMatch` | `http://hl7.org/fhir/observation-status` |
| Observation Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uulveklfu0gsttxdsb5w0daw` |
| Diastolic Blood Pressure | `dcterms:publisher` | `https://axius-sdc.com` |
| Diastolic Blood Pressure | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Diastolic Blood Pressure | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/diastolic-blood-pressure` |
| Diastolic Blood Pressure | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Diastolic Blood Pressure | `skos:exactMatch` | `https://loinc.org/8462-4/` |
| Diastolic Blood Pressure | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-on1yxktbzpmkrfha7vpy818u` |
| Systolic Blood Pressure | `dcterms:publisher` | `https://axius-sdc.com` |
| Systolic Blood Pressure | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Systolic Blood Pressure | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/systolic-blood-pressure` |
| Systolic Blood Pressure | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.valueQuantity` |
| Systolic Blood Pressure | `skos:exactMatch` | `https://loinc.org/8480-6/` |
| Systolic Blood Pressure | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-zcqdrf41l9x3y4kc6kk472zi` |
| Observation Date Time | `dcterms:publisher` | `https://axius-sdc.com` |
| Observation Date Time | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Observation Date Time | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/observation-datetime` |
| Observation Date Time | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.effectiveDateTime` |
| Observation Date Time | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-uwjplwpntsl4q5mckbmb7lhi` |
| Body Site (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Body Site (SNOMED CT) | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Body Site (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/body-site` |
| Body Site (SNOMED CT) | `skos:closeMatch` | `http://snomed.info/sct` |
| Body Site (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.bodySite` |
| Code System: SNOMED CT | `dcterms:publisher` | `https://axius-sdc.com` |
| Code System: SNOMED CT | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/system-snomed` |
| Code System: SNOMED CT | `skos:exactMatch` | `http://snomed.info/sct` |
| Code System: SNOMED CT | `dcterms:source` | `http://snomed.info/sct` |
| Body Site Code (SNOMED CT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Body Site Code (SNOMED CT) | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/body-site-code` |
| Body Site Code (SNOMED CT) | `skos:exactMatch` | `http://hl7.org/fhir/R4/observation-definitions.html#Observation.bodySite` |
| Body Site Code (SNOMED CT) | `skos:exactMatch` | `http://snomed.info/sct` |
| Body Site Code (SNOMED CT) | `dcterms:source` | `http://snomed.info/sct` |
| Body Site Code (SNOMED CT) | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w8ydi05lu9vtr4cxwvnc7cs5` |
| Code Display Text | `dcterms:publisher` | `https://axius-sdc.com` |
| Code Display Text | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Code Display Text | `dcterms:identifier` | `https://axius-sdc.com/library/fhir/code-display-text` |
| Code Display Text | `skos:exactMatch` | `http://hl7.org/fhir/R4/datatypes-definitions.html#Coding.display` |
| BRFSS Chronic Conditions | `dcterms:publisher` | `https://axius-sdc.com` |
| BRFSS Chronic Conditions | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| BRFSS Chronic Conditions | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-chronic-conditions` |
| BRFSS Chronic Conditions | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C2991` |
| Still Have Asthma (ASTHNOW) | `dcterms:publisher` | `https://axius-sdc.com` |
| Still Have Asthma (ASTHNOW) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Still Have Asthma (ASTHNOW) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-still-have-asthma` |
| Still Have Asthma (ASTHNOW) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Chronic Condition Indicators | `dcterms:publisher` | `https://axius-sdc.com` |
| Chronic Condition Indicators | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Chronic Condition Indicators | `dcterms:identifier` | `https://axius-sdc.com/library/fair/chronic-condition-indicators` |
| Chronic Condition Indicators | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C2991` |
| Condition: Alzheimer's Disease or Related Disorder | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Alzheimer's Disease or Related Disorder | `dcterms:subject` | `http://snomed.info/id/26929004` |
| Condition: Alzheimer's Disease or Related Disorder | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Alzheimer's Disease or Related Disorder | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-alzheimers-disease` |
| Condition: Angina | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Angina | `dcterms:subject` | `http://snomed.info/id/194828000` |
| Condition: Angina | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Angina | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-angina` |
| Condition: Arthritis | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Arthritis | `dcterms:subject` | `http://snomed.info/id/3723001` |
| Condition: Arthritis | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Arthritis | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-arthritis` |
| Condition: Asthma | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Asthma | `dcterms:subject` | `http://snomed.info/id/195967001` |
| Condition: Asthma | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Asthma | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-asthma` |
| Condition: Cancer | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Cancer | `dcterms:subject` | `http://snomed.info/id/363346000` |
| Condition: Cancer | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Cancer | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-cancer` |
| Condition: Chronic Bronchitis | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Chronic Bronchitis | `dcterms:subject` | `http://snomed.info/id/63480004` |
| Condition: Chronic Bronchitis | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Chronic Bronchitis | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-chronic-bronchitis` |
| Condition: Congestive Heart Failure | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Congestive Heart Failure | `dcterms:subject` | `http://snomed.info/id/42343007` |
| Condition: Congestive Heart Failure | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Congestive Heart Failure | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-congestive-heart-failure` |
| Condition: COPD | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: COPD | `dcterms:subject` | `http://snomed.info/id/13645005` |
| Condition: COPD | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: COPD | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-copd` |
| Condition: Coronary Heart Disease | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Coronary Heart Disease | `dcterms:subject` | `http://snomed.info/id/53741008` |
| Condition: Coronary Heart Disease | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Coronary Heart Disease | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-coronary-heart-disease` |
| Condition: Depression | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Depression | `dcterms:subject` | `http://snomed.info/id/35489007` |
| Condition: Depression | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Depression | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-depression` |
| Condition: Diabetes | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Diabetes | `dcterms:subject` | `http://snomed.info/id/73211009` |
| Condition: Diabetes | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Diabetes | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-diabetes` |
| Condition: Emphysema | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Emphysema | `dcterms:subject` | `http://snomed.info/id/87433001` |
| Condition: Emphysema | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Emphysema | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-emphysema` |
| Condition: Heart Attack | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Heart Attack | `dcterms:subject` | `http://snomed.info/id/22298006` |
| Condition: Heart Attack | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Heart Attack | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-heart-attack` |
| Condition: High Blood Pressure | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: High Blood Pressure | `dcterms:subject` | `http://snomed.info/id/38341003` |
| Condition: High Blood Pressure | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: High Blood Pressure | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-high-blood-pressure` |
| Condition: High Cholesterol | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: High Cholesterol | `dcterms:subject` | `http://snomed.info/id/13644009` |
| Condition: High Cholesterol | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: High Cholesterol | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-high-cholesterol` |
| Condition Indicator Basis | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition Indicator Basis | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition Indicator Basis | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-indicator-basis` |
| Condition Indicator Basis | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C25596` |
| Condition: Kidney Disease | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Kidney Disease | `dcterms:subject` | `http://snomed.info/id/709044004` |
| Condition: Kidney Disease | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Kidney Disease | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-kidney-disease` |
| Condition: Liver Condition | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Liver Condition | `dcterms:subject` | `http://snomed.info/id/235856003` |
| Condition: Liver Condition | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Liver Condition | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-liver-condition` |
| Condition: Osteoporosis | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Osteoporosis | `dcterms:subject` | `http://snomed.info/id/64859006` |
| Condition: Osteoporosis | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Osteoporosis | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-osteoporosis` |
| Condition: Skin Cancer | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Skin Cancer | `dcterms:subject` | `http://snomed.info/id/372130007` |
| Condition: Skin Cancer | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Skin Cancer | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-skin-cancer` |
| Condition: Stroke | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Stroke | `dcterms:subject` | `http://snomed.info/id/230690007` |
| Condition: Stroke | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Stroke | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-stroke` |
| Condition: Thyroid Problem | `dcterms:publisher` | `https://axius-sdc.com` |
| Condition: Thyroid Problem | `dcterms:subject` | `http://snomed.info/id/14304000` |
| Condition: Thyroid Problem | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Condition: Thyroid Problem | `dcterms:identifier` | `https://axius-sdc.com/library/fair/condition-thyroid-problem` |
| BRFSS Demographics | `dcterms:publisher` | `https://axius-sdc.com` |
| BRFSS Demographics | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| BRFSS Demographics | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-demographics` |
| BRFSS Demographics | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C16495` |
| Education Level (EDUCA) | `dcterms:publisher` | `https://axius-sdc.com` |
| Education Level (EDUCA) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Education Level (EDUCA) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-education-level` |
| Education Level (EDUCA) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Employment Status (EMPLOY1) | `dcterms:publisher` | `https://axius-sdc.com` |
| Employment Status (EMPLOY1) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Employment Status (EMPLOY1) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-employment-status` |
| Employment Status (EMPLOY1) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Imputed Race/Ethnicity Value (_IMPRACE) | `dcterms:publisher` | `https://axius-sdc.com` |
| Imputed Race/Ethnicity Value (_IMPRACE) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Imputed Race/Ethnicity Value (_IMPRACE) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-imputed-race-ethnicity` |
| Imputed Race/Ethnicity Value (_IMPRACE) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Income Level (INCOME3) | `dcterms:publisher` | `https://axius-sdc.com` |
| Income Level (INCOME3) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Income Level (INCOME3) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-income-level` |
| Income Level (INCOME3) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Marital Status (MARITAL) | `dcterms:publisher` | `https://axius-sdc.com` |
| Marital Status (MARITAL) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Marital Status (MARITAL) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-marital-status` |
| Marital Status (MARITAL) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Pregnancy Status (PREGNANT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Pregnancy Status (PREGNANT) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Pregnancy Status (PREGNANT) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-pregnancy-status` |
| Pregnancy Status (PREGNANT) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Primary Source of Health Insurance (PRIMINSR) | `dcterms:publisher` | `https://axius-sdc.com` |
| Primary Source of Health Insurance (PRIMINSR) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Primary Source of Health Insurance (PRIMINSR) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-primary-source-of-insurance` |
| Primary Source of Health Insurance (PRIMINSR) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Sex of Respondent (SEXVAR) | `dcterms:publisher` | `https://axius-sdc.com` |
| Sex of Respondent (SEXVAR) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Sex of Respondent (SEXVAR) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-sex-of-respondent` |
| Sex of Respondent (SEXVAR) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Veteran Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Veteran Status | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Veteran Status | `dcterms:identifier` | `https://axius-sdc.com/library/fair/veteran-status` |
| Veteran Status | `rdfs:seeAlso` | `https://wwwn.cdc.gov/Nchs/Nhanes/2017-2018/DEMO_J.htm#DMQMILIZ` |
| Veteran Status | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C17742` |
| Are you pregnant now? | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C25742` |
| Are you pregnant now? | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C25471` |
| Are you pregnant now? | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C25180` |
| Are you pregnant now? | `dcterms:source` | `https://cde.nlm.nih.gov/deView?tinyId=LiUWCWluP` |
| Are you pregnant now? | `dcterms:publisher` | `http://www.wikidata.org/entity/Q390551` |
| Are you pregnant now? | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C25190` |
| Are you pregnant now? | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-a35l6khng8f63x6jgfs450lf` |
| Category of Health Insurance | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C157356` |
| Category of Health Insurance | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C25372` |
| Category of Health Insurance | `dcterms:source` | `https://cde.nlm.nih.gov/deView?tinyId=cPiK4Amjn5` |
| Category of Health Insurance | `dcterms:publisher` | `http://www.wikidata.org/entity/Q390551` |
| Category of Health Insurance | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C25190` |
| Category of Health Insurance | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ez8dt6meortb1xt1h4w9qz6b` |
| Current Educational Attainment | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C17953` |
| Current Educational Attainment | `dcterms:source` | `https://cde.nlm.nih.gov/deView?tinyId=Co2d1RyYS3` |
| Current Educational Attainment | `dcterms:publisher` | `http://www.wikidata.org/entity/Q390551` |
| Current Educational Attainment | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C25190` |
| Current Educational Attainment | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-u0t7nkb38c0sk5baielllqld` |
| Employment Status | `dcterms:source` | `https://cde.nlm.nih.gov/deView?tinyId=RME88_Wg_hV` |
| Employment Status | `dcterms:publisher` | `http://www.wikidata.org/entity/Q6973755` |
| Employment Status | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C179143` |
| Employment Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-f6buldrgoh2se4ttirffh2g0` |
| Marital Status | `dcterms:source` | `https://cde.nlm.nih.gov/deView?tinyId=C6SezX_mKG` |
| Marital Status | `dcterms:publisher` | `http://www.wikidata.org/entity/Q6973755` |
| Marital Status | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C25188` |
| Marital Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-qmqis7vj5dmx3m9adbbvlb7r` |
| Race/Ethnicity Self-Identification | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C16564` |
| Race/Ethnicity Self-Identification | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C74528` |
| Race/Ethnicity Self-Identification | `dcterms:source` | `https://cde.nlm.nih.gov/deView?tinyId=LakF0YkywC` |
| Race/Ethnicity Self-Identification | `dcterms:publisher` | `http://www.wikidata.org/entity/Q6973755` |
| Race/Ethnicity Self-Identification | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C17049` |
| Race/Ethnicity Self-Identification | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hmc3dce8i1muhh9nr5bkbj92` |
| Administrative Gender | `dcterms:publisher` | `https://axius-sdc.com` |
| Administrative Gender | `dcterms:source` | `http://hl7.org/fhir/R4/` |
| Administrative Gender | `dcterms:identifier` | `https://axius-sdc.com/library/default/administrative-gender` |
| Administrative Gender | `skos:exactMatch` | `http://hl7.org/fhir/administrative-gender` |
| Administrative Gender | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tnyh2ude3db9smwfin0vai5h` |
| Imputed Age Value Collapsed Above 80 (_AGE80) | `dcterms:publisher` | `https://axius-sdc.com` |
| Imputed Age Value Collapsed Above 80 (_AGE80) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Imputed Age Value Collapsed Above 80 (_AGE80) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-imputed-age-80` |
| Imputed Age Value Collapsed Above 80 (_AGE80) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Number of Children in Household (CHILDREN) | `dcterms:publisher` | `https://axius-sdc.com` |
| Number of Children in Household (CHILDREN) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Number of Children in Household (CHILDREN) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-number-of-children-in-household` |
| Number of Children in Household (CHILDREN) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Age | `dcterms:source` | `https://cde.nlm.nih.gov/deView?tinyId=PDjBiGXjO` |
| Age | `dcterms:publisher` | `http://www.wikidata.org/entity/Q6973755` |
| Age | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C25150` |
| Age | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-cb4ti4afgfe9wd641tflfrdj` |
| BRFSS Disability | `dcterms:publisher` | `https://axius-sdc.com` |
| BRFSS Disability | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| BRFSS Disability | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-disability` |
| BRFSS Disability | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C21007` |
| Blind or Serious Difficulty Seeing (BLIND) | `dcterms:publisher` | `https://axius-sdc.com` |
| Blind or Serious Difficulty Seeing (BLIND) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Blind or Serious Difficulty Seeing (BLIND) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-blind-or-difficulty-seeing` |
| Blind or Serious Difficulty Seeing (BLIND) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Deaf or Serious Difficulty Hearing (DEAF) | `dcterms:publisher` | `https://axius-sdc.com` |
| Deaf or Serious Difficulty Hearing (DEAF) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Deaf or Serious Difficulty Hearing (DEAF) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-deaf-or-hard-of-hearing` |
| Deaf or Serious Difficulty Hearing (DEAF) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Difficulty Doing Errands Alone (DIFFALON) | `dcterms:publisher` | `https://axius-sdc.com` |
| Difficulty Doing Errands Alone (DIFFALON) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Difficulty Doing Errands Alone (DIFFALON) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-difficulty-doing-errands-alone` |
| Difficulty Doing Errands Alone (DIFFALON) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Difficulty Dressing or Bathing (DIFFDRES) | `dcterms:publisher` | `https://axius-sdc.com` |
| Difficulty Dressing or Bathing (DIFFDRES) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Difficulty Dressing or Bathing (DIFFDRES) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-difficulty-dressing-or-bathing` |
| Difficulty Dressing or Bathing (DIFFDRES) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Serious Difficulty Concentrating, Remembering or Deciding (DECIDE) | `dcterms:publisher` | `https://axius-sdc.com` |
| Serious Difficulty Concentrating, Remembering or Deciding (DECIDE) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Serious Difficulty Concentrating, Remembering or Deciding (DECIDE) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-difficulty-concentrating-or-remembering` |
| Serious Difficulty Concentrating, Remembering or Deciding (DECIDE) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Serious Difficulty Walking or Climbing Stairs (DIFFWALK) | `dcterms:publisher` | `https://axius-sdc.com` |
| Serious Difficulty Walking or Climbing Stairs (DIFFWALK) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Serious Difficulty Walking or Climbing Stairs (DIFFWALK) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-difficulty-walking-or-climbing-stairs` |
| Serious Difficulty Walking or Climbing Stairs (DIFFWALK) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| BRFSS Health Status and Access | `dcterms:publisher` | `https://axius-sdc.com` |
| BRFSS Health Status and Access | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| BRFSS Health Status and Access | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-health-status` |
| BRFSS Health Status and Access | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C16669` |
| Exercise in Past 30 Days (EXERANY2) | `dcterms:publisher` | `https://axius-sdc.com` |
| Exercise in Past 30 Days (EXERANY2) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Exercise in Past 30 Days (EXERANY2) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-exercise-in-past-30-days` |
| Exercise in Past 30 Days (EXERANY2) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| General Health Status | `dcterms:publisher` | `https://axius-sdc.com` |
| General Health Status | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| General Health Status | `dcterms:identifier` | `https://axius-sdc.com/library/fair/general-health-status` |
| General Health Status | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| General Health Status | `skos:closeMatch` | `http://purl.obolibrary.org/obo/NCIT_C16669` |
| Length of Time Since Last Routine Checkup (CHECKUP1) | `dcterms:publisher` | `https://axius-sdc.com` |
| Length of Time Since Last Routine Checkup (CHECKUP1) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Length of Time Since Last Routine Checkup (CHECKUP1) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-length-since-last-checkup` |
| Length of Time Since Last Routine Checkup (CHECKUP1) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Days Mental Health Not Good, Past 30 (MENTHLTH) | `dcterms:publisher` | `https://axius-sdc.com` |
| Days Mental Health Not Good, Past 30 (MENTHLTH) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Days Mental Health Not Good, Past 30 (MENTHLTH) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-days-mental-health-not-good` |
| Days Mental Health Not Good, Past 30 (MENTHLTH) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Days Mental Health Not Good, Past 30 (MENTHLTH) | `skos:closeMatch` | `https://loinc.org/63579-7/` |
| Days Physical Health Not Good, Past 30 (PHYSHLTH) | `dcterms:publisher` | `https://axius-sdc.com` |
| Days Physical Health Not Good, Past 30 (PHYSHLTH) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Days Physical Health Not Good, Past 30 (PHYSHLTH) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-days-physical-health-not-good` |
| Days Physical Health Not Good, Past 30 (PHYSHLTH) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Days Physical Health Not Good, Past 30 (PHYSHLTH) | `skos:closeMatch` | `https://loinc.org/63580-5/` |
| BRFSS Survey Design | `dcterms:publisher` | `https://axius-sdc.com` |
| BRFSS Survey Design | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| BRFSS Survey Design | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-survey-design` |
| BRFSS Survey Design | `skos:exactMatch` | `http://purl.obolibrary.org/obo/NCIT_C142700` |
| Primary Sampling Unit (_PSU) | `dcterms:publisher` | `https://axius-sdc.com` |
| Primary Sampling Unit (_PSU) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Primary Sampling Unit (_PSU) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-primary-sampling-unit` |
| Primary Sampling Unit (_PSU) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Sample Design Stratification Variable (_STSTR) | `dcterms:publisher` | `https://axius-sdc.com` |
| Sample Design Stratification Variable (_STSTR) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Sample Design Stratification Variable (_STSTR) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-sample-design-stratum` |
| Sample Design Stratification Variable (_STSTR) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| State FIPS Code (_STATE) | `dcterms:publisher` | `https://axius-sdc.com` |
| State FIPS Code (_STATE) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| State FIPS Code (_STATE) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-state-fips-code` |
| State FIPS Code (_STATE) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Final Weight: Land-line and Cell-phone Data (_LLCPWT) | `dcterms:publisher` | `https://axius-sdc.com` |
| Final Weight: Land-line and Cell-phone Data (_LLCPWT) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Final Weight: Land-line and Cell-phone Data (_LLCPWT) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-final-weight` |
| Final Weight: Land-line and Cell-phone Data (_LLCPWT) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Interview Date (IDATE) | `dcterms:publisher` | `https://axius-sdc.com` |
| Interview Date (IDATE) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Interview Date (IDATE) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-interview-date` |
| Interview Date (IDATE) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| BRFSS Tobacco and Alcohol Use | `dcterms:publisher` | `https://axius-sdc.com` |
| BRFSS Tobacco and Alcohol Use | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| BRFSS Tobacco and Alcohol Use | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-tobacco-and-alcohol` |
| BRFSS Tobacco and Alcohol Use | `skos:exactMatch` | `https://loinc.org/72166-2/` |
| Computed Smoking Status (_SMOKER3) | `dcterms:publisher` | `https://axius-sdc.com` |
| Computed Smoking Status (_SMOKER3) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Computed Smoking Status (_SMOKER3) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-computed-smoking-status` |
| Computed Smoking Status (_SMOKER3) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Current E-cigarette Use (ECIGNOW2) | `dcterms:publisher` | `https://axius-sdc.com` |
| Current E-cigarette Use (ECIGNOW2) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Current E-cigarette Use (ECIGNOW2) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-e-cigarette-use` |
| Current E-cigarette Use (ECIGNOW2) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Frequency of Days Now Smoking (SMOKDAY2) | `dcterms:publisher` | `https://axius-sdc.com` |
| Frequency of Days Now Smoking (SMOKDAY2) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Frequency of Days Now Smoking (SMOKDAY2) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-frequency-of-days-now-smoking` |
| Frequency of Days Now Smoking (SMOKDAY2) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Smoked at Least 100 Cigarettes (SMOKE100) | `dcterms:publisher` | `https://axius-sdc.com` |
| Smoked at Least 100 Cigarettes (SMOKE100) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Smoked at Least 100 Cigarettes (SMOKE100) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-smoked-100-cigarettes` |
| Smoked at Least 100 Cigarettes (SMOKE100) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Smoked at Least 100 Cigarettes (SMOKE100) | `skos:closeMatch` | `https://loinc.org/63581-3/` |
| Smoking Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Smoking Status | `dcterms:source` | `https://github.com/SemanticDataCharter/FAIR_Data_Demo` |
| Smoking Status | `dcterms:identifier` | `https://axius-sdc.com/library/fair/smoking-status` |
| Smoking Status | `skos:exactMatch` | `https://loinc.org/72166-2/` |
| Average Alcoholic Drinks per Day in Past 30 (AVEDRNK3) | `dcterms:publisher` | `https://axius-sdc.com` |
| Average Alcoholic Drinks per Day in Past 30 (AVEDRNK3) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Average Alcoholic Drinks per Day in Past 30 (AVEDRNK3) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-average-drinks-per-day` |
| Average Alcoholic Drinks per Day in Past 30 (AVEDRNK3) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Average Alcoholic Drinks per Day in Past 30 (AVEDRNK3) | `skos:closeMatch` | `https://loinc.org/74013-4/` |
| Binge Drinking Occasions in Past 30 (DRNK3GE5) | `dcterms:publisher` | `https://axius-sdc.com` |
| Binge Drinking Occasions in Past 30 (DRNK3GE5) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Binge Drinking Occasions in Past 30 (DRNK3GE5) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-binge-drinking-occasions` |
| Binge Drinking Occasions in Past 30 (DRNK3GE5) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| Days in Past 30 Had Alcoholic Beverage (ALCDAY4) | `dcterms:publisher` | `https://axius-sdc.com` |
| Days in Past 30 Had Alcoholic Beverage (ALCDAY4) | `dcterms:source` | `https://www.cdc.gov/brfss/annual_data/annual_2022.html` |
| Days in Past 30 Had Alcoholic Beverage (ALCDAY4) | `dcterms:identifier` | `https://axius-sdc.com/library/fair/brfss-days-drank-alcohol` |
| Days in Past 30 Had Alcoholic Beverage (ALCDAY4) | `rdfs:seeAlso` | `https://www.cdc.gov/brfss/annual_data/2022/pdf/codebook22_llcp-v2-508.pdf` |
| PROV Activity | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Activity | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-activity` |
| PROV Activity | `skos:exactMatch` | `http://www.w3.org/ns/prov#Activity` |
| PROV Activity | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-description` |
| Activity Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Activity Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-m9xg6e182m1oq77ssrf9iujv` |
| Activity Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-identifier` |
| Activity Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Activity Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-fpnn1dew0kcevc8ptohndc5t` |
| Activity Label | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Label | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-label` |
| Activity Label | `skos:exactMatch` | `http://www.w3.org/2000/01/rdf-schema#label` |
| Activity Label | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Label | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-n4kaez29vbknku2jy8n56gfm` |
| Activity Location | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Location | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-location` |
| Activity Location | `skos:exactMatch` | `http://www.w3.org/ns/prov#atLocation` |
| Activity Location | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Location | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ciuklf1kl8bphpudye4i47am` |
| Activity Type | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-type` |
| Activity Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#type` |
| Activity Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Activity Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ceusvbe55b266gcdzf5qnurc` |
| Error Message | `dcterms:publisher` | `https://axius-sdc.com` |
| Error Message | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/error-message` |
| Error Message | `dcterms:source` | `https://schema.org/` |
| Error Message | `skos:exactMatch` | `https://schema.org/error` |
| Error Message | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-eakhqr9l9nbblppgxc5fq25n` |
| Had Plan Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Had Plan Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/had-plan-reference` |
| Had Plan Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#hadPlan` |
| Had Plan Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Had Plan Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-xvdfh1nzfar33yxmgl3jgvqo` |
| Used Entity Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Used Entity Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/used-entity-reference` |
| Used Entity Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#used` |
| Used Entity Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Used Entity Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ixv0fa8xlde52mdeymr4zaka` |
| Was Associated With Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Associated With Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-associated-with-reference` |
| Was Associated With Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasAssociatedWith` |
| Was Associated With Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Associated With Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-gs0e1hp2rpjl6qfg9v8d047f` |
| Was Ended By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Ended By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-ended-by-reference` |
| Was Ended By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasEndedBy` |
| Was Ended By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Ended By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-jr1e3n5kg31nqz1ynh28kitp` |
| Was Informed By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Informed By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-informed-by-reference` |
| Was Informed By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasInformedBy` |
| Was Informed By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Informed By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rz60y6aujd274j4i7jpyxvpr` |
| Was Started By Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Was Started By Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/was-started-by-reference` |
| Was Started By Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#wasStartedBy` |
| Was Started By Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Was Started By Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-kmodjk1e5xu9z94zgiaxx1hu` |
| Activity Status | `dcterms:publisher` | `https://axius-sdc.com` |
| Activity Status | `dcterms:source` | `https://w3id.org/dpv` |
| Activity Status | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/activity-status` |
| Activity Status | `skos:closeMatch` | `https://w3id.org/dpv#ActivityStatus` |
| Activity Status | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yehcpzf43j0b5zp9ck59t9eg` |
| Ended At | `dcterms:publisher` | `https://axius-sdc.com` |
| Ended At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/ended-at-time` |
| Ended At | `skos:exactMatch` | `http://www.w3.org/ns/prov#endedAtTime` |
| Ended At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Started At | `dcterms:publisher` | `https://axius-sdc.com` |
| Started At | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/started-at-time` |
| Started At | `skos:exactMatch` | `http://www.w3.org/ns/prov#startedAtTime` |
| Started At | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent` |
| PROV Agent | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `dcterms:publisher` | `https://axius-sdc.com` |
| Acted On Behalf Of Reference | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/acted-on-behalf-of-reference` |
| Acted On Behalf Of Reference | `skos:exactMatch` | `http://www.w3.org/ns/prov#actedOnBehalfOf` |
| Acted On Behalf Of Reference | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Acted On Behalf Of Reference | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-dce4w62jxjngjnmc5y26fq66` |
| Agent Description | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Description | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-description` |
| Agent Description | `skos:exactMatch` | `http://purl.org/dc/terms/description` |
| Agent Description | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Description | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-w79xppnskig5vq31er8gh7nk` |
| Agent Email | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Email | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-email` |
| Agent Email | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/mbox` |
| Agent Email | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Email | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yp6pm5xyovxhkjimrrb8h9xy` |
| Agent Identifier | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Identifier | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-identifier` |
| Agent Identifier | `skos:exactMatch` | `http://purl.org/dc/terms/identifier` |
| Agent Identifier | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Identifier | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-hhfnj5hd1yzt252jfq5pdjj1` |
| Agent Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-name` |
| Agent Name | `skos:exactMatch` | `http://xmlns.com/foaf/0.1/name` |
| Agent Name | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| Agent Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-yya0pdgjd2w0wlz5r3h516om` |
| Agent Organization Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Agent Organization Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/agent-organization-name` |
| Agent Organization Name | `dcterms:source` | `https://schema.org/` |
| Agent Organization Name | `skos:exactMatch` | `https://schema.org/legalName` |
| Agent Organization Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-ifw5zfe4oiijbxjn1ylc2wm3` |
| Software Name | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Name | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-name` |
| Software Name | `dcterms:source` | `https://schema.org/` |
| Software Name | `skos:exactMatch` | `https://schema.org/SoftwareApplication` |
| Software Name | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-rsjfjz8m5z7a58h5793duqbs` |
| Software Version | `dcterms:publisher` | `https://axius-sdc.com` |
| Software Version | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/software-version` |
| Software Version | `dcterms:source` | `https://schema.org/` |
| Software Version | `skos:exactMatch` | `https://schema.org/softwareVersion` |
| Software Version | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-tep9wanrrtqfw0k76huv6tvd` |
| PROV Agent Type | `dcterms:publisher` | `https://axius-sdc.com` |
| PROV Agent Type | `dcterms:identifier` | `https://axius-sdc.com/library/provgov/prov-agent-type` |
| PROV Agent Type | `skos:exactMatch` | `http://www.w3.org/ns/prov#Agent` |
| PROV Agent Type | `dcterms:source` | `https://www.w3.org/TR/prov-o/` |
| PROV Agent Type | `prov:wasRevisionOf` | `https://semanticdatacharter.com/ns/sdc4/mc-nesxtz8c5o665swc9lhvqkjj` |

## Using This Model with AI Assistants

### Quick Start Prompt

Copy and customize this prompt for your AI assistant:

```
I have an SDC4-compliant data model called "BRFSS Respondent" and need help
creating a data entry application.

**Attached Files:**
- XML Schema (dm-iymux9kjv8ndbkoi36xzx17i.xsd)
- Example instance (dm-iymux9kjv8ndbkoi36xzx17i.xml)
- HTML documentation (dm-iymux9kjv8ndbkoi36xzx17i.html)

**What I Need:**
I need a [specify framework: Python Reflex / React / Django / etc.] application that:

1. **Data Import**: Import data from CSV files
2. **Data Storage**: Store in [SQLite / PostgreSQL / MySQL / etc.] database
3. **Data Entry**: Forms for creating/editing records with validation
4. **Data Browser**: View, filter, and search records
5. **Export**: Export data back to CSV or XML

**Database Design:**
Each SDC4 Cluster in the schema should map to a database table with
appropriate relationships.

**My Specific Requirements:**
[Add your specific needs here]

Please analyze the schema and propose an application architecture.
```

### Example Use Cases

**Python Reflex Data Entry App:**
```
Create a Python Reflex application for data entry based on the
"BRFSS Respondent" SDC4 schema (dm-iymux9kjv8ndbkoi36xzx17i.xsd).
Include CSV import, SQLite storage, forms with validation, and a data browser.
Use the sdcvalidator library for full SDC4 XML validation.
```

**React/Next.js Web App:**
```
Build a React/Next.js application with a REST API backend for the
"BRFSS Respondent" schema (dm-iymux9kjv8ndbkoi36xzx17i.xsd).
Frontend: data entry forms and browser using the schema structure.
Backend: Node.js/Express with PostgreSQL for storage.
```

**Django Admin Interface:**
```
Generate Django models from the "BRFSS Respondent" SDC4 schema (dm-iymux9kjv8ndbkoi36xzx17i.xsd)
with a custom admin interface.
Each cluster should be a Django model with appropriate field types.
Include CSV import/export via Django admin actions.
```

**REST API Only:**
```
Create a FastAPI REST API for the "BRFSS Respondent" data model (dm-iymux9kjv8ndbkoi36xzx17i.xsd).
Endpoints for CRUD operations on each cluster.
Include XML validation using sdcvalidator.
Return both JSON and XML responses.
```

## SDC4 Validation (Optional but Recommended)

For full SDC4 compliance with XML validation, use the `sdcvalidator` Python library.

### Installation

```bash
pip install sdcvalidator
```

### Basic Usage

```python
from sdcvalidator import SDC4Validator

# Initialize validator with your SDC4 data model schema
validator = SDC4Validator('dm-iymux9kjv8ndbkoi36xzx17i.xsd')

# Validate and get a detailed report
report = validator.validate_and_report('data.xml')

if report['valid']:
    print('Valid SDC4 XML instance')
else:
    print('Validation errors:')
    for error in report['errors']:
        print(f"  - {error['xpath']}: {error['reason']}")
```

### ExceptionalValue Recovery

When validation errors occur, sdcvalidator can quarantine invalid data
with ISO 21090 ExceptionalValue elements:

```python
validator = SDC4Validator('dm-iymux9kjv8ndbkoi36xzx17i.xsd')
recovered_tree = validator.validate_with_recovery('data.xml')
validator.save_recovered_xml('recovered_data.xml', 'data.xml')
```

**Note**: XML validation is completely optional. You can build applications
using only JSON, implement custom validation, or add sdcvalidator later.

## GQL Graph Database Usage

The `dm-iymux9kjv8ndbkoi36xzx17i.gql` file contains GQL CREATE statements for property
graph databases (e.g., Neo4j, Amazon Neptune, TigerGraph).

### Loading into Neo4j

```cypher
// Load the GQL file content
// Copy the CREATE statements from dm-iymux9kjv8ndbkoi36xzx17i.gql into the Neo4j browser
```

### Example Queries

```cypher
// Find all components in this data model
MATCH (n:ModelComponent) RETURN n.label, n.sdcType

// Show the structural hierarchy
MATCH (dm:DataModel)-[:HAS_ROOT_CLUSTER]->(c:Cluster)-[:CONTAINS_COMPONENT]->(comp)
RETURN dm.label, c.label, comp.label, comp.sdcType

// Find components with specific constraints
MATCH (n:ModelComponent) WHERE n.minLength IS NOT NULL
RETURN n.label, n.minLength, n.maxLength
```

## Tips for Working with AI Assistants

### 1. Start with Architecture Discussion

Before asking for code, ask the AI to:
- Analyze the schema structure
- Identify complex relationships
- Recommend database design
- Suggest appropriate frameworks

### 2. Iterate in Phases

- **Phase 1**: Basic data models and storage
- **Phase 2**: Data entry forms
- **Phase 3**: Data browser and search
- **Phase 4**: CSV import/export
- **Phase 5**: Advanced features (auth, reporting, etc.)

### 3. Leverage the Documentation

The `dm-iymux9kjv8ndbkoi36xzx17i.html` file contains human-readable descriptions,
constraint definitions, business rules, and semantic links.
Share this with the AI for better understanding.

### 4. Database Schema Mapping

**Option 1: Normalized Tables (Traditional)**
```
Cluster -> Database Table
Sub-Cluster -> Separate Table with Foreign Key
Component -> Table Column
```

**Option 2: JSON Embedding (Simpler)**
```
Main Cluster -> Table
Sub-Clusters -> JSON Column
Components -> Mixed (simple types as columns, complex as JSON)
```

Ask your AI assistant which approach fits your use case.

## Additional Resources

**SDC4 Specification:**
- [Semantic Data Charter](https://semanticdatacharter.org)

**sdcvalidator Documentation:**
- [PyPI Package](https://pypi.org/project/sdcvalidator/)

**Framework Documentation:**
- [Python Reflex](https://reflex.dev)
- [Django](https://www.djangoproject.com)
- [React](https://react.dev)
- [FastAPI](https://fastapi.tiangolo.com)

---

**Generated by SDCStudio** -- Your SDC4-compliant data modeling platform
